

import { ThemedText } from '@/components/themed-text';
import { ThemedView } from '@/components/themed-view';
import { Ionicons } from '@expo/vector-icons';
import * as ImagePicker from 'expo-image-picker';
import * as Location from 'expo-location';
import { useRouter } from 'expo-router';
import React, { useEffect, useState } from 'react';
import {
    Alert,
    Image,
    Modal, Platform,
    Pressable, ScrollView, StyleSheet,
    TextInput, View, useColorScheme
} from 'react-native';
import { Dropdown } from 'react-native-element-dropdown';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { useAuth } from '../../context/userContext';


const API_URL = 'http://192.168.1.11:3000';
const MJM_BLUE = '#024885';
const ID_CAMIONETA = 1;
const ID_PATRULLAJE_MOTORIZADO = 3;
const MAX_FOTOS = 4;
interface RegistroProps {
    visible: boolean;
    onClose: () => void;
    initialData?: any; // Aquí recibes los valores predefinidos (como 'Lugar')
}

export default function 
RegistroOcurrenciat({ visible, onClose, initialData }: RegistroProps) {
useEffect(() => {
    // Solo cargamos initialData si el formulario aún no tiene un lugar asignado
    if (visible && initialData && !form.id_lugar) {
        setForm(prev => ({
            ...prev,
            ...initialData 
        }));
    }
}, [visible]); // Quitamos initialData de las dependencias para evitar bucles
    const [modoBusquedaManual, setModoBusquedaManual] = useState(false);
    const insets = useSafeAreaInsets();
    const { userData } = useAuth();
    const router = useRouter();
    const colorScheme = useColorScheme();
    const isDark = colorScheme === 'dark';

    // --- ESTADOS ---
    const [step, setStep] = useState(1);
    const [loading, setLoading] = useState(false);
    const [uploadProgress, setUploadProgress] = useState(0);
    const [uploadStatus, setUploadStatus] = useState('Subiendo...');
    const [isFinished, setIsFinished] = useState(false);
    const [fotos, setFotos] = useState<{ uri: string; base64: string }[]>([]);
   
    const [showPicker, setShowPicker] = useState(false);
    const [pickerMode, setPickerMode] = useState<'time' | 'date'>('time');
    const [activeField, setActiveField] = useState<string | null>(null);
    const [tempDate, setTempDate] = useState<Date>(new Date());
const [derivarUnidad, setDerivarUnidad] = useState(false);
    const [tiposVia, setTiposVia] = useState([]);
    const [vias, setVias] = useState([]);        
    const [cuadras, setCuadras] = useState([]);  
    const [selTipoVia, setSelTipoVia] = useState<any>(null);
    const [selVia, setSelVia] = useState<any>(null);
const normalize = (text: string): string => 
    text.toLowerCase()
        .normalize("NFD")
        .replace(/[\u0300-\u036f]/g, "");
    const [catalogos, setCatalogos] = useState({
        usuarios: [], modalidades: [], origenes: [], camaras: [],
        tipos_patrullaje: [], modalidades_patrullaje: [],
        tipos_vehiculo: [], unidades: [], pnps: [], lugares: [], id_personal_operativo: []
    });

    const [unidadForm, setUnidadForm] = useState({
        id_tipo_vehiculo: null as number | null,
        id_unidad: null as number | null,
        placa: '',
        tipo_asignacion: 'MUNICIPAL' as 'MUNICIPAL' | 'INTEGRADO',
        id_pnp: null as number | null
    });
const getHoy = () => {
    const d = new Date();
    return new Date(d.getTime() - d.getTimezoneOffset() * 60000).toISOString().split('T')[0];
};
    const [form, setForm] = useState({
        id_usuario: null,
        id_lugar: null,
        id_modalidad: '',
        id_origen: '5',
        id_tipo_patrullaje:'7',
        id_modalidad_patrullaje: '6',
        vehiculos_detalle: [] as any[],
        id_personal_operativo: [] as any[], // <--- OBLIGATORIO INICIAR COMO ARRAY
        id_camara: [] as any[],
        descripcion: '',
        hora_alerta: '',
        hora_llegada: '',
        hora_repliegue: '',
        latitud_gps: '0',
        longitud_gps: '0',
        nombre_punto_gps: '',
        referencia: '',   
        detalle_llamada: { numero_telefono: '', nombre_informante: '' },
        unidad_encargada: 'SERENAZGO',
      fecha_evento: getHoy(),
        grupo: null
    });
const [showPersonalDropdown, setShowPersonalDropdown] = useState(false);
const [searchFocus, setSearchFocus] = useState<string | null>(null); // Para resetear el dropdown
// Definimos el tipo para que TypeScript no marque error
const validation: Record<string, boolean> = {
   step1: !!form.grupo && 
           !!form.detalle_llamada?.numero_telefono && 
           form.detalle_llamada.numero_telefono.length >= 9,
 step2: (() => {
    const { hora_alerta, hora_llegada, hora_repliegue } = form;
    if (!hora_alerta || !hora_llegada || !hora_repliegue) return false;

    const toMin = (t: string) => {
        const [h, m] = t.split(':').map(Number);
        return h * 60 + m;
    };

    const tA = toMin(hora_alerta);
    const tL = toMin(hora_llegada);
    const tR = toMin(hora_repliegue);

    // Calcula diferencia real (0 a 1439 minutos)
    const getDiff = (start: number, end: number) => {
        const diff = end - start;
        return diff < 0 ? diff + 1440 : diff; 
    };

    const diffAlertaLlegada = getDiff(tA, tL);
    const diffLlegadaRepliegue = getDiff(tL, tR);

    // REGLAS:
    // 1. Admitimos 0 (pueden ser la misma hora).
    // 2. Ponemos un tope de 720 min (12h) por tramo para detectar errores de captura.
    const tramo1Valido = diffAlertaLlegada >= 0 && diffAlertaLlegada < 720; 
    const tramo2Valido = diffLlegadaRepliegue >= 0 && diffLlegadaRepliegue < 720;

    return tramo1Valido && tramo2Valido;
})(),
    step3: !!form.id_lugar,
    step4: !!form.id_modalidad && form.descripcion?.length > 2,
};
// Evalúa si todos los pasos del objeto validation son true
const formCompleto = validation.step1 && validation.step2 && validation.step3 && validation.step4;
    // --- LÓGICA DE VALIDACIÓN ---
    const canAdvance = () => {
   if (step === 1) {
    // Verifica que exista el grupo Y que el arreglo de cámaras tenga al menos un elemento
    const hasBasics = !!form.grupo ;
    
    if (!hasBasics) {
        Alert.alert("Atención", "Debe seleccionar al menos una cámara para continuar.");
    }
    
    return hasBasics;
}
    if (step === 2) {
        const { hora_alerta, hora_llegada, hora_repliegue, fecha_evento } = form;
        
        // Primero: ¿Están todos los campos llenos?
        const camposLlenos = !!hora_alerta && !!hora_llegada && !!hora_repliegue && !!fecha_evento;
        if (!camposLlenos) return false;

        // Segundo: Validar orden (Alerta <= Llegada y Llegada <= Repliegue)
     const esCronologico = () => {
    const d1 = new Date(`2000-01-01T${form.hora_alerta}`);
    const d2 = new Date(`2000-01-01T${form.hora_llegada}`);
    const d3 = new Date(`2000-01-01T${form.hora_repliegue}`);
    return d1 <= d2 && d2 <= d3;
};
        return esCronologico;
    }

        if (step === 3) return !!form.id_lugar;
        if (step === 4) return !!form.id_modalidad && form.descripcion.length > 0;
        return false;
    };

    const getDynamicBorderStyle = (value: any) => ({
        borderColor: value ? MJM_BLUE : (isDark ? '#444' : '#ddd'),
        borderWidth: value ? 1.5 : 1
    });

    // --- FUNCIÓN PARA FORMATEAR FECHA EN ESPAÑOL ---
    const formatearFechaEspañol = (fechaStr: string) => {
        if (!fechaStr) return "Seleccione fecha";
        
        const fecha = new Date(fechaStr + 'T12:00:00');
        
        const diasSemana = ['Domingo', 'Lunes', 'Martes', 'Miércoles', 'Jueves', 'Viernes', 'Sábado'];
        const meses = ['Enero', 'Febrero', 'Marzo', 'Abril', 'Mayo', 'Junio', 'Julio', 'Agosto', 'Septiembre', 'Octubre', 'Noviembre', 'Diciembre'];
        
        const diaSemana = diasSemana[fecha.getDay()];
        const dia = fecha.getDate();
        const mes = meses[fecha.getMonth()];
        const año = fecha.getFullYear();
        
        return `${diaSemana}, ${dia} de ${mes} de ${año}`;
    };

    // --- FUNCIÓN PARA FORMATEAR HORA EN 24H ---
    const formatearHora24h = (horaStr: string) => {
        if (!horaStr) return "00:00";
        // Si ya está en formato HH:MM, lo devolvemos
        if (/^([0-1][0-9]|2[0-3]):[0-5][0-9]$/.test(horaStr)) {
            return horaStr;
        }
        return "00:00";
    };

    // --- MANEJADOR DE CAMBIO DE FECHA ---
// --- MANEJADOR DE CAMBIO DE FECHA ---
const handleDateChange = (event: any, selectedDate?: Date) => {
    if (Platform.OS === 'android') {
        setShowPicker(false);
    }

    if (selectedDate) {
        const fechaStr = selectedDate.toISOString().split('T')[0];
        
        if (Platform.OS === 'android') {
            // Retraso para evitar crash al cerrar el modal
            setTimeout(() => {
                setForm(f => ({ ...f, fecha_evento: fechaStr }));
            }, 100);
        } else {
            setForm(f => ({ ...f, fecha_evento: fechaStr }));
        }
    }

    if (Platform.OS === 'ios') {
        setTempDate(selectedDate || new Date());
    }
};

// --- MANEJADOR DE CAMBIO DE HORA ---
const handleTimeChange = (event: any, selectedTime?: Date) => {
    if (Platform.OS === 'android') {
        setShowPicker(false);
    }

    if (selectedTime && activeField) {
        const horaStr = selectedTime.toLocaleTimeString('en-GB', { 
            hour: '2-digit', 
            minute: '2-digit',
            hour12: false 
        });

        if (Platform.OS === 'android') {
            // El setTimeout es vital aquí para que no se quede trabado en "24h"
            setTimeout(() => {
                setForm(f => ({ ...f, [activeField!]: horaStr }));
                setActiveField(null); // <--- Agrega esto para "soltar" el foco del input
            }, 100);
        } else {
            setForm(f => ({ ...f, [activeField!]: horaStr }));
        }
    }

    if (Platform.OS === 'ios') {
        setTempDate(selectedTime || new Date());
    }
};
    // --- CONFIRMAR SELECCIÓN EN iOS ---
    const confirmIOSSelection = () => {
        if (activeField === 'fecha_evento') {
            const fechaStr = tempDate.toISOString().split('T')[0];
            setForm(f => ({ ...f, fecha_evento: fechaStr }));
        } else if (activeField) {
            const horaStr = tempDate.toLocaleTimeString('en-GB', { 
                hour: '2-digit', 
                minute: '2-digit',
                hour12: false 
            });
            setForm(f => ({ ...f, [activeField]: horaStr }));
        }
        setShowPicker(false);
    };

    // --- EFECTOS E INICIALIZACIÓN ---
    useEffect(() => {
        if (userData) setForm(prev => ({ ...prev, id_usuario: userData.id || (userData as any).id_usuario }));
        setForm(prev => ({ ...prev, fecha_evento: getHoy() }));
        cargarCatalogosInit();
        
        obtenerGpsAutomatico();
        
    }, [userData]);

    const obtenerGpsAutomatico = async () => {
        try {
            let lat, lon;
            if (Platform.OS === 'web') { lat = -12.073769; lon = -77.039673; }
            else {    
                let { status } = await Location.requestForegroundPermissionsAsync();
                if (status !== 'granted') return;
                const loc = await Location.getCurrentPositionAsync({ accuracy: Location.Accuracy.Balanced });
                lat = loc.coords.latitude; lon = loc.coords.longitude;
            }
            setForm(prev => ({ ...prev, latitud_gps: lat.toString(), longitud_gps: lon.toString() }));
            const reverseGeocode = await Location.reverseGeocodeAsync({ latitude: lat, longitude: lon });
            if (reverseGeocode.length > 0) {
                const p = reverseGeocode[0];
                const direccionNombre = `${p.street || ''} ${p.streetNumber || ''}, ${p.district || p.city || ''}`.trim();
                setForm(prev => ({ ...prev, nombre_punto_gps: direccionNombre || 'Ubicación identificada' }));
            }
        } catch (e) { console.error("Error GPS:", e); }
    };

const cargarCatalogosInit = async () => {
    try {
        const [resGral, resTiposV, resPnps] = await Promise.all([
            fetch(`${API_URL}/catalogos/completo/unificadov?tipoLugar=4`),
            fetch(`${API_URL}/catalogos/tipos-vehiculo`),
            fetch(`${API_URL}/catalogos/pnp-activos`),
        ]);

        const data = await resGral.json();
        const dataTiposV = await resTiposV.json();
        const dataPnps = await resPnps.json();

        // Obtenemos el ID del usuario logueado desde tu contexto/state
        const miId = userData?.id || (userData as any)?.id_persona || (userData as any)?.id_usuario;

        setCatalogos({
            usuarios: data.usuarios || [],
            modalidades: data.modalidades || [],
            origenes: data.origenes || [],
            camaras: data.camaras || [],
            tipos_patrullaje: data.tipos_patrullaje || [],
            modalidades_patrullaje: data.modalidades_patrullaje || [],
            
            // --- AQUÍ HACEMOS EL FILTRO ---
            id_personal_operativo: (data.personal_operativo || []).filter(
                (persona: any) => Number(persona.value) !== Number(miId)
            ),
            // ------------------------------

            tipos_vehiculo: dataTiposV || [],
            unidades: [],
            pnps: dataPnps || [],
            lugares: data.lugares || []
        });

        if (data.tipos_via) setTiposVia(data.tipos_via);

    } catch (err) {
        console.error("Error al cargar datos:", err);
    }
};
    const fetchUnidades = async (idTipo: any) => {
        try {
            const res = await fetch(`${API_URL}/catalogos/vehiculos-por-tipo/${idTipo}`);
            const data = await res.json();
            setCatalogos(prev => ({ ...prev, unidades: data }));
        } catch (e) { console.error(e); }
    };

    // --- ACCIONES DE FORMULARIO ---
    const agregarVehiculo = () => {
    if (!unidadForm.id_unidad) return Alert.alert("Atención", "Seleccione una unidad/placa.");
    
    // --- VALIDACIÓN DE DUPLICADOS ---
    const yaExiste = form.vehiculos_detalle.some(v => v.id_unidad === unidadForm.id_unidad);
    if (yaExiste) return Alert.alert("Atención", `La placa ${unidadForm.placa} ya ha sido agregada.`);
    // --------------------------------

    const esCamioneta = unidadForm.id_tipo_vehiculo === ID_CAMIONETA;
    const asignacionFinal = esCamioneta ? unidadForm.tipo_asignacion : 'MUNICIPAL';
    const pnpFinal = (esCamioneta && asignacionFinal === 'INTEGRADO') ? unidadForm.id_pnp : null;
    
    if (asignacionFinal === 'INTEGRADO' && !pnpFinal) return Alert.alert("Atención", "Efectivo PNP requerido.");

    setForm(f => ({
        ...f,
        vehiculos_detalle: [...f.vehiculos_detalle, { 
            ...unidadForm, 
            tipo_asignacion: asignacionFinal, 
            id_pnp: pnpFinal,
            // Guardamos el nombre del PNP si existe para mostrarlo en el resumen
      nombre_pnp: (catalogos.pnps.find((p: any) => String(p.value) === String(unidadForm.id_pnp)) as any)?.label || ''
        }]
    }));

    // Resetear formulario de unidad
    setUnidadForm({ id_tipo_vehiculo: null, id_unidad: null, placa: '', tipo_asignacion: 'MUNICIPAL', id_pnp: null });
};

    const handleTipoViaChange = async (idTipo: any) => {
        setSelTipoVia(idTipo); setSelVia(null); setCuadras([]);
        setForm(f => ({ ...f, id_lugar: null }));
        try {
            const res = await fetch(`${API_URL}/catalogos/vias/${idTipo}`);
            setVias(await res.json());
        } catch (err) { console.error(err); }
    };

    const handleViaChange = async (idVia: any) => {
        setSelVia(idVia);
        setForm(f => ({ ...f, id_lugar: null }));
        try {
            const res = await fetch(`${API_URL}/catalogos/cuadras/${idVia}`);
            setCuadras(await res.json());
        } catch (err) { console.error(err); }
    };

    const capturarHoraActual = (campo: string) => {
        const ahora = new Date().toLocaleTimeString('en-GB', { hour12: false, hour: '2-digit', minute: '2-digit' });
        setForm(f => ({ ...f, [campo]: ahora }));
    };
const obtenerFechaLocal = () => {
    const fecha = new Date();
    const offset = fecha.getTimezoneOffset();
    const fechaLocal = new Date(fecha.getTime() - (offset * 60 * 1000));
    return fechaLocal.toISOString().split('T')[0];
};

    const tomarFoto = async () => {
        if (fotos.length >= MAX_FOTOS) return Alert.alert("Límite", "Máximo 5 fotos.");
        const { status } = await ImagePicker.requestCameraPermissionsAsync();
        if (status !== 'granted') return Alert.alert("Error", "Sin permiso de cámara");
        let res = await ImagePicker.launchCameraAsync({ base64: true, quality: 0.3 });
        if (!res.canceled) setFotos(p => [...p, { uri: res.assets[0].uri, base64: `data:image/jpeg;base64,${res.assets[0].base64}` }]);
    };

    const seleccionarGaleria = async () => {
        if (fotos.length >= MAX_FOTOS) return Alert.alert("Límite", "Máximo 5 fotos.");
        let res = await ImagePicker.launchImageLibraryAsync({ base64: true, allowsMultipleSelection: true, quality: 0.3, selectionLimit: MAX_FOTOS - fotos.length });
        if (!res.canceled) {
            const nuevas = res.assets.map(a => ({ uri: a.uri, base64: `data:image/jpeg;base64,${a.base64}` }));
            setFotos(p => [...p, ...nuevas].slice(0, MAX_FOTOS));
        }
    };

const enviarRegistro = async () => {
    // --- RESCATE DE ID PARA ANDROID ---
    const idFinal = form.id_usuario || userData?.id || (userData as any)?.id_usuario;

    if (!idFinal) {
        Alert.alert("Atención", "No se pudo identificar al usuario. Verifique su conexión o reinicie sesión.");
        return;
    }

    setLoading(true); 
    setUploadProgress(0); 
    setUploadStatus('Subiendo...'); 
    setIsFinished(false);

    // Animación simulada de la barra (0% a 90%)
    const interval = setInterval(() => setUploadProgress(p => (p < 90 ? p + 10 : p)), 150);

    try {
        const res = await fetch(`${API_URL}/ocurrencias/registrar/modvehi`, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({
                ...form,
                id_usuario: Number(idFinal),
                id_tipop: form.id_tipo_patrullaje,
                id_modalidadp: form.id_modalidad_patrullaje,
                id_camara: form.id_camara.map(c => (c as any).value).join(','),
                fotos: fotos.map(f => ({ base64_data: f.base64 }))
            })
        });

        clearInterval(interval); // Detiene el contador de la barra simulada
        
        if (res.ok) {
            // Se ejecuta la secuencia visual del éxito
            setUploadProgress(100); 
            setUploadStatus('¡Listo! Subido');
            setIsFinished(true);

            // Esperamos 1.2 segundos para que el usuario aprecie el estado "¡Listo!"
            setTimeout(() => { 
                setLoading(false); // Recién aquí cerramos el modal de carga
                router.replace('/(tabs)' as any); // Redireccionamos de forma fluida
            }, 1200);

        } else { 
            const errorData = await res.json();
            setLoading(false); 
            Alert.alert("Error", errorData.error || "No se pudo guardar el registro."); 
        }
    } catch (e) { 
        clearInterval(interval); 
        setLoading(false); 
        Alert.alert("Error", "Error de conexión con el servidor."); 
    }
};
    // --- RENDER HELPERS ---
    const renderMosaicos = (data: any[], currentId: any, field: string, iconDefault: string) => (
        <View style={styles.mosaicoGrid}>
            {data.map((item: any) => (
                <Pressable key={item.value} onPress={() => setForm({ ...form, [field]: item.value })} style={[styles.mosaicoItem, currentId === item.value && styles.mosaicoSelected]}>
                    <Ionicons name={iconDefault as any} size={18} color={currentId === item.value ? 'white' : MJM_BLUE} />
                    <ThemedText style={[styles.mosaicoText, currentId === item.value && { color: 'white' }]}>{item.label}</ThemedText>
                </Pressable>
            ))}
        </View>
    );

    // --- ESTILOS DINÁMICOS PARA MODO OSCURO ---
const dynamicStyles = {
    card: {
        backgroundColor: 'white',
    },
    textInput: {
        // El fondo es blanco, por lo tanto la letra DEBE ser negra
        backgroundColor: 'white',
        // CAMBIO AQUÍ: #000000 es Negro. El que tenías (#f0efef) es casi blanco.
        color: '#000000', 
        borderColor: isDark ? '#cccccc' : '#eeeeee',
    },
    label: {
        // Un gris oscuro para que sea legible sobre el fondo claro
        color: '#333333', 
    },
    sectionTitle: {
        color: MJM_BLUE,
    },
    dropdown: {
        backgroundColor: 'white',
        // CAMBIO AQUÍ: Tenías #ffffff (Blanco), por eso no se veía nada.
        color: '#000000', 
    },
    timeText: {
        color: MJM_BLUE,
    },
};
    return (
        <ThemedView style={styles.mainContainer}>
            {/* BOTÓN DE INSERTAR - Fuera del modal */}
          

            
                   <Modal animationType="fade" transparent={true} visible={visible} onRequestClose={onClose}>
                {/* Overlay que oscurece el fondo pero es transparente */}
                <View style={styles.modalOverlay}>
                    
                    {/* CONTENEDOR CON ANCHO CONTROLADO */}
                    <View style={styles.modalContent}>
                        
                        {/* Cabecera del Modal */}
                        <View style={styles.modalHeader}>
                            <ThemedText style={styles.modalTitle}>REQ. TELÉFONO</ThemedText>
                           <Pressable onPress={onClose}>
    <Ionicons name="close-circle" size={30} color="#666" />
</Pressable>
                            
                        </View>

                        <ScrollView keyboardShouldPersistTaps="handled" contentContainerStyle={styles.scrollForm}>
                       <View style={styles.newStepperContainer}>
{[1, 2, 3, 4].map((i) => {
const estaListo = validation[`step${i}`];

return (
<View key={i} style={styles.stepWrapper}>
{/* CÍRCULO: Se pinta de azul sólido si está listo, o queda con borde azul si falta */}
<View style={[
styles.circleMain,
estaListo ? styles.circleComplete : styles.circlePending
]}>
<ThemedText style={[
styles.stepNumber,
{ color: estaListo ? 'white' : '#024885' } // Texto blanco sobre fondo azul
]}>
{i}
</ThemedText>
</View>

{/* LÍNEA: También se pinta de azul si el paso está completado */}
{i < 4 && (
<View style={[
styles.connectorLine,
estaListo && { backgroundColor: '#024885' }
]} />
)}
</View>
);
})}
</View>
{/* CABECERA ESTÁTICA */}

 <ScrollView keyboardShouldPersistTaps="handled" contentContainerStyle={styles.scrollWeb} horizontal={false}>
            <View style={styles.webGridContainer}>
                
                {/* COLUMNA 1: DESPACHO */}
                <View style={styles.webColumn}>
                    <View style={styles.headerStepWeb}>
                        <Ionicons name="megaphone" size={18} color="white" />
                        <ThemedText style={styles.headerStepText}>1. DESPACHO Y PERSONAL</ThemedText>
                    </View>
                    <View style={styles.columnBody}>
                         {/* step1*/}  
     <View style={styles.cascadaContainer}>
      
                                   
   <ThemedText style={{fontSize: 11, color: isDark ? '#000000' : '#000000', marginTop: 2}}></ThemedText>
        
       <ThemedText style={{fontSize: 10, color: MJM_BLUE, fontWeight: 'bold'}}>PERSONAL REPORTANDO: </ThemedText>


        <View style={{ flexDirection: 'row', alignItems: 'center', gap: 8, marginBottom: 10 }}>
            <View style={{ 
                flex: 1, flexDirection: 'row', alignItems: 'center', 
                backgroundColor: isDark ? '#222' : '#f0f0f0', borderRadius: 10, 
                paddingHorizontal: 10, height: 45, borderWidth: 1, borderColor: isDark ? '#444' : '#ddd'
            }}>
                <Ionicons name="person-circle" size={20} color={MJM_BLUE} />
                <ThemedText numberOfLines={1} style={{ flex: 1, marginLeft: 8, fontSize: 13, color: isDark ? '#aaa' : '#666' }}>
              {`${userData?.apellido_paterno || ''} ${userData?.apellido_materno || ''}, ${userData?.nombres || ''}`} (TÚ)
                </ThemedText>
                <Ionicons name="lock-closed" size={12} color="#999" />
           
</View>
            {/* BOTÓN QUE ACTIVA/DESACTIVA EL DROPDOWN */}
            <Pressable 
                onPress={() => setShowPersonalDropdown(!showPersonalDropdown)}
                style={({ pressed }) => ({
                    backgroundColor: showPersonalDropdown ? '#E53935' : MJM_BLUE, // Rojo si está abierto para cerrar
                    width: 45, height: 45, borderRadius: 10, justifyContent: 'center', alignItems: 'center',
                    opacity: pressed ? 0.7 : 1
                })}
            >
                <Ionicons name={showPersonalDropdown ? "close" : "person-add"} size={20} color="white" />
            </Pressable>
        </View>

        {/* SELECTOR DE APOYO (Solo se muestra si showPersonalDropdown es true) */}
        {/* SELECTOR DE APOYO MEJORADO */}
{/* SELECTOR DE APOYO MEJORADO CON BÚSQUEDA FLEXIBLE */}
{showPersonalDropdown && (
    <Dropdown
    containerStyle={styles.dropdownContainer}
    itemTextStyle={styles.itemText}
    itemContainerStyle={styles.itemContainer}


     style={[
        styles.inputShared, // El estilo que unificamos (debe tener height: 50 o similar)
        { borderColor: MJM_BLUE }
    ]}
        data={catalogos.id_personal_operativo}
        search
        labelField="label"
        valueField="value"
        placeholder="Agregar personal de apoyo"
        searchPlaceholder="Escribe iniciales o apellidos..."
        
        // --- PROPIEDAD PARA BÚSQUEDA POR FRAGMENTOS ---
        searchQuery={(keyword, label) => {
            const cleanLabel = label.toLowerCase();
            const searchTerms = keyword.toLowerCase().trim().split(/\s+/); 
            
            // Retorna true solo si todos los fragmentos escritos existen en el nombre
            return searchTerms.every(term => cleanLabel.includes(term));
        }}
        // ----------------------------------------------

        onChange={item => {
            if (!form.id_personal_operativo.find(p => p.value === item.value)) {
                setForm(prev => ({ 
                    ...prev, 
                    id_personal_operativo: [...prev.id_personal_operativo, item] 
                }));
            }
            setShowPersonalDropdown(false);
        }}
        renderLeftIcon={() => <Ionicons name="search" size={18} color={MJM_BLUE} />}
    />
)}

        {/* CHIPS DE PERSONAL SELECCIONADO */}
        <View style={styles.chipsRow}>
            {form.id_personal_operativo.map(p => (
                <Pressable 
                    key={p.value} 
                    style={[styles.chip, { backgroundColor: '#2E7D32', marginBottom: 5 }]} 
                    onPress={() => {
                        setForm(f => ({
                            ...f, 
                            id_personal_operativo: f.id_personal_operativo.filter(x => x.value !== p.value)
                        }));
                    }}
                >
                    <ThemedText style={styles.chipText}>{p.label}</ThemedText>
                    <Ionicons name="close-circle" size={14} color="white" />
                </Pressable>
            ))}
        </View> 

        {/* ... Resto de Grupos y Cámaras (se mantienen igual) ... */}
    <ThemedText style={{fontSize: 10, color: MJM_BLUE, fontWeight: 'bold'}}>GRUPO: </ThemedText>
        <View style={{ marginBottom: 15 }}>
            {renderMosaicos(
                [{label: 'G1', value: '1'}, {label: 'G2', value: '2'}, {label: 'G3', value: '3'}, {label: 'G4', value: '4'}], 
                form.grupo, 'grupo', 'people-outline'
            )}

           
  <View style={styles.sectionContainer}>
  
     <View style={{backgroundColor: isDark ? '#ffffff' : '#eef2ff', padding: 10, borderRadius: 8, marginBottom: 15, borderWidth: 1, borderColor: MJM_BLUE}}>
       <View style={{flexDirection:'row', alignItems:'center', gap:5}}>
                                       
      <ThemedText style={{fontSize: 10, color: MJM_BLUE, fontWeight: 'bold',textAlign: 'center'}}>DATOS DEL CONTRIBUYENTE:</ThemedText>
                                     
       </View>
  
      <View style={styles.inputGroup}>
                    <View style={{ flexDirection: 'row', alignItems: 'center' }}>
    <Ionicons name="phone-landscape-sharp" size={14} color={MJM_BLUE} style={{ marginRight: 4 }} />
    <ThemedText style={{ fontSize: 10, color: MJM_BLUE, fontWeight: 'bold' }}>
        TELÉFONO :
    </ThemedText>
</View>
         <TextInput
         placeholder='Ejem: 987654321'
          placeholderTextColor="#999"
          keyboardType="phone-pad"
          maxLength={9} // Limita a nivel de sistema operativo
          style={styles.input} // Usando el estilo profesional que definimos
          value={form.detalle_llamada.numero_telefono}
          onChangeText={(txt) => {
              // 1. Elimina cualquier caracter que no sea número
              const cleaned = txt.replace(/[^0-9]/g, '');
              
              // 2. Solo actualiza si tiene 9 o menos caracteres
              if (cleaned.length <= 9) {
                  setForm({
                      ...form, 
                      detalle_llamada: { ...form.detalle_llamada, numero_telefono: cleaned }
                  });
              }
          }}
      />
      </View>
    <View style={styles.inputGroup}>
         <ThemedText style={{fontSize: 10, color: MJM_BLUE, fontWeight: 'bold'}}>NOMBRES Y APELLIDOS: (opcional) </ThemedText>
       <TextInput
      placeholderTextColor="#999"
      style={styles.input}
      autoCapitalize="characters" // Sugiere al teclado activar mayúsculas automáticamente
      value={form.detalle_llamada.nombre_informante}
      onChangeText={(txt) => setForm({
        ...form,    
        detalle_llamada: { 
          ...form.detalle_llamada, 
          nombre_informante: txt.toUpperCase() // Convierte cada letra a mayúscula en tiempo real
        }
      })}
    />
      </View>
  </View>
    
    </View>
     
        </View>

        



       
    </View>

                    </View>
                </View>

                {/* COLUMNA 2: TIEMPOS Y UBICACIÓN */}
                
                <View style={styles.webColumn}>
                    <View style={styles.headerStepWeb}>

                        
                        <Ionicons name="time" size={18} color="white" />
                        <ThemedText style={styles.headerStepText}>2. TEMPORALIDAD</ThemedText>
                    </View>
                    <View style={styles.columnBody}>
                {/*step2 */}       
                        <View style={styles.cascadaContainer}>
                               <View style={{ flexDirection: 'row', justifyContent: 'space-between', marginBottom: 10 }}>
                                   <ThemedText style={{fontSize: 10, color: MJM_BLUE, fontWeight: 'bold'}}>FECHA: </ThemedText>
                                <Pressable 
                                    onPress={() => setForm({...form, fecha_evento: getHoy()})}
                                    style={{ backgroundColor: MJM_BLUE, paddingHorizontal: 12, paddingVertical: 6, borderRadius: 6 }}
                                >
                                    <ThemedText style={{ color: 'white', fontSize: 11, fontWeight: 'bold' }}>PONER HOY</ThemedText>
                                </Pressable>
                            </View>
                    
                            {Platform.OS === 'web' ? (
                                <input
                                
                                    type="date"
                                    value={form.fecha_evento}
                                    onChange={(e) => setForm({ ...form, fecha_evento: e.target.value })}
                                   style={{
    height: 45,
    width: '100%',
    borderWidth: 1,
    borderColor: '#ccc',
    borderRadius: 8,
  
    fontSize: 16,
    backgroundColor: '#FFFFFF',
    color: '#000000',
    borderStyle: 'solid',
    // outline: 'none', // Nota: outline solo funciona en Web
}}
                                />
                            ) : (
                               <Pressable 
    onPress={() => { 
        setPickerMode('date'); 
        setActiveField('fecha_evento'); 
        setTempDate(new Date(form.fecha_evento + 'T12:00:00'));
        setShowPicker(true); 
    }} 
    style={[
        styles.inputShared, // <--- Usamos el estilo unificado
        { borderColor: MJM_BLUE }, 
        getDynamicBorderStyle(form.fecha_evento)
    ]}
>
    <Ionicons name="calendar-outline" size={20} color={MJM_BLUE} />
    <ThemedText style={{ color: '#000', marginLeft: 10, flex: 1 }}>
        {formatearFechaEspañol(form.fecha_evento)}
    </ThemedText>
    {/* Opcional: puedes agregar un icono de flechita al final para que parezca un select */}
    <Ionicons name="chevron-down" size={18} color="#ccc" />
</Pressable>
                            )}
                    
                            {/* INPUTS DE HORAS */}
                            {['hora_alerta', 'hora_llegada', 'hora_repliegue'].map((k) => (
                                <View key={k} style={{ marginTop: 15 }}>

                                
                                    <ThemedText style={{fontSize: 10, color: MJM_BLUE, fontWeight: 'bold'}}>
                                        {k.toUpperCase().replace('_', ' ')}
                                    </ThemedText>

                                    <View style={styles.timeRow}>
                                        {Platform.OS === 'web' ? (
                                            <input
                                                type="time"
                                                value={(form as any)[k]}
                                                onChange={(e) => setForm({ ...form, [k]: e.target.value })}
                                                style={{
    // flex: 1, // Quita esto si no quieres que ocupe todo el espacio sobrante
    width: '100%', // O usa un porcentaje menor si quieres margen, ej: '90%'
    maxWidth: 400, // Opcional: evita que en pantallas grandes se vea gigante
    height: 45,
    borderWidth: 1,
    borderColor: '#ccc',
    borderRadius: 8,

    fontSize: 14, // Un tamaño de fuente 16 o 14 es más estándar
    backgroundColor: '#FFFFFF',
}}
                                            />
                                        ) : (
                                            <Pressable 
                                                onPress={() => { 
                                                    setPickerMode('time'); 
                                                    setActiveField(k);
                                                    const currentTime = (form as any)[k];
                                                    const date = new Date();
                                                    if (currentTime && currentTime !== '00:00') {
                                                        const [hours, minutes] = currentTime.split(':');
                                                        date.setHours(parseInt(hours), parseInt(minutes));
                                                    }
                                                    setTempDate(date);
                                                    setShowPicker(true); 
                                                }} 
                                                style={[styles.pickerPressable, { flex: 1, backgroundColor: '#FFF' }]}
                                            >
                                                <Ionicons name="time-outline" size={20} color={MJM_BLUE} />
                                                <ThemedText style={{ color: '#000', marginLeft: 10 }}>
                                                    {formatearHora24h((form as any)[k]) || "00:00"}
                                                </ThemedText>
                                            </Pressable>
                                        )}
                                        <Pressable style={styles.btnTime} onPress={() => capturarHoraActual(k)}>
                                            <Ionicons name="flash" size={20} color="white" />
                                        </Pressable>
                                    </View>
                                </View>
                            ))}
                    
                            {/* VALIDACIÓN VISUAL: Solo aparece si las horas están llenas y el orden es incorrecto */}
                          {/* VALIDACIÓN VISUAL: Solo aparece si las horas están llenas y el step2 de tu validación es false */}
{form.hora_alerta && form.hora_llegada && form.hora_repliegue && !validation.step2 && (
    <View style={{ 
        backgroundColor: '#FFF5F5', 
        borderLeftWidth: 4, 
        borderLeftColor: '#D32F2F', 
        padding: 12, 
        borderRadius: 8, 
        marginTop: 20,
        flexDirection: 'row',
        alignItems: 'center',
        shadowColor: "#000",
        shadowOffset: { width: 0, height: 1 },
        shadowOpacity: 0.1,
        shadowRadius: 2,
        elevation: 2
    }}>
        <View style={{ flex: 1 }}>
            <ThemedText style={{ color: '#D32F2F', fontSize: 13, fontWeight: 'bold' }}>
                Error en secuencia de tiempo
            </ThemedText>
            <ThemedText style={{ color: '#555', fontSize: 11 }}>
                {"La secuencia debe ser: Alerta ➔ Llegada ➔ Repliegue"}
            </ThemedText>
        </View>
    </View>
)}
                        </View>
                
                    </View>
                </View>

                {/* COLUMNA 3: CIERRE Y EVIDENCIA */}
                <View style={styles.webColumn}>
                    <View style={styles.headerStepWeb}>
                 <Ionicons name="location-sharp" size={18} color="white" />

                        <ThemedText style={styles.headerStepText}>3. UBICACIÓN</ThemedText>
                    </View>
                    <View style={styles.columnBody}>
                     {/*step3 */}
    <View style={styles.cascadaContainer}>
        
        {/* Cabecera con Botón de Cambio */}
        <View style={{ flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', marginBottom: 15 }}>
          
           <ThemedText style={{fontSize: 10, color: MJM_BLUE, fontWeight: 'bold'}}>LUGAR CONSOLIDADO:</ThemedText>
      

          
        </View>

        {/* --- MODO A: DIRECCIÓN DIRECTA --- */}
        {!modoBusquedaManual && (
            <View style={{ marginBottom: 10 }}>
              {/* --- MODO A: DIRECCIÓN DIRECTA CON BÚSQUEDA FLEXIBLE --- */}
{!modoBusquedaManual && (
    <View style={{ marginBottom: 10 }}>
      <Dropdown
    containerStyle={styles.dropdownContainer}
    itemTextStyle={[styles.itemText, { color: '#000' }]} 
    selectedTextStyle={{ color: '#000', fontSize: 14 }} 
    itemContainerStyle={styles.itemContainer}
 style={[  styles.dropdown,
    dynamicStyles.dropdown, { borderColor: MJM_BLUE }]}

    data={catalogos?.lugares || []} 
    search 
    searchPlaceholder="Buscar dirección..."
    labelField="label" 
    valueField="value" 
    placeholder="Seleccione la ubicación..."
    value={form.id_lugar} 

    // --- ESTO ES LO QUE LIMPIA AL SELECCIONAR POR SEGUNDA VEZ ---
    onFocus={() => {
        setForm((prev: any) => ({ ...prev, id_lugar: "" }));
    }}

    // BUSCADOR CON EL PARADIGMA DE TOKENS (IGUAL AL ANTERIOR)
    searchQuery={(keyword: string, label: string) => {
        const normalize = (text: string): string =>
            text
                .toLowerCase()
                .normalize("NFD")
                .replace(/[\u0300-\u036f]/g, "");

        const cleanLabel = normalize(label);
        const cleanKeyword = normalize(keyword);

        const searchTerms = cleanKeyword.trim().split(/\s+/); 
        
        return searchTerms.every(term => cleanLabel.includes(term));
    }}
  placeholderStyle={{ color: '#666' }}
    onChange={(item) => {
        setForm((prev: any) => ({ ...prev, id_lugar: item.value }));
    }}

    flatListProps={{
        nestedScrollEnabled: true,
        keyboardShouldPersistTaps: 'handled',
    }}

    activeColor="#E3F2FD"
    inputSearchStyle={{
    height: 40,
    fontSize: 14,
    borderRadius: 8,
    color: '#000',
    paddingHorizontal: 10,
    backgroundColor: '#F9F9F9',
  }}
/>
    </View>
)}
            </View>
        )}

     
{/* PREGUNTA DE DERIVACIÓN Y SELECCIÓN DE ÁREA */}
      

            {/* ... Resto de Grupos y Cámaras (se mantienen igual) ... */}
          
        {/* --- REFERENCIA --- */}
        <View >
            <View style={{ flexDirection: 'row', alignItems: 'center', marginBottom: 5 }}>
          
                <ThemedText style={{fontSize: 10, color: MJM_BLUE, fontWeight: 'bold'}}>REFERENCIA / INTERSECCIÓN: </ThemedText>
            </View>
           <TextInput 
    style={[
        styles.textAreaSmall, 
        { 
            minHeight: 85, 
            textAlignVertical: 'top', 
            color: '#000', 
            backgroundColor: '#FFF',
            padding: 12,
            fontSize: 14,
            borderWidth: 1.5,
            borderColor: form.referencia.length >= 3 ? MJM_BLUE : '#DDD',
            borderRadius: 10
        }
    ]} 
    placeholder="Ej: A media cuadra del ..." 
    placeholderTextColor="#AAA"
    value={form.referencia} 
    // Aplicamos la transformación aquí
    onChangeText={t => {
        const capitalizedText = t.charAt(0).toUpperCase() + t.slice(1);
        setForm({...form, referencia: capitalizedText});
    }} 
    autoCapitalize="sentences"
    multiline 
/>
        </View>
            {/* --- boton--- */}
<View style={{ marginTop: 10, marginBottom: 15, backgroundColor: isDark ? '#1e1e1e' : '#f9f9f9', padding: 12, borderRadius: 10, borderWidth: 1, borderColor: '#ddd' }}>
    
    {/* 1. UNIDAD POR DEFECTO (SIEMPRE SELECCIONADA / FIJA) */}
                <ThemedText style={{fontSize: 10, color: MJM_BLUE, fontWeight: 'bold'}}>UNIDAD PRINCIPAL: </ThemedText>
    <View 
        style={{ 
            flexDirection: 'row', 
            alignItems: 'center', 
            height: 40, 
            borderRadius: 8, 
            paddingHorizontal: 12, 
            backgroundColor: MJM_BLUE, 
            marginBottom: 12 
        }}
    >
        <Ionicons name="checkbox" size={20} color="white" style={{ marginRight: 8 }} />
        <ThemedText style={{ fontSize: 12, fontWeight: 'bold', color: 'white' }}>
            Serenazgo
        </ThemedText>
    </View>

    {/* 2. CHECKBOX PARA ACTIVAR DERIVACIÓN */}
    <Pressable 
        onPress={() => {
            const nuevoEstado = !derivarUnidad;
            setDerivarUnidad(nuevoEstado);
            if (!nuevoEstado) {
                // Si se desmarca, limpiamos las áreas de derivación volviendo al flujo normal
                setForm(f => ({ ...f, unidad_encargada: 'SERENAZGO' }));
            } else {
                // Al marcar, preseleccionamos la primera opción de derivación
                setForm(f => ({ ...f, unidad_encargada: 'FISCALIZACION' }));
            }
        }}
        style={{ flexDirection: 'row', alignItems: 'center', gap: 8, paddingTop: 4 }}
    >
        <Ionicons 
            name={derivarUnidad ? "checkbox" : "square-outline"} 
            size={22} 
            color={MJM_BLUE} 
        />
        <View style={{ flex: 1 }}>
            <ThemedText style={{ fontSize: 12, fontWeight: 'bold', color: MJM_BLUE }}>
                ¿Derivar esta ocurrencia a otra área?
            </ThemedText>
           
        </View>
    </Pressable>

    {/* 3. OPCIONES DE DERIVACIÓN (Se abre si el segundo check es true) */}
    {derivarUnidad && (
        <View style={{ marginTop: 12, borderTopWidth: 1, borderTopColor: '#eee', paddingTop: 10 }}>
            <ThemedText style={{ fontSize: 10, fontWeight: 'bold', color: '#555', marginBottom: 8 }}>
                SELECCIONE EL ÁREA DESTINO:
            </ThemedText>
            
            <View style={{ flexDirection: 'row', gap: 8 }}>
                {/* OPCIÓN FISCALIZACIÓN */}
                <Pressable 
    onPress={() => setForm(f => ({ ...f, unidad_encargada: 'FISCALIZACION' }))}
    style={[
        { 
            flex: 1, 
            height: 40, 
            borderRadius: 8, 
            borderWidth: 1, 
            borderColor: '#ccc', 
            backgroundColor: 'white',
            // Centrado absoluto horizontal y vertical
            justifyContent: 'center', 
            alignItems: 'center' 
        },
        form.unidad_encargada === 'FISCALIZACION' && { backgroundColor: MJM_BLUE, borderColor: MJM_BLUE }
    ]}
>
    <ThemedText 
        style={{ 
            fontSize: 11, 
            fontWeight: 'bold', 
            textAlign: 'center',
            color: form.unidad_encargada === 'FISCALIZACION' ? 'white' : '#333' 
        }}
    >
        Fiscalización   
    </ThemedText>
</Pressable>

                {/* contro urabano */}
              <Pressable 
    onPress={() => setForm(f => ({ ...f, unidad_encargada: 'CONTROL URBANO' }))}
    style={[
        { 
            flex: 1, 
            height: 40, 
            borderRadius: 8, 
            borderWidth: 1, 
            borderColor: '#ccc', 
            backgroundColor: 'white',
            // Centrado absoluto horizontal y vertical
            justifyContent: 'center', 
            alignItems: 'center' 
        },
        form.unidad_encargada === 'CONTROL URBANO' && { backgroundColor: MJM_BLUE, borderColor: MJM_BLUE }
    ]}
>
    <ThemedText 
        style={{ 
            fontSize: 11, 
            fontWeight: 'bold', 
            textAlign: 'center', // Centrado por si el texto salta de línea en pantallas chicas
            color: form.unidad_encargada === 'CONTROL URBANO' ? 'white' : '#333' 
        }}
    >
        Control Urbano
    </ThemedText>
</Pressable>
                 {/* OPCIÓN MOVILIDAD */}
                <Pressable 
    onPress={() => setForm(f => ({ ...f, unidad_encargada: 'LIMPIEZA PUBLICA' }))}
    style={[
        { 
            flex: 1, 
            height: 40, 
            borderRadius: 8, 
            borderWidth: 1, 
            borderColor: '#ccc', 
            backgroundColor: 'white',
            // ESTO CENTRA EL CONTENIDO DE MANERA VERTICAL Y HORIZONTAL:
            justifyContent: 'center', 
            alignItems: 'center' 
        },
        form.unidad_encargada === 'LIMPIEZA PUBLICA' && { backgroundColor: MJM_BLUE, borderColor: MJM_BLUE }
    ]}
>
    <ThemedText 
        style={{ 
            fontSize: 11, 
            fontWeight: 'bold', 
            textAlign: 'center', // Asegura el centrado si el texto llega a ocupar dos líneas
            color: form.unidad_encargada === 'LIMPIEZA PUBLICA' ? 'white' : '#333' 
        }}
    >
        Limpieza Pública
    </ThemedText>
                </Pressable>
            </View>
        </View>
    )}
</View>


            
    </View>

                        
                    </View>
                </View>
 {/* COLUMNA 4: CIERRE Y EVIDENCIA */}
                <View style={styles.webColumn}>
                    <View style={styles.headerStepWeb}>
                        <Ionicons name="checkmark-circle" size={18} color="white" />
                        <ThemedText style={styles.headerStepText}>4. CIERRE DE REGISTRO</ThemedText>
                    </View>
                    <View style={styles.columnBody}>
                         {/*step4 */}
             <View style={styles.cascadaContainer}>
               
              {/* MODALIDAD CON BÚSQUEDA ACTIVADA */}
                     <ThemedText style={{fontSize: 10, color: MJM_BLUE, fontWeight: 'bold'}}>MODALIDAD: </ThemedText>
   <Dropdown
  // 1. Estilos de Contenedor y Textos de la Lista
  containerStyle={styles.dropdownContainer}
  itemTextStyle={[styles.itemText, { color: '#000' }]}
  itemContainerStyle={styles.itemContainer}
  
  // 2. SOLUCIÓN AL DESBORDE: flex: 1 obliga al texto a quedarse dentro
  selectedTextStyle={{ 
    color: '#000', 
    fontSize: 14, 
    flex: 1,           // <--- IMPORTANTE: Evita que el texto se salga
    marginRight: 15    // <--- Espacio para no chocar con la flecha
  }}
  
  // 3. Estilo del Input (Parejo con los demás)
style={[
    styles.dropdown,
    dynamicStyles.dropdown,
    
    getDynamicBorderStyle(form.id_modalidad),
  ]}
  
  // 4. Configuración de Datos
  data={catalogos.modalidades || []}
  value={form.id_modalidad}
  labelField="label"
  valueField="value"
  placeholder="Seleccione Modalidad"
  placeholderStyle={{ color: '#666', fontSize: 14 }}
  
  // 5. Buscador Inteligente
  search
  searchPlaceholder="Buscar modalidad..."
  searchQuery={(keyword: string, label: string) => {
    const normalize = (text: string): string =>
      text
        .toLowerCase()
        .normalize("NFD")
        .replace(/[\u0300-\u036f]/g, "");

    const cleanLabel = normalize(label);
    const cleanKeyword = normalize(keyword);
    const keywords = cleanKeyword.split(" ").filter(word => word.length > 0);

    return keywords.every(word => cleanLabel.includes(word));
  }}

  // 6. Manejo de Eventos
  onFocus={() => {
    setForm((prev) => ({ ...prev, id_modalidad: "" }));
  }}
  onChange={(item) => {
    setForm((prev) => ({ ...prev, id_modalidad: item.value }));
  }}

  // 7. Estilos Visuales del Buscador y Lista
  activeColor="#E3F2FD"
  flatListProps={{
    nestedScrollEnabled: true,
    keyboardShouldPersistTaps: 'handled',
  }}
  inputSearchStyle={{
    height: 40,
    fontSize: 14,
    borderRadius: 8,
    color: '#000',
    paddingHorizontal: 10,
    backgroundColor: '#F9F9F9',
  }}
/>
      
              {/* DESCRIPCIÓN */}
              <View style={{ marginTop: 15, marginBottom: 10 }}>
                              <ThemedText style={{fontSize: 10, color: MJM_BLUE, fontWeight: 'bold'}}>DATOS IMPORTANTES: </ThemedText>
                  <TextInput 
    style={[
        styles.textArea, 
        dynamicStyles.textInput, 
        { 
            backgroundColor: '#FFFFFF', 
            color: '#000000', 
            minHeight: 120, 
            textAlignVertical: 'top',
            padding: 12,
            fontSize: 14
        },
        getDynamicBorderStyle(form.descripcion.length >= 3) 
    ]} 
    placeholder="Escribe todos los detalles aquí..." 
    placeholderTextColor="#999999" 
    multiline={true} 
    autoCapitalize="sentences" // Ayuda al teclado a sugerir la mayúscula
    value={form.descripcion} 
    onChangeText={(t) => {
        // Lógica para forzar la primera letra a Mayúscula
        const capitalizedText = t.charAt(0).toUpperCase() + t.slice(1);
        setForm({ ...form, descripcion: capitalizedText });
    }} 
/>
                  <ThemedText style={{ fontSize: 10, textAlign: 'right', marginTop: 2, color: '#888' }}>
                      {`${form.descripcion.length} caracteres`}
                  </ThemedText>
              </View>
      
              {/* ACCIONES DE FOTOS */}
              <View style={[styles.photoActions, { marginTop: 5 }]}>
                
                  <Pressable style={[styles.btnCamAction, {backgroundColor: '#024885'}]} onPress={seleccionarGaleria}>
                      <Ionicons name="images" size={20} color="white" />
                      <ThemedText style={styles.btnCamText}></ThemedText>
                  </Pressable>
              </View>
      
              <ThemedText style={[
                  styles.photoCounter, 
                  { marginVertical: 5 }, 
                  fotos.length === MAX_FOTOS && { color: 'red', fontWeight: 'bold' }
              ]}>
                  {`${fotos.length} de ${MAX_FOTOS} fotos`}
              </ThemedText>
      
              {/* CAROUSEL DE FOTOS */}
              {fotos.length > 0 && (
                  <ScrollView keyboardShouldPersistTaps="handled" horizontal style={[styles.photoCarousel, { maxHeight: 100 }]} showsHorizontalScrollIndicator={false}>
                      {fotos.map((f, i) => (
                          <View key={i} style={styles.photoWrapper}>
                              <Image source={{ uri: f.uri }} style={styles.photoThumb} />
                              <Pressable 
                                  style={styles.removePhoto} 
                                  onPress={() => setFotos(prev => prev.filter((_, idx) => idx !== i))}
                              >
                                  <Ionicons name="close-circle" size={22} color="red" />
                              </Pressable>
                          </View>
                      ))}
                  </ScrollView>
              )}
      
           <Pressable 
    style={[
        styles.btnSave, 
        { 
            marginTop: 15, 
            // Si formCompleto es true, azul sólido; si no, gris y opaco
        backgroundColor: formCompleto ? '#2E7D32' : '#A0A0A0',
            opacity: formCompleto ? 1 : 0.6 
        }
    ]} 
    onPress={enviarRegistro} 
    // Se bloquea si formCompleto es false o si ya se está enviando
    disabled={!formCompleto || loading}
>
    <ThemedText style={{ color: 'white', fontWeight: 'bold' }}>
        {loading ? "ENVIANDO..." : formCompleto ? "ENVIAR" : "ENVIAR"}
    </ThemedText>
</Pressable>
          </View>
    
                       
                    </View>
                </View>
            </View>

            {/* MODAL DE CARGA REAL / SIMULADO */}
{/* OVERLAY DE CARGA: Aparece encima del formulario al enviar */}
    {loading && (
      <View style={{
        position: 'absolute',
        top: 0, left: 0, right: 0, bottom: 0,
        backgroundColor: 'rgba(0,0,0,0.3)', // Sombra oscura sutil
        justifyContent: 'center',
        alignItems: 'center',
        zIndex: 99999, // Se superpone a todo
      }}>
        {/* Tarjeta blanca con la barra de progreso */}
        <View style={{
          width: '80%',
          backgroundColor: 'white',
          padding: 25,
          borderRadius: 15,
          alignItems: 'center',
          shadowColor: '#000',
          shadowOpacity: 0.25,
          shadowRadius: 4,
          elevation: 5
        }}>
          {/* Texto dinámico protegido contra nulos */}
          <ThemedText style={{ fontSize: 16, fontWeight: 'bold', marginBottom: 15, color: '#000' }}>
            {uploadStatus || 'Subiendo...'}
          </ThemedText>

          {/* Carril gris de la barra de progreso */}
          <View style={{
            width: '100%',
            height: 10,
            backgroundColor: '#e0e0e0', 
            borderRadius: 5,
            overflow: 'hidden',
            marginBottom: 10
          }}>
            {/* Relleno azul dinámico */}
            <View style={{
              width: `${uploadProgress || 0}%`,
              height: '100%',
              backgroundColor: '#007AFF', // Azul estándar por si MJM_BLUE da error
            }} />
          </View>

          {/* Porcentaje numérico */}
          <ThemedText style={{ fontSize: 12, color: '#666' }}>
            {uploadProgress || 0}%
          </ThemedText>
        </View>
      </View>
    )}
        </ScrollView>
                            <View style={styles.webGridContainer}>
                           
                            </View>
                        </ScrollView>

                        
                    </View>
                </View>
            </Modal>
        </ThemedView>
    );

    
}


export const styles = StyleSheet.create({
  // === CONTENEDORES PRINCIPALES ===
  mainContainer: {
    flex: 1,
    padding: 20,
    
  },
  main: { 
    flex: 1 
  },
  scroll: { 
    paddingHorizontal: 15, 
    paddingBottom: 100 
  },
  sectionContainer: {
    backgroundColor: '#fff',
    borderRadius: 12,
    padding: 16,
    marginVertical: 10,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.05,
    shadowRadius: 8,
    elevation: 3,
  },
  card: { 
    backgroundColor: '#FFFFFF', 
    padding: 18, 
    borderRadius: 15, 
    borderWidth: 1,
    borderColor: '#EFEFEF',
  },

  // === MODAL TIPO PANEL (SE ABRE AL COSTADO DERECHO) ===
  modalOverlay: {
    flex: 1,
    backgroundColor: 'rgba(0, 0, 0, 0.4)',
    justifyContent: 'center',              
    alignItems: 'flex-end', // Envía el panel al borde derecho
  },
  modalContent: {
    backgroundColor: 'white',
    width: Platform.OS === 'web' ? '85%' : '95%', 
    height: '99%',
    marginRight: '1%',   
    borderRadius: 20,    
    elevation: 10,
    shadowColor: '#000',
    shadowOpacity: 0.25,
    shadowRadius: 10,
    overflow: 'hidden',
  },

  // === MODAL TIPO DIÁLOGO / PICKER (SE ABRE AL CENTRO) ===
  modalCenterOverlay: {
    flex: 1,
    backgroundColor: 'rgba(0, 0, 0, 0.4)',
    justifyContent: 'center', // Centrado vertical
    alignItems: 'center',     // Centrado horizontal exacto
  },
  modalPickerContent: { 
    backgroundColor: 'white', 
    borderRadius: 20, 
    padding: 20, 
    width: '85%', 
    alignItems: 'center',
    elevation: 5,
    shadowColor: '#000',
    shadowOpacity: 0.15,
    shadowRadius: 6,
  },
  pickerTitle: { 
    fontWeight: 'bold', 
    marginBottom: 15, 
    color: MJM_BLUE 
  },

  // === ELEMENTOS DE MODALES (HEADERS Y FOOTERS) ===
  modalContainer: {
    flex: 1,
    backgroundColor: '#f4f7f6'
  },
  modalHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',    
    paddingHorizontal: 20,   
    paddingVertical: 12,     
    borderBottomWidth: 1,
    borderBottomColor: '#eee',
    backgroundColor: 'white',
  },
  modalTitle: {
    fontSize: 16,            
    fontWeight: 'bold',
    color: MJM_BLUE,
  },
  scrollForm: {
    padding: 20,
  },
  modalFooter: {
    padding: 20,
    borderTopWidth: 1,
    borderTopColor: '#eee',
  },
  footer: {
    padding: 20,
    backgroundColor: 'white',
    borderTopWidth: 1,
    borderTopColor: '#eee'
  },

  // === ENTRADAS DE TEXTO Y FORMULARIOS ===
  inputGroup: {
    marginBottom: 15,
  },
  inputLabel: {
    fontSize: 12,
    fontWeight: '600',
    color: '#444',
    marginBottom: 6,
    marginLeft: 4,
  },
  inputBase: {
    height: 45, 
    borderWidth: 1,
    borderColor: '#ccc',
    borderRadius: 8,
    paddingHorizontal: 12,
    backgroundColor: '#FFFFFF',
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
  },
  inputShared: {
    height: 50,              
    backgroundColor: '#FFFFFF',
    borderWidth: 1,
    borderRadius: 8,         
    paddingHorizontal: 15,
    flexDirection: 'row',    
    alignItems: 'center',    
    marginBottom: 12,        
  },
  input: {
    height: 48,
    backgroundColor: '#f8f9fa',
    borderWidth: 1,
    borderColor: '#e0e0e0',
    borderRadius: 8,
    paddingHorizontal: 15,
    fontSize: 16,
    color: '#333',
  },
  disabledInput: { 
    backgroundColor: '#f8f9fa', 
    color: '#aaa', 
    padding: 10, 
    borderRadius: 8, 
    marginTop: 5 
  },
  fieldContainer: {
    marginBottom: 15,
    width: '100%', 
  },
  textArea: { 
    borderWidth: 1.5, 
    borderColor: '#eee', 
    height: 100, 
    marginTop: 15, 
    padding: 12, 
    borderRadius: 10, 
    textAlignVertical: 'top', 
    backgroundColor: 'white' 
  },
  textAreaSmall: { 
    borderWidth: 1.5, 
    borderColor: '#eee', 
    height: 60, 
    marginTop: 15, 
    padding: 10, 
    borderRadius: 10, 
    backgroundColor: 'white' 
  },

  // === SELECTORES / DROPDOWNS ===
  dropdownContainer: {
    borderRadius: 10,
    overflow: 'hidden',
    backgroundColor: 'white',
  },
  dropdown: { 
    backgroundColor: 'white', 
    borderWidth: 1, 
    borderColor: '#ddd', 
    borderRadius: 6, 
    padding: 8, 
    marginTop: 5 
  },
  itemContainer: {
    paddingVertical: 2, 
  },
  itemText: {
    fontSize: 12, 
    color: '#333',
  },
  selectedTextStyle: {
    fontSize: 14,
    color: '#000',
    marginLeft: 10,
    flex: 1,               
    marginRight: 35,       
    flexWrap: 'nowrap',    
  },
  inputSearchStyle: {
    height: 40,
    fontSize: 16,
    borderRadius: 8,
    color: 'black',
  },
  pickerPressable: { 
    flexDirection: 'row', 
    alignItems: 'center', 
    gap: 10, 
    padding: 12, 
    backgroundColor: '#f4f4f4', 
    borderRadius: 10, 
    marginTop: 5, 
    borderWidth: 1 
  },

  // === FILAS DE MOSAICOS / GRILLAS ===
  filaMosaicos: {
    flexDirection: 'row', 
    paddingVertical: 10,
    paddingHorizontal: 5,
  },
  mosaicoIndividual: {
    width: 100, 
    marginHorizontal: 5,
    aspectRatio: 1,
    justifyContent: 'center',
    alignItems: 'center',
    borderRadius: 10,
    backgroundColor: '#f0f0f0',
  },
  mosaicoGrid: { 
    flexDirection: 'row', 
    gap: 6,           
    marginTop: 8,
    width: '100%'     
  },
  mosaicoItem: { 
    flex: 1,           
    backgroundColor: '#fff', 
    paddingVertical: 8, 
    paddingHorizontal: 2,
    borderRadius: 8, 
    alignItems: 'center', 
    justifyContent: 'center',
    borderWidth: 1.5, 
    borderColor: '#f0f0f0' 
  },
  mosaicoSelected: { 
    backgroundColor: MJM_BLUE, 
    borderColor: MJM_BLUE 
  },
  mosaicoText: { 
    fontSize: 10,      
    fontWeight: 'bold', 
    marginTop: 4,      
    color: MJM_BLUE, 
    textAlign: 'center' 
  },

  // === COMPONENTE STEPPER ===
  newStepperContainer: {
    flexDirection: 'row',
    justifyContent: 'center',
    alignItems: 'center',
    paddingVertical: 5,          
    backgroundColor: '#FFFFFF',
    marginTop: 2,                
    marginBottom: 2,             
  },
  stepperContainer: { 
    flexDirection: 'row', 
    justifyContent: 'center', 
    marginVertical: 12, 
    gap: 12 
  },
  stepWrapper: {
    flexDirection: 'row',
    alignItems: 'center',
  },
  circleMain: {
    width: 34,
    height: 34,
    borderRadius: 17,
    justifyContent: 'center',
    alignItems: 'center',
    borderWidth: 2,
  },
  circlePending: {
    backgroundColor: 'white',
    borderColor: MJM_BLUE, 
  },
  circleComplete: {
    backgroundColor: MJM_BLUE, 
    borderColor: MJM_BLUE,
  },
  circle: { 
    width: 24, 
    height: 24, 
    borderRadius: 12, 
    backgroundColor: '#ddd', 
    justifyContent: 'center', 
    alignItems: 'center' 
  },
  stepNumber: {
    fontWeight: 'bold',
    fontSize: 15,
    textAlign: 'center',
    includeFontPadding: false, 
  },
  connectorLine: {
    width: 30,
    height: 2,
    backgroundColor: '#E0E0E0',
    marginHorizontal: 4,
  },

  // === CHIPS Y UNIDADES ===
  chipsWrapper: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    gap: 8,
  },
  chipsRow: {
    flexDirection: 'row',
    flexWrap: 'wrap', 
    gap: 8,           
    width: '100%',
  },
  chip: { 
    backgroundColor: MJM_BLUE,  
    padding: 8, 
    borderRadius: 15, 
    gap: 5,
    flexDirection: 'row',
    alignItems: 'center',
    maxWidth: '100%', 
  },
  chipText: { 
    color: 'white', 
    fontSize: 12 
  },
  unitChip: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: MJM_BLUE,
    paddingVertical: 6,
    paddingHorizontal: 10,
    borderRadius: 20,
    marginBottom: 5,
  },
  unitChipText: {
    color: 'white',
    fontSize: 12,
    fontWeight: 'bold',
  },
  cascadaContainer: {
    marginTop: 15,
    padding: 12,
    borderRadius: 12,
    backgroundColor: '#F9FBFF', 
    borderWidth: 1,
    borderColor: '#E1E8F5',
  },
  cascadaHeader: { 
    flexDirection: 'row', 
    alignItems: 'center', 
    gap: 8, 
    marginBottom: 5 
  },
  cascadaTitle: { 
    fontSize: 11, 
    fontWeight: 'bold', 
    color: MJM_BLUE 
  },
  unitCard: {
    flexDirection: 'row',
    alignItems: 'center',
    padding: 12,
    borderRadius: 10,
    marginBottom: 8,
    backgroundColor: '#FFFFFF', 
    borderWidth: 1,
    borderColor: '#F0F0F0',
  },
  unitCardIcon: {
    width: 36,
    height: 36,
    borderRadius: 18,
    backgroundColor: '#F0F5FF', 
    justifyContent: 'center',
    alignItems: 'center',
  },
  unitCardPlaca: {
    fontSize: 14,
    fontWeight: 'bold',
    color: MJM_BLUE,
  },
  unitCardSub: {
    fontSize: 11,
    color: '#666',
  },
  unitCardRemove: {
    padding: 8,
  },
  listadoUnidadesContainer: {
    marginTop: 20,
    borderTopWidth: 1,
    borderTopColor: '#e0e0e0',
    paddingTop: 15,
  },
  listadoHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    marginBottom: 10,
  },
  listadoTitle: {
    fontSize: 10,
    fontWeight: 'bold',
    color: '#888',
    letterSpacing: 1,
  },
  selectedUnitsContainer: {
    marginTop: 15,
    paddingTop: 10,
    borderTopWidth: 1,
    borderTopColor: '#eee',
  },
  selectedUnitsTitle: {
    fontSize: 11,
    fontWeight: 'bold',
    color: '#666',
    marginBottom: 8,
    textTransform: 'uppercase'
  },

  // === BOTONES ===
  asignacionContainer: {
    flexDirection: 'row',
    gap: 12,
    width: '100%',
    justifyContent: 'space-between'
  },
  asignacionBtn: {
    flex: 1,
    height: 48,
    borderRadius: 10,
    borderWidth: 1.5,
    borderColor: MJM_BLUE,
    alignItems: 'center',
    justifyContent: 'center',
    backgroundColor: '#FFFFFF', 
  },
  asignacionText: {
    fontSize: 13,
    fontWeight: 'bold',
    textAlign: 'center',
    color: MJM_BLUE,
  },
  btnAddUnit: { 
    backgroundColor: MJM_BLUE, 
    padding: 10, 
    borderRadius: 10 
  },
  btnInsertar: {
    backgroundColor: MJM_BLUE,
    flexDirection: 'row',
    padding: 15,
    borderRadius: 12,
    alignItems: 'center',
    justifyContent: 'center',
    margin: 20,
    gap: 10,
    elevation: 4
  },
  btnInsertarText: {
    color: 'white',
    fontWeight: 'bold',
    fontSize: 16
  },
  btnEnviar: {
    backgroundColor: MJM_BLUE,
    padding: 16,
    borderRadius: 10,
    alignItems: 'center'
  },
  btnEnviarText: {
    color: 'white',
    fontWeight: 'bold'
  },
  btnConfirmIOS: { 
    backgroundColor: MJM_BLUE, 
    padding: 12, 
    borderRadius: 10, 
    marginTop: 15, 
    width: '100%', 
    alignItems: 'center' 
  },
  btnTime: { 
    backgroundColor: MJM_BLUE, 
    padding: 10, 
    borderRadius: 10 
  },
  navContainer: { 
    flexDirection: 'row', 
    padding: 15, 
    gap: 12, 
    backgroundColor: 'white', 
    borderTopWidth: 1, 
    borderTopColor: '#eee' 
  },
  navBtn: { 
    flex: 1, 
    padding: 14, 
    borderRadius: 12, 
    alignItems: 'center', 
    borderWidth: 1.5, 
    borderColor: '#eee' 
  },

  // === TIEMPO Y BARRAS DE PROGRESO ===
  timeRow: { 
    flexDirection: 'row', 
    alignItems: 'center', 
    gap: 10 
  },
  timeText: { 
    fontSize: 16, 
    color: MJM_BLUE, 
    fontWeight: 'bold' 
  },
  progressTitle: { 
    fontSize: 16, 
    fontWeight: 'bold', 
    marginBottom: 15, 
    color: MJM_BLUE 
  },
  progressBarBackground: { 
    width: '100%', 
    height: 10, 
    backgroundColor: '#eee', 
    borderRadius: 5, 
    overflow: 'hidden' 
  },
  progressBarFill: { 
    height: '100%', 
    backgroundColor: MJM_BLUE 
  },
  progressPercentage: { 
    marginTop: 10, 
    fontSize: 12, 
    color: '#666', 
    fontWeight: 'bold' 
  },

  // === CÁMARA Y ADJUNTOS ===
  photoActions: { 
    flexDirection: 'row', 
    gap: 10, 
    marginTop: 20 
  },
  btnCamAction: { 
    flex: 1, 
    backgroundColor: '#444', 
    padding: 12, 
    borderRadius: 12, 
    flexDirection: 'row', 
    justifyContent: 'center', 
    alignItems: 'center', 
    gap: 8 
  },
  btnCamText: { 
    color: 'white', 
    fontSize: 12, 
    fontWeight: 'bold' 
  },
  photoCounter: { 
    fontSize: 10, 
    color: '#888', 
    marginTop: 8, 
    textAlign: 'right' 
  },
  photoCarousel: { 
    marginTop: 15 
  },
  photoWrapper: { 
    marginRight: 15, 
    position: 'relative' 
  },
  photoThumb: { 
    width: 80, 
    height: 80, 
    borderRadius: 12, 
    borderWidth: 1, 
    borderColor: '#ddd' 
  },
  removePhoto: { 
    position: 'absolute', 
    top: -8, 
    right: -8, 
    backgroundColor: 'white', 
    borderRadius: 12 
  },
  btnSave: { 
    backgroundColor: '#28a745', 
    padding: 15, 
    borderRadius: 12, 
    marginTop: 20, 
    alignItems: 'center', 
    width: '100%' 
  },

  // === VISTAS WEB (GRILLA TRIPLE COLUMNA) ===
  webHeader: {
    backgroundColor: MJM_BLUE,
    padding: 15,
    alignItems: 'center',
    elevation: 4,
  },
  webTitle: { 
    color: 'white', 
    fontWeight: 'bold', 
    fontSize: 18 
  },
  scrollWeb: { 
    padding: 20 
  },
  webGridContainer: {
    flexDirection: 'row', 
    justifyContent: 'center',
    gap: 20,
    alignItems: 'flex-start',
  },
  webColumn: {
    flex: 1, 
    height: 650,
    minWidth: 350, 
    padding: 15,
    marginHorizontal: 5, 
    backgroundColor: 'white',
    borderRadius: 12,
    borderWidth: 1,
    borderColor: '#e0e0e0',
    shadowColor: '#000',
    shadowOpacity: 0.1,
    shadowRadius: 10,
    elevation: 5,
    overflow: 'hidden',
  },
  headerStepWeb: {
    flexDirection: 'row',
    backgroundColor: MJM_BLUE,
    padding: 12,
    alignItems: 'center',
    gap: 10,
  },
  headerStepText: { 
    color: 'white', 
    fontWeight: 'bold', 
    fontSize: 14 
  },
  columnBody: { 
    padding: 15 
  },
  labelWeb: {
    fontSize: 11,
    fontWeight: 'bold',
    color: MJM_BLUE,
    marginBottom: 8,
    textTransform: 'uppercase',
  },
  webBtnSave: {
    backgroundColor: '#28a745',
    padding: 18,
    borderRadius: 8,
    marginTop: 20,
    alignItems: 'center',
  },
  webBtnSaveText: { 
    color: 'white', 
    fontWeight: 'bold', 
    fontSize: 15 
  },
  labelSmall: { 
    fontSize: 10, 
    fontWeight: 'bold', 
    marginTop: 10, 
    color: '#666' 
  },
  label: { 
    fontSize: 11, 
    fontWeight: 'bold', 
    marginTop: 15, 
    color: '#444' 
  },
  sectionTitle: { 
    fontSize: 14, 
    fontWeight: 'bold', 
    color: MJM_BLUE, 
    marginBottom: 15, 
    textAlign: 'center' 
  },
});