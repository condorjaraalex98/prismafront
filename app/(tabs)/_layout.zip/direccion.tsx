import { ThemedText } from '@/components/themed-text';
import { ThemedView } from '@/components/themed-view';
import { Ionicons } from '@expo/vector-icons';
import React, { useCallback, useEffect, useState } from 'react';
import {
    ActivityIndicator, Alert, FlatList, KeyboardAvoidingView,
    Modal, Platform, ScrollView, StyleSheet, TextInput, TouchableOpacity, View
} from 'react-native';
import { Dropdown } from 'react-native-element-dropdown';
import MapaSelector from '../../components/MapaSelector';

const MJM_BLUE = '#024885';
const API_URL = 'http://192.168.1.11:3000';

export default function LugaresScreen() {
    const [modalVisible, setModalVisible] = useState(false);
    const [modalMapaVisible, setModalMapaVisible] = useState(false);
    const [loading, setLoading] = useState(false);
    const [lugares, setLugares] = useState([]);
    const [catalogos, setCatalogos] = useState({ vias: [], cuadras: [], jv: [], pnp: [], tipos: [] });

    const [form, setForm] = useState({
        nombre_lugar: '', direccion: '', id_via: '', id_cuadra: '',
        id_jv_cuadrante: '', id_pnp_cuadrante: '', id_tipo_lugar: '',
        latitud: '-12.0463', longitud: '-77.0427'
    });

    const [mapRegion, setMapRegion] = useState({
        latitude: -12.0463, longitude: -77.0427,
        latitudeDelta: 0.005, longitudeDelta: 0.005,
    });

    // --- LÓGICA DE PEGADO DE COORDENADAS ---
    const manejarEntradaCoordenadas = (input: string, campo: 'lat' | 'lon') => {
        if (input.includes(',') || input.includes(' ')) {
            const partes = input.split(/[\s,]+/);
            if (partes.length >= 2) {
                setForm(prev => ({ ...prev, latitud: partes[0].trim(), longitud: partes[1].trim() }));
                return;
            }
        }
        setForm(prev => ({ ...prev, [campo === 'lat' ? 'latitud' : 'longitud']: input }));
    };

    // --- CARGA DE DATOS ---
    const fetchJSON = async (endpoint: string) => {
        try {
            const r = await fetch(`${API_URL}${endpoint}`);
            const contentType = r.headers.get("content-type");
            if (r.ok && contentType?.includes("application/json")) return await r.json();
            return [];
        } catch (e) { return []; }
    };

    const cargarTodo = useCallback(async () => {
        setLoading(true);
        const [l, v, c, j, p, t] = await Promise.all([
            fetchJSON('/lugares'), fetchJSON('/vias'), fetchJSON('/cuadras'),
            fetchJSON('/jv-cuadrantes'), fetchJSON('/pnp-cuadrantes'), fetchJSON('/tipos-lugar')
        ]);
        setLugares(l || []);
        setCatalogos({
            vias: v.map((x: any) => ({ label: x.nombre_via, value: x.id_via })),
            cuadras: c.map((x: any) => ({ label: `Cuadra ${x.numero_cuadra}`, value: x.id_cuadra })),
            jv: j.map((x: any) => ({ label: x.nombre_cuadrante, value: x.id_jv_cuadrante })),
            pnp: p.map((x: any) => ({ label: x.codigo_cuadrante, value: x.id_pnp_cuadrante })),
            tipos: t.map((x: any) => ({ label: x.nombre_tipo, value: x.id_tipo }))
        });
        setLoading(false);
    }, []);

    useEffect(() => { cargarTodo(); }, [cargarTodo]);

    // --- GUARDAR EN BD ---
    const guardarRegistro = async () => {
        if (!form.nombre_lugar || !form.id_via || !form.id_tipo_lugar) {
            Alert.alert("Aviso", "Por favor llene los campos obligatorios (*)");
            return;
        }

        try {
            setLoading(true);
            const res = await fetch(`${API_URL}/lugares`, {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({
                    ...form,
                    lat: parseFloat(form.latitud),
                    lon: parseFloat(form.longitud)
                })
            });
            if (res.ok) {
                setModalVisible(false);
                cargarTodo();
                Alert.alert("Éxito", "Lugar guardado correctamente");
            }
        } catch (e) {
            Alert.alert("Error", "No se pudo conectar con el servidor");
        } finally {
            setLoading(false);
        }
    };

    return (
        <ThemedView style={styles.main}>
            <View style={styles.header}>
                <ThemedText style={styles.headerTitle}>Gestión de Lugares</ThemedText>
                <TouchableOpacity onPress={() => setModalVisible(true)}>
                    <Ionicons name="add-circle" size={50} color="white" />
                </TouchableOpacity>
            </View>

            <FlatList
                data={lugares}
                keyExtractor={(item: any) => item.id_lugar?.toString()}
                renderItem={({ item }) => (
                    <View style={styles.card}>
                        <ThemedText style={{ fontWeight: 'bold' }}>{item.nombre_lugar}</ThemedText>
                        <ThemedText style={{ fontSize: 12, color: '#666' }}>{item.nombre_via} | {item.latitud}, {item.longitud}</ThemedText>
                    </View>
                )}
            />

            <Modal visible={modalVisible} animationType="slide">
                <KeyboardAvoidingView behavior={Platform.OS === 'ios' ? 'padding' : 'height'} style={{ flex: 1 }}>
                    <ScrollView contentContainerStyle={styles.form}>
                        <ThemedText style={styles.title}>Nuevo Registro</ThemedText>

                        <ThemedText style={styles.label}>DATOS GENERALES</ThemedText>
                        <TextInput style={styles.input} placeholder="Nombre del Lugar *" value={form.nombre_lugar} onChangeText={t => setForm({ ...form, nombre_lugar: t })} />
                        <Dropdown style={styles.input} data={catalogos.vias} labelField="label" valueField="value" placeholder="Vía Principal *" value={form.id_via} onChange={i => setForm({ ...form, id_via: i.value })} />

                        <View style={styles.row}>
                            <Dropdown style={[styles.input, { flex: 1, marginRight: 5 }]} data={catalogos.cuadras} labelField="label" valueField="value" placeholder="Cuadra" value={form.id_cuadra} onChange={i => setForm({ ...form, id_cuadra: i.value })} />
                            <TextInput style={[styles.input, { flex: 1 }]} placeholder="Nro / Mz / Lt" value={form.direccion} onChangeText={t => setForm({ ...form, direccion: t })} />
                        </View>

                        <ThemedText style={styles.label}>UBICACIÓN Y SEGURIDAD</ThemedText>
                       <Dropdown style={styles.input} data={catalogos.tipos} labelField="label" valueField="value" placeholder="Tipo de Establecimiento *" value={form.id_tipo_lugar} onChange={i => setForm({ ...form, id_tipo_lugar: i.value })} />

                        <ThemedText style={styles.label}>COORDENADAS (Pega aquí la ubicación completa)</ThemedText>
                        <View style={styles.row}>
                            <TextInput style={[styles.input, { flex: 1, marginRight: 5 }]} placeholder="Lat" value={form.latitud} onChangeText={t => manejarEntradaCoordenadas(t, 'lat')} keyboardType={Platform.OS === 'web' ? 'numeric' : 'default'} />
                            <TextInput style={[styles.input, { flex: 1 }]} placeholder="Lon" value={form.longitud} onChangeText={t => manejarEntradaCoordenadas(t, 'lon')} keyboardType={Platform.OS === 'web' ? 'numeric' : 'default'} />
                        </View>

                        {Platform.OS === 'web' && (
                            <TouchableOpacity style={styles.btnMap} onPress={() => setModalMapaVisible(true)}>
                                <Ionicons name="map" size={20} color="white" />
                                <ThemedText style={{ color: 'white', marginLeft: 10 }}>SELECCIONAR EN MAPA</ThemedText>
                            </TouchableOpacity>
                        )}

                        <View style={styles.footer}>
                            <TouchableOpacity style={styles.btnSave} onPress={guardarRegistro} disabled={loading}>
                                {loading ? <ActivityIndicator color="white" /> : <ThemedText style={{ color: 'white', fontWeight: 'bold' }}>GUARDAR</ThemedText>}
                            </TouchableOpacity>
                            <TouchableOpacity style={styles.btnCancel} onPress={() => setModalVisible(false)}>
                                <ThemedText>CERRAR</ThemedText>
                            </TouchableOpacity>
                        </View>
                    </ScrollView>
                </KeyboardAvoidingView>
            </Modal>

            <Modal visible={modalMapaVisible} animationType="fade">
                <View style={{ flex: 1 }}>
                    <MapaSelector region={mapRegion} setRegion={setMapRegion} />
                    <View style={styles.mapActions}>
                        <TouchableOpacity style={styles.btnConfirm} onPress={() => {
                            setForm({ ...form, latitud: mapRegion.latitude.toFixed(6), longitud: mapRegion.longitude.toFixed(6) });
                            setModalMapaVisible(false);
                        }}>
                            <ThemedText style={{ color: 'white', fontWeight: 'bold' }}>CONFIRMAR PUNTO</ThemedText>
                        </TouchableOpacity>
                        <TouchableOpacity style={styles.btnBack} onPress={() => setModalMapaVisible(false)}>
                            <ThemedText>VOLVER</ThemedText>
                        </TouchableOpacity>
                    </View>
                </View>
            </Modal>
        </ThemedView>
    );
}

const styles = StyleSheet.create({
    main: { flex: 1, backgroundColor: '#F8FAFC' },
    header: { backgroundColor: MJM_BLUE, padding: 25, paddingTop: 50, flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center' },
    headerTitle: { color: 'white', fontSize: 20, fontWeight: 'bold' },
    card: { backgroundColor: 'white', margin: 10, padding: 15, borderRadius: 12, elevation: 2 },
    form: { padding: 20 },
    title: { fontSize: 22, fontWeight: 'bold', color: MJM_BLUE, marginBottom: 20 },
    label: { fontSize: 10, fontWeight: 'bold', color: '#94A3B8', marginTop: 15, marginBottom: 5 },
    input: { backgroundColor: 'white', padding: 12, borderRadius: 10, marginBottom: 10, borderWidth: 1, borderColor: '#E2E8F0' },
    row: { flexDirection: 'row' },
    btnMap: { backgroundColor: '#64748B', padding: 15, borderRadius: 10, flexDirection: 'row', justifyContent: 'center' },
    footer: { marginTop: 30, flexDirection: 'row-reverse', justifyContent: 'space-between', alignItems: 'center' },
    btnSave: { backgroundColor: MJM_BLUE, padding: 15, borderRadius: 10, width: '60%', alignItems: 'center' },
    btnCancel: { padding: 15 },
    mapActions: { position: 'absolute', bottom: 30, width: '100%', alignItems: 'center' },
    btnConfirm: { backgroundColor: MJM_BLUE, padding: 20, borderRadius: 30 },
    btnBack: { marginTop: 10, backgroundColor: 'white', padding: 10, borderRadius: 20 }
});