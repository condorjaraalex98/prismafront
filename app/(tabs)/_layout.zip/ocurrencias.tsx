import React, { useCallback, useEffect, useMemo, useRef, useState } from 'react';
import {
    Dimensions, FlatList, Platform, RefreshControl, StyleSheet,
    TextInput,
    TouchableOpacity, View
} from 'react-native';
import { SafeAreaProvider, SafeAreaView } from 'react-native-safe-area-context';

// IMPORTACIÓN ULTRA-SEGURA: Solo cargamos WebView si no es Web.
const WebView = Platform.OS !== 'web' ? require('react-native-webview').WebView : null;

import { ThemedText } from '@/components/themed-text';
import { Ionicons } from '@expo/vector-icons';

const MJM_BLUE = '#024885';

export default function PuntostScreen() {
    const isDesktop = Dimensions.get('window').width > 768;
    const [ocurrencias, setOcurrencias] = useState<any[]>([]);
    const [refreshing, setRefreshing] = useState(false);
    const [mapaExpandido, setMapaExpandido] = useState(false);
    
    // Fechas en formato texto YYYY-MM-DD (Universal para Web y Móvil)
    const [fechaInicio, setFechaInicio] = useState(new Date().toISOString().split('T')[0]);
    const [fechaFin, setFechaFin] = useState(new Date().toISOString().split('T')[0]);

    const mapRef = useRef<any>(null);

    const cargarDatos = useCallback(async () => {
        setRefreshing(true);
        try {
            const response = await fetch('http://192.168.1.11:3000/ocurrencias');
            const data = await response.json();
            if (!Array.isArray(data)) return;

            const ahora = new Date().getTime();
            const hoyStr = new Date().toISOString().split('T')[0];

            const filtrados = data.filter(item => {
                const fItem = new Date(item.fecha);
                const fItemStr = fItem.toISOString().split('T')[0];
                const estaEnRango = fItemStr >= fechaInicio && fItemStr <= fechaFin;
                const esFiltroHoy = (fechaInicio === hoyStr && fechaFin === hoyStr);
                const esReciente = (ahora - fItem.getTime()) < (24 * 60 * 60 * 1000);

                return esFiltroHoy ? esReciente : estaEnRango;
            });
            setOcurrencias(filtrados);
        } catch (error) { console.error("Error API:", error); }
        finally { setRefreshing(false); }
    }, [fechaInicio, fechaFin]);

    useEffect(() => { cargarDatos(); }, [cargarDatos]);

    const seleccionarDesdeTabla = (item: any) => {
        const script = `if(window.map && markers["${item.id}"]){ map.flyTo([${item.latitud}, ${item.longitud}], 18); markers["${item.id}"].openPopup(); } true;`;
        if (Platform.OS === 'web') {
            mapRef.current?.contentWindow?.postMessage(script, '*');
        } else if (mapRef.current) {
            mapRef.current.injectJavaScript(script);
        }
    };

    const mapHTML = useMemo(() => {
        const puntosJS = JSON.stringify(ocurrencias);
        return `
            <!DOCTYPE html><html><head>
            <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no" />
            <link rel="stylesheet" href="https://unpkg.com/leaflet@1.9.4/dist/leaflet.css" />
            <script src="https://unpkg.com/leaflet@1.9.4/dist/leaflet.js"></script>
            <style>
                body, html, #map { height: 100vh; width: 100vw; margin: 0; padding: 0; }
                .emoji-icon { font-size: 28px; text-align: center; line-height: 1; }
            </style></head>
            <body><div id="map"></div><script>
                var map = L.map('map', { zoomControl: false }).setView([-12.046, -77.042], 13);
                L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png').addTo(map);
                var markers = {};
                window.addEventListener('message', function(e){ eval(e.data); });
                document.addEventListener('message', function(e){ eval(e.data); });

                function getEmoji(mod) {
                    if (!mod) return '📍';
                    var m = mod.toUpperCase();
                    if (m.includes('VIVIENDA')) return '🏠';
                    if (m.includes('HERIDO')) return '🚑';
                    if (m.includes('ROBO')) return '💸';
                    return '📍';
                }

                JSON.parse('${puntosJS}').forEach(function(o){
                    var icon = L.divIcon({ 
                        html: '<div class="emoji-icon">' + getEmoji(o.modalidad) + '</div>', 
                        className: '', iconSize: [35, 35] 
                    });
                    var m = L.marker([o.latitud, o.longitud], {icon: icon}).addTo(map);
                    m.bindPopup("<b>"+(o.modalidad || 'Ocurrencia')+"</b><br>"+o.lugar);
                    markers[o.id] = m;
                });
            </script></body></html>
        `;
    }, [ocurrencias]);

    return (
        <SafeAreaProvider>
            <SafeAreaView style={styles.container} edges={['top', 'left', 'right']}>
                <View style={isDesktop ? styles.layoutDesktop : styles.layoutMobile}>
                    
                    {(!mapaExpandido || isDesktop) && (
                        <View style={styles.listSide}>
                            <View style={styles.filterPanel}>
                                <ThemedText style={styles.filterTitle}>Producción</ThemedText>
                                <View style={styles.dateRow}>
                                    <View style={styles.dateBox}>
                                        <ThemedText style={styles.label}>Inicio</ThemedText>
                                        <TextInput 
                                            style={styles.inputDate}
                                            value={fechaInicio}
                                            onChangeText={setFechaInicio}
                                            {...(Platform.OS === 'web' ? { type: 'date' } : { placeholder: 'YYYY-MM-DD' })}
                                        />
                                    </View>
                                    <View style={styles.dateBox}>
                                        <ThemedText style={styles.label}>Fin</ThemedText>
                                        <TextInput 
                                            style={styles.inputDate}
                                            value={fechaFin}
                                            onChangeText={setFechaFin}
                                            {...(Platform.OS === 'web' ? { type: 'date' } : { placeholder: 'YYYY-MM-DD' })}
                                        />
                                    </View>
                                </View>
                            </View>

                            <FlatList
                                data={ocurrencias}
                                keyExtractor={(item) => item.id.toString()}
                                renderItem={({ item }) => (
                                    <TouchableOpacity style={styles.card} onPress={() => seleccionarDesdeTabla(item)}>
                                        <View style={styles.cardHeader}>
                                            <Ionicons name="location-sharp" size={14} color={MJM_BLUE} />
                                            <ThemedText style={styles.cardTag}>{item.modalidad}</ThemedText>
                                        </View>
                                        <ThemedText numberOfLines={1} style={styles.cardLugar}>{item.lugar}</ThemedText>
                                        <ThemedText style={styles.cardFooter}>{new Date(item.fecha).toLocaleString()}</ThemedText>
                                    </TouchableOpacity>
                                )}
                                refreshControl={<RefreshControl refreshing={refreshing} onRefresh={cargarDatos} />}
                            />
                        </View>
                    )}

                    <View style={[styles.mapSide, mapaExpandido && styles.mapExpanded]}>
                        {Platform.OS === 'web' ? (
                            <iframe ref={mapRef} srcDoc={mapHTML} style={styles.webMap as any} />
                        ) : (
                            WebView && <WebView key={ocurrencias.length} ref={mapRef} source={{ html: mapHTML }} style={{ flex: 1 }} javaScriptEnabled />
                        )}
                        <TouchableOpacity style={styles.expandBtn} onPress={() => setMapaExpandido(!mapaExpandido)}>
                            <Ionicons name={mapaExpandido ? "contract" : "expand"} size={24} color="white" />
                        </TouchableOpacity>
                    </View>
                </View>
            </SafeAreaView>
        </SafeAreaProvider>
    );
}

const styles = StyleSheet.create({
    container: { flex: 1, backgroundColor: '#fff' },
    layoutDesktop: { flex: 1, flexDirection: 'row' },
    layoutMobile: { flex: 1, flexDirection: 'column' },
    listSide: { flex: 1.5 },
    mapSide: { flex: 1, position: 'relative', borderTopWidth: 1, borderTopColor: '#eee' },
    mapExpanded: { flex: 10 },
    filterPanel: { padding: 15, backgroundColor: '#f9f9f9', borderBottomWidth: 1, borderBottomColor: '#eee' },
    filterTitle: { fontWeight: 'bold', color: MJM_BLUE, marginBottom: 10 },
    dateRow: { flexDirection: 'row', gap: 10 },
    dateBox: { flex: 1 },
    label: { fontSize: 10, color: '#888', marginBottom: 4 },
    inputDate: { 
        backgroundColor: '#fff', 
        padding: 10, 
        borderRadius: 8, 
        borderWidth: 1, 
        borderColor: '#ddd', 
        fontSize: 14,
        color: '#333'
    },
    card: { padding: 12, marginHorizontal: 15, marginTop: 10, backgroundColor: '#fff', borderRadius: 8, borderLeftWidth: 4, borderLeftColor: MJM_BLUE, elevation: 2 },
    cardHeader: { flexDirection: 'row', alignItems: 'center', gap: 5 },
    cardTag: { fontWeight: 'bold', color: MJM_BLUE },
    cardLugar: { fontSize: 13, color: '#444' },
    cardFooter: { fontSize: 10, color: '#999', marginTop: 4 },
    expandBtn: { position: 'absolute', top: 10, right: 10, backgroundColor: MJM_BLUE, width: 44, height: 44, borderRadius: 22, justifyContent: 'center', alignItems: 'center', zIndex: 99 },
    webMap: { width: '100%', height: '100%', borderWidth: 0 }
});