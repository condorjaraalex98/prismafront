import { Ionicons } from '@expo/vector-icons';
import React, { useCallback, useEffect, useMemo, useState } from 'react';
import * as XLSX from 'xlsx';

// CONFIGURACIÓN DE TIPOS E IMPORTACIÓN PARA EXPORTAR PDF
import { jsPDF as jsPDFType } from 'jspdf';
import autoTable from 'jspdf-autotable';
const jsPDF = require('jspdf/dist/jspdf.es.min.js').jsPDF;

// Hook de autenticación global
import { useAuth } from '../../context/userContext';

// Modales de inserción de registros
import RegistroRedes from './modalredes';
import RegistroOcurrenciat from './modaltele';
import RegistroOcurrencia from './modalvvcam';

const MJM_BLUE = '#024885';

interface Ocurrencia {
  id_ocurrencia: number | string;
  fecha_reporte: string;
  distancia_metros?: number;
  placa_con_tipo?: string;
  tipo_asignacion?: string;
  codigo_seguimiento?: string;
  origen_descripcion?: string;
  fecha_evento: string;
  hora_alerta?: string;
  hora_llegada?: string;
  hora_repliegue?: string;
  ocurrencia_descripcion?: string;
  nombre_lugar?: string;
  unidad_encargada?: string;
  referencia?: string;
  persona_nombre_completo: string;
  persona_dni: string;
  modalidad_nombre: string;
  via_nombre?: string;
  cuadra?: string | number;
  tipo_patrullaje_nombre?: string;
  mod_patrullaje_nombre?: string;
  value?: number;
  label?: string;
  total_fotos?: number;
  foto_principal?: string;
  descripcion?: string;
}

export default function ReportesWebScreen() {
  const { userData } = useAuth(); 

  // ESTADOS PRINCIPALES
  const [reportesCompletos, setReportesCompletos] = useState<Ocurrencia[]>([]);
  const [filtro, setFiltro] = useState<'TODOS' | 'MIOS'>('TODOS');
  const [paginaActual, setPaginaActual] = useState(1);
  const [registrosPorPagina, setRegistrosPorPagina] = useState(10); // Selector dinámico
  const [modalInsertOpen, setModalInsertOpen] = useState<string | null>(null);
  const [detalleSeleccionado, setDetalleSeleccionado] = useState<Ocurrencia | null>(null);

  // OBTENCIÓN DE DATOS DESDE LA API
  const fetchOcurrencias = useCallback(async () => {
    try {
      const response = await fetch('http://192.168.1.11:3000/ocurrencias/listar/tabla');
      const data = await response.json();
      setReportesCompletos(data || []);
    } catch (error) {
      console.error("Error al obtener datos operativos:", error);
    }
  }, []);

  useEffect(() => { 
    fetchOcurrencias(); 
  }, [fetchOcurrencias]);
// Inyecta el efecto hover de forma global y eficiente para la tabla
useEffect(() => {
  const estiloHover = document.createElement("style");
  estiloHover.innerText = `
    .fila-tabla-operativa:hover {
      background-color: #f1f5f9 !important; /* Color gris sutil de resalte */
      transition: background-color 0.15s ease-in-out;
    }
  `;
  document.head.appendChild(estiloHover);
  return () => { document.head.removeChild(estiloHover); };
}, []);
  // CERRAR MODAL CON ESCAPE
  useEffect(() => {
    const handleKeyDown = (event: KeyboardEvent) => {
      if (event.key === 'Escape') setDetalleSeleccionado(null);
    };
    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, []);

  // CONTROLADORES DE CAMBIOS
  const handleCambioFiltro = (nuevoFiltro: 'TODOS' | 'MIOS') => {
    setFiltro(nuevoFiltro);
    setPaginaActual(1); 
  };

  // FORMATEADORES DE FECHAS
  const formatearFechaConDia = (fechaStr: string) => {
    if (!fechaStr) return 'S/F';
    const fechaLimpia = String(fechaStr).includes('-') ? String(fechaStr).replace(/-/g, '/') : fechaStr;
    const fechaObjReal = new Date(fechaLimpia);
    if (isNaN(fechaObjReal.getTime())) return fechaStr;

    const diaSemana = fechaObjReal.toLocaleDateString('es-PE', { weekday: 'short' }).replace('.', '').toLowerCase();
    const fechaNumerica = fechaObjReal.toLocaleDateString('es-PE');
    return `${diaSemana} ${fechaNumerica}`;
  };

  const extraerFechaYHoraLimpia = (fechaIsoStr: string) => {
    if (!fechaIsoStr) return { dia: 'S/D', fecha: 'S/F', hora: 'S/H' };
    const formateada = new Date(fechaIsoStr);
    if (isNaN(formateada.getTime())) return { dia: 'S/D', fecha: fechaIsoStr, hora: 'S/H' };

    const dia = formateada.toLocaleDateString('es-PE', { weekday: 'short' }).replace('.', '').toLowerCase();
    const fecha = formateada.toLocaleDateString('es-PE');
    const hora = formateada.toLocaleTimeString('es-PE', { hour: '2-digit', minute: '2-digit', hour12: false });
    
    return { dia, fecha, hora };
  };

  // LÓGICA DE CONTADORES Y FILTRADO (MEMOIZADA)
  const totalTodos = reportesCompletos.length;
  
  const totalMios = useMemo(() => {
    const miNombreLower = String(userData?.nombres || '').toLowerCase().trim();
    if (!miNombreLower) return 0;
    return reportesCompletos.filter(item => 
      String(item.persona_nombre_completo || '').toLowerCase().includes(miNombreLower)
    ).length;
  }, [reportesCompletos, userData]);

  const reportesFiltrados = useMemo(() => {
    if (!reportesCompletos) return [];
    if (filtro === 'MIOS') {
      const miNombreLower = String(userData?.nombres || '').toLowerCase().trim();
      return reportesCompletos.filter(item => {
        const nombreCompletoReporte = String(item.persona_nombre_completo || '').toLowerCase();
        return nombreCompletoReporte.includes(miNombreLower) && miNombreLower !== '';
      });
    }
    return reportesCompletos;
  }, [reportesCompletos, filtro, userData]);

  // PAGINACIÓN DINÁMICA ADAPTATIVA
  const totalPaginas = useMemo(() => {
    const paginas = Math.ceil(reportesFiltrados.length / registrosPorPagina);
    return paginas > 0 ? paginas : 1;
  }, [reportesFiltrados, registrosPorPagina]);

  const datosPaginados = useMemo(() => {
    const inicio = (paginaActual - 1) * registrosPorPagina;
    const fin = inicio + registrosPorPagina;
    return reportesFiltrados.slice(inicio, fin);
  }, [reportesFiltrados, paginaActual, registrosPorPagina]);

  // EXPORTACIONES COMPLETA DE REPORTES
  const exportarExcel = () => {
    const dataParaExcel = reportesFiltrados.map(item => {
      const registro = extraerFechaYHoraLimpia(item.fecha_reporte);
      const sucesoReal = extraerFechaYHoraLimpia(item.fecha_evento);
      return {
        'ID REPORTE': item.id_ocurrencia,
        'REGISTRO DIA': registro.dia,
        'REGISTRO FECHA': registro.fecha,
        'REGISTRO HORA': registro.hora,
        'OPERADOR NOMBRE': item.persona_nombre_completo,
        'OPERADOR DNI': item.persona_dni,
        'ORIGEN ALERTA': item.origen_descripcion || '---',
        'TIPO PATRULLAJE': item.tipo_patrullaje_nombre || '---',
        'ASIGNACION PLACA': item.placa_con_tipo || '---',
        'MODALIDAD': item.modalidad_nombre,
        'DISTANCIA METROS': item.distancia_metros || 0,
        'SUCESO DIA': sucesoReal.dia,
        'SUCESO FECHA': sucesoReal.fecha,
        'SUCESO HORA': item.hora_llegada || registro.hora,
        'UBICACIÓN PRINCIPAL': item.label || item.via_nombre || '---',
        'REFERENCIA': item.referencia || 'Sin referencia',
        'COD SEGUIMIENTO': item.codigo_seguimiento || '---'
      };
    });

    const ws = XLSX.utils.json_to_sheet(dataParaExcel);
    const wb = XLSX.utils.book_new();
    XLSX.utils.book_append_sheet(wb, ws, "Historial_Operativo");
    XLSX.writeFile(wb, `Reporte_Central_${Date.now()}.xlsx`);
  };

  const exportarPDF = () => {
    const doc = new jsPDF({ orientation: 'landscape' }) as jsPDFType;
    doc.setFontSize(14);
    doc.setTextColor(2, 72, 133);
    doc.text("HISTORIAL OPERATIVO DE SEGURIDAD CIUDADANA", 14, 14);
    
    const tablaData = reportesFiltrados.map(item => {
      const reg = extraerFechaYHoraLimpia(item.fecha_reporte);
      const suc = extraerFechaYHoraLimpia(item.fecha_evento);
      return [
        item.id_ocurrencia,
        `${reg.dia} ${reg.fecha} ${reg.hora}`,
        item.persona_nombre_completo,
        `${item.tipo_patrullaje_nombre || '---'} | ${item.origen_descripcion || '---'}`,
        item.modalidad_nombre,
        `${suc.dia} ${suc.fecha} - ${item.hora_llegada || 'S/H'}`,
        item.label || item.via_nombre || '---'
      ];
    });

    autoTable(doc, {
      head: [['ID', 'FECHA REGISTRO', 'PERSONAL OPERADOR', 'ORIGEN / ASIGNACIÓN', 'MODALIDAD', 'FECHA OCURRENCIA', 'DIRECCIÓN UBICACIÓN']],
      body: tablaData,
      startY: 22,
      headStyles: { fillColor: [2, 72, 133], fontSize: 8, fontStyle: 'bold' },
      theme: 'grid',
      styles: { fontSize: 8, cellPadding: 3 }
    });

    doc.save(`Reporte_Operativo_${Date.now()}.pdf`);
  };

  return (
    <div style={styles.container}>
      {/* Accesos Rápidos */}
      <div style={styles.grid}>
        <button onClick={() => setModalInsertOpen('camara')} style={{...styles.card, backgroundColor: MJM_BLUE}}>
          <Ionicons name="videocam" size={26} color="white" />
          <div style={styles.cardLab}>CÁMARA</div>
        </button>
        <button onClick={() => setModalInsertOpen('telefono')} style={{...styles.card, backgroundColor: MJM_BLUE}}>
          <Ionicons name="call" size={26} color="white" />
          <div style={styles.cardLab}>TELÉFONO</div>
        </button>
        <button onClick={() => setModalInsertOpen('redes')} style={{...styles.card, backgroundColor: MJM_BLUE}}>
          <Ionicons name="alert-circle" size={26} color="white" />
          <div style={styles.cardLab}>PÁNICO</div>
        </button>
        <button onClick={() => setModalInsertOpen('redes')} style={{...styles.card, backgroundColor: MJM_BLUE}}>
          <Ionicons name="share-social" size={26} color="white" />
          <div style={styles.cardLab}>REDES</div>
        </button>
      </div>

      {/* Cabecera Principal */}
      <div style={styles.header}>
        <div style={{ display: 'flex', alignItems: 'center', gap: '15px' }}>
          <h2 style={{ color: MJM_BLUE, margin: 0, fontWeight: 700, fontSize: '22px' }}>Historial Operativo</h2>
          <button onClick={exportarExcel} style={{...styles.btnExport, backgroundColor: MJM_BLUE}}>
            <Ionicons name="document-text" size={16} color="white" /> Excel
          </button>
          <button onClick={exportarPDF} style={{...styles.btnExport, backgroundColor: MJM_BLUE}}>
            <Ionicons name="download" size={16} color="white" /> PDF
          </button>
        </div>

        <div style={styles.tabs}>
          <button onClick={() => handleCambioFiltro('TODOS')} style={filtro === 'TODOS' ? styles.tabActive : styles.tab}>
            TODO ({totalTodos})
          </button>
          <button onClick={() => handleCambioFiltro('MIOS')} style={filtro === 'MIOS' ? styles.tabActive : styles.tab}>
            MIS REGISTROS ({totalMios})
          </button>
        </div>
      </div>

      {/* Caja de Datos y Estructura Automatizada de la Tabla */}
      <div style={styles.tableCard}>
        <div style={styles.tableScrollContainer}>
          <table style={styles.table}>
            <thead>
              <tr style={styles.thead}>
                <th style={{...styles.th, width: '7%',textAlign: 'center'}}>FECHA REGISTRO</th>
                <th style={{...styles.th, width: '18%',textAlign: 'center'}}>PERSONAL</th>
                <th style={{...styles.th, width: '15%',textAlign: 'center'}}>ORIGEN</th>
                <th style={{...styles.th, width: '25%',textAlign: 'center'}}>MODALIDAD</th>
                <th style={{...styles.th, width: '7%',textAlign: 'center'}}>FECHA EVENTO</th>
                <th style={{...styles.th, width: '17%',textAlign: 'center'}}>UBICACIÓN</th>
                <th style={{...styles.th, width: '5%',textAlign: 'center'}}>FOTO</th>
              </tr>
            </thead>
            <tbody>
              {datosPaginados.map((item) => (
              <tr 
  key={item.id_ocurrencia} 
  className="fila-tabla-operativa" // <-- Añades esta clase aquí
  style={styles.tr} 
  onClick={() => setDetalleSeleccionado(item)}
>
                  {/* Celda 1: Fecha Registro */}
                  <td style={styles.td}>
                    <div style={styles.celdaTruncadaContainer}>
                      <div style={styles.txtB}>
                        {item.fecha_reporte ? (
                          (() => {
                            const fechaObj = new Date(item.fecha_reporte);
                            const diaSemana = fechaObj.toLocaleDateString('es-PE', { weekday: 'short' }).replace('.', '').toLowerCase();
                            const fechaNumerica = fechaObj.toLocaleDateString('es-PE');
                            return `${diaSemana} ${fechaNumerica}`;
                          })()
                        ) : (
                          item.fecha_evento || 'S/F'
                        )}
                      </div>
                      <div style={styles.txtS}>
                        {item.fecha_reporte ? new Date(item.fecha_reporte).toLocaleTimeString('es-PE', {hour: '2-digit', minute: '2-digit', hour12: false}) : 'S/H'}
                      </div>
                    </div>    
                  </td>
            
                  {/* Celda 2: Personal */}
                  <td style={styles.td}>
                    <div style={styles.celdaTruncadaContainer}>
                      <div style={styles.txtB} title={item.persona_nombre_completo}>{item.persona_nombre_completo}</div>
                      <div style={styles.txtS}>DNI: {item.persona_dni}</div>
                    </div>
                  </td>

                  {/* Celda 3: Origen */}
                  <td style={styles.td}>
                    <div style={styles.celdaTruncadaContainer}>
                      <div style={styles.txtB} title={item.tipo_patrullaje_nombre || '---'}>
                        {item.tipo_patrullaje_nombre || '---'}
                      </div>
                      <div style={{...styles.txtS, color: '#024885', fontWeight: '500'}} title={item.origen_descripcion}>
                        {item.origen_descripcion}
                      </div>
                      <div style={{...styles.txtS, color: '#024885', fontWeight: '500'}} title={item.placa_con_tipo}>
                        {item.placa_con_tipo}
                      </div>
                    </div>
                  </td>
                  
                  {/* Celda 4: Modalidad con Autoajuste */}
                
                    <td style={styles.td}>
<span style={{
  ...styles.badge, 
  backgroundColor: (() => {
    const mod = String(item.modalidad_nombre || '').toUpperCase();
    
    if (mod.includes('CUADERNO')) return '#dc2626';           // Rojo vivo
    if (mod.includes('TACTICO')) return '#024885';            // Azul Rey
    if (mod.includes('PROTECCIÓN ESCOLAR')) return '#eab308'; // Amarillo/Dorado visible en web
    
    return '#f1f5f9'; // Plomo sutil por defecto (Slate 100) para otros casos
  })(),
  color: (() => {
    const mod = String(item.modalidad_nombre || '').toUpperCase();
    
    // Si es Protección Escolar, usamos letras oscuras
    if (mod.includes('PROTECCIÓN ESCOLAR')) return '#1e293b';
    
    // SOLUCCIÓN: Si cae en el plomo por defecto, le ponemos letras gris oscuro/negro para que resalte
    if (!mod.includes('CUADERNO') && !mod.includes('TACTICO')) return '#475569';
    
    // Para Cuaderno y Táctico se mantiene texto blanco
    return 'white';
  })(),
  fontWeight: '700' // <-- Forza a que todas las letras del badge sean negritas
}}>
  {item.modalidad_nombre}
</span>
  
  {/* Renderizado condicional de la distancia con color dinámico si supera los 50m */}
{/* REEMPLAZO ACTUALIZADO CON PROTECCIÓN, TÁCTICO Y CUADERNO */}
{((String(item.modalidad_nombre || '').toUpperCase().includes('PROTECCIÓN')) || 
  (String(item.modalidad_nombre || '').toUpperCase().includes('TÁCTICO')) ||
  (String(item.modalidad_nombre || '').toUpperCase().includes('CUADERNO'))) && item.distancia_metros ? (
  <div style={{
    ...styles.txtS, 
    color: (() => {
      const mod = String(item.modalidad_nombre || '').toUpperCase();
      const distancia = Number(item.distancia_metros || 0);

      // Si es Protección Escolar, mantiene su color oscuro sutil
      if (mod.includes('PROTECCIÓN ESCOLAR')) return '#1e293b';
      
      // Si supera el límite de 50 metros en las otras modalidades
      if (distancia > 50) return '#024885'; 

      // Plomo sutil por defecto
      return '#94a3b8'; 
    })(),
    fontWeight: (() => {
      const mod = String(item.modalidad_nombre || '').toUpperCase();
      const distancia = Number(item.distancia_metros || 0);

      // Negrita (peso 700) si es Protección Escolar o si excede los 50 metros
      if (mod.includes('PROTECCIÓN ESCOLAR') || distancia > 50) return '700';
      
      return 'normal';
    })(),
    marginTop: '2px'
  }}>
    {`(${item.distancia_metros}m)`}
  </div>
) : null}
</td>

                  {/* Celda 5: Fecha Evento */}
                  <td style={styles.td}>
                    <div style={styles.celdaTruncadaContainer}>
                      <div style={styles.txtB}>{formatearFechaConDia(item.fecha_evento)}</div>
                      <div style={styles.txtS}>{item.hora_llegada || 'S/H'}</div>
                    </div>
                  </td>
                  
                  {/* Celda 6: Ubicación */}
                  <td style={styles.td}>
                    <div style={styles.celdaTruncadaContainer}>
                      <div style={styles.txtB} title={item.label || item.via_nombre || '---'}>
                        {item.label || item.via_nombre || '---'}
                      </div>
                      <div style={styles.txtS} title={item.referencia || 'Sin referencia'}>
                        Ref: {item.referencia || 'Sin referencia'}
                      </div>
                    </div>
                  </td>
                  
                  {/* Celda 7: Foto */}
                  <td style={styles.td}>
                    {item.foto_principal ? (
                      <div style={{position: 'relative', width: '42px', height: '42px'}}>
                        <img src={item.foto_principal} style={styles.img} alt="img" />
                        {Number(item.total_fotos) > 1 && (
                          <span style={styles.photoCountBadge}>+{Number(item.total_fotos) - 1}</span>
                        )}
                      </div>
                    ) : "---"}
                  </td>

                </tr>
              ))}
              {datosPaginados.length === 0 && (
                <tr>
                  <td colSpan={7} style={{...styles.td, textAlign: 'center', color: '#94a3b8', padding: '40px'}}>
                    No se encontraron registros operativos guardados bajo este filtro.
                  </td>
                </tr>
              )}
            </tbody>
          </table>
        </div>

        {/* CONTENEDOR DE PAGINACIÓN COMPLETO CON SELECTOR DE FILAS */}
        <div style={styles.tableFooterPagination}>
          <div style={{ display: 'flex', alignItems: 'center', gap: '8px', marginRight: 'auto' }}>
            <span style={{ fontSize: '12px', color: '#475569', fontWeight: '600' }}>Mostrar:</span>
            <select 
              value={registrosPorPagina} 
              onChange={(e) => {
                setRegistrosPorPagina(Number(e.target.value));
                setPaginaActual(1); 
              }}
              style={styles.selectRows}
            >
              <option value={10}>10 registros</option>
              <option value={25}>25 registros</option>
              <option value={50}>50 registros</option>
              <option value={100}>100 registros</option>
            </select>
          </div>

          <div style={styles.paginationFlex}>
            <button 
              disabled={paginaActual === 1} 
              onClick={() => setPaginaActual(p => Math.max(p - 1, 1))} 
              style={styles.btnPageNew}
            >
              <Ionicons name="chevron-back" size={15} color={paginaActual === 1 ? '#cbd5e1' : '#334155'} />
            </button>
            
            <div style={styles.pageInfoWrapper}>
              Página {paginaActual} de {totalPaginas}
            </div>
            
            <button 
              disabled={paginaActual >= totalPaginas} 
              onClick={() => setPaginaActual(p => Math.min(p + 1, totalPaginas))} 
              style={styles.btnPageNew}
            >
              <Ionicons name="chevron-forward" size={15} color={paginaActual >= totalPaginas ? '#cbd5e1' : '#334155'} />
            </button>
          </div>
        </div>
      </div>

      {/* MODAL DETALLE DE REGISTRO ACTIVO */}
      {detalleSeleccionado && (
        <div style={styles.overlay} onClick={() => setDetalleSeleccionado(null)}>
          <div style={styles.modalDetail} onClick={e => e.stopPropagation()}>
            <div style={styles.modalHeader}>
              <h3 style={{margin:0, color: MJM_BLUE, fontWeight: 700}}>Ficha Operativa #{detalleSeleccionado.id_ocurrencia}</h3>
              <button onClick={() => setDetalleSeleccionado(null)} style={styles.btnClose}>✕</button>
            </div>
            
            <div style={styles.modalBodyScrollable}>
              <div style={styles.modalGridDobleFila}>
                
                <div style={styles.infoRowGrid}>
                  <span style={styles.infoLabel}>Personal:</span>
                  <span style={styles.infoValue}>{detalleSeleccionado.persona_nombre_completo} ({detalleSeleccionado.persona_dni})</span>
                </div>
                <div style={styles.infoRowGrid}>
                  <span style={styles.infoLabel}>Modalidad:</span>
                  <span style={{...styles.infoValue, fontWeight: '700', color: '#024885'}}>{detalleSeleccionado.modalidad_nombre}</span>
                </div>

                <div style={styles.infoRowGrid}>
                  <span style={styles.infoLabel}>Unidad / Placa:</span>
                  <span style={styles.infoValue}>{detalleSeleccionado.placa_con_tipo || '---'}</span>
                </div>
                <div style={styles.infoRowGrid}>
                  <span style={styles.infoLabel}>Asignación:</span>
                  <span style={styles.infoValue}>{detalleSeleccionado.tipo_asignacion || '---'}</span>
                </div>

                <div style={styles.infoRowGrid}>
                  <span style={styles.infoLabel}>Origen Alerta:</span>
                  <span style={styles.infoValue}>{detalleSeleccionado.origen_descripcion || '---'}</span>
                </div>
                <div style={styles.infoRowGrid}>
                  <span style={styles.infoLabel}>Seguimiento:</span>
                  <span style={styles.infoValue}>{detalleSeleccionado.codigo_seguimiento || '---'}</span>
                </div>

                <div style={styles.infoRowGrid}>
                  <span style={styles.infoLabel}>Patrullaje:</span>
                  <span style={styles.infoValue}>{detalleSeleccionado.tipo_patrullaje_nombre || '---'}</span>
                </div>
                <div style={styles.infoRowGrid}>
                  <span style={styles.infoLabel}>Encargado:</span>
                  <span style={styles.infoValue}>{detalleSeleccionado.unidad_encargada || '---'}</span>
                </div>

                <div style={{...styles.infoRowGrid, gridColumn: 'span 2'}}>
                  <span style={styles.infoLabel}>Ubicación:</span>
                  <span style={styles.infoValue}>
                    {detalleSeleccionado.label || detalleSeleccionado.via_nombre || '---'} 
                    <span style={{color: '#64748b', fontSize: '12px'}}> (Ref: {detalleSeleccionado.referencia || 'Sin referencia'})</span>
                  </span>
                </div>
              </div>
              
              <div style={{marginTop: '16px'}}>
                <strong style={styles.sectionTitle}>Descripción / Suceso:</strong>
                <p style={styles.descBox}>
                  {detalleSeleccionado.ocurrencia_descripcion || detalleSeleccionado.descripcion || 'Sin descripción en base de datos.'}
                </p>
              </div>

              {detalleSeleccionado.foto_principal && (
                <div style={{marginTop: '16px'}}>
                  <strong style={styles.sectionTitle}>Evidencias Adjuntas ({detalleSeleccionado.total_fotos || 1}):</strong>
                  <div style={styles.galleryGrid}>
                    <img src={detalleSeleccionado.foto_principal} style={styles.imgGalleryItem} alt="Evidencia 1" />
                    {Number(detalleSeleccionado.total_fotos) > 1 && Array.from({length: Number(detalleSeleccionado.total_fotos) - 1}).map((_, idx) => (
                      <img key={idx} src={detalleSeleccionado.foto_principal} style={styles.imgGalleryItem} alt={`Evidencia ${idx + 2}`} />
                    ))}
                  </div>
                </div>
              )}
            </div>
          </div>
        </div>
      )}

      {/* Modales de Inserción */}
      <RegistroOcurrencia visible={modalInsertOpen === 'camara'} onClose={() => { setModalInsertOpen(null); fetchOcurrencias(); }} initialData={{ idTipo: 'camara' }} />
      <RegistroOcurrenciat visible={modalInsertOpen === 'telefono'} onClose={() => { setModalInsertOpen(null); fetchOcurrencias(); }} initialData={{ idTipo: 'telefono' }} />
      <RegistroRedes visible={modalInsertOpen === 'redes'} onClose={() => { setModalInsertOpen(null); fetchOcurrencias(); }} initialData={{ idTipo: 'redes' }} />
    </div>
  );
}

// ESTILOS CONSOLIDADOS Y OPTIMIZADOS
const styles: Record<string, React.CSSProperties | any> = {
  container: { padding: '24px', backgroundColor: '#f8fafc', minHeight: '100vh', fontFamily: '-apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif' },
  grid: { display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(180px, 1fr))', gap: '16px', marginBottom: '24px' },
  card: { padding: '18px', borderRadius: '12px', color: 'white', display: 'flex', flexDirection: 'column', alignItems: 'center', border: 'none', cursor: 'pointer', boxShadow: '0 4px 6px -1px rgb(0 0 0 / 0.1)' },
  cardLab: { fontSize: '12px', fontWeight: '700', marginTop: '8px', letterSpacing: '0.5px' },
  header: { display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '20px', flexWrap: 'wrap', gap: '15px' },
  tabs: { display: 'flex', gap: '4px', backgroundColor: '#e2e8f0', padding: '4px', borderRadius: '8px' },
  tab: { border: 'none', padding: '8px 16px', cursor: 'pointer', borderRadius: '6px', backgroundColor: 'transparent', color: '#64748b', fontWeight: '600', fontSize: '13px', transition: 'all 0.2s' },
  tabActive: { border: 'none', padding: '8px 16px', cursor: 'pointer', borderRadius: '6px', backgroundColor: MJM_BLUE, color: 'white', fontWeight: '600', fontSize: '13px', transition: 'all 0.2s' },
  btnExport: { display: 'flex', alignItems: 'center', gap: '6px', padding: '8px 14px', borderRadius: '6px', border: 'none', color: 'white', fontSize: '13px', fontWeight: '600', cursor: 'pointer' },
  tableCard: { 
    backgroundColor: 'white', 
    borderRadius: '12px', 
    boxShadow: '0 4px 6px -1px rgb(0 0 0 / 0.05)', 
    border: '1px solid #e2e8f0', 
    display: 'flex', 
    flexDirection: 'column', 
    overflow: 'hidden', 
    position: 'relative',
    // SOLUCIÓN: Fijamos la altura de la tarjeta para controlar el espacio de la pantalla
    height: '700px' 
  },
  tableScrollContainer: { 
    overflowX: 'auto', 
    // SOLUCIÓN: Activamos el scroll vertical automático para las filas
    overflowY: 'auto', 
    // Ocupa todo el espacio disponible entre la cabecera y el paginador
    flex: 1 
  }, table: { width: '100%', borderCollapse: 'collapse', tableLayout: 'fixed' }, 
thead: { 
    backgroundColor: '#024885', // <-- Cambiado a tu azul MJM_BLUE
    borderBottom: '2px solid #013663', 
    textAlign: 'left', 
    position: 'sticky', 
    top: 0, 
    zIndex: 10 
  },
  th: { 
    padding: '14px 16px', 
    fontSize: '10px', // Enfoque profesional ligeramente más grande
    fontWeight: '700', 
    color: '#ffffff', // <-- Texto blanco para que contraste con el fondo azul
    textTransform: 'uppercase',
    letterSpacing: '0.5px'
  },
  td: { padding: '14px 16px', borderBottom: '1px solid #e2e8f0', verticalAlign: 'middle', overflow: 'hidden' },
  tr: { cursor: 'pointer', transition: 'background-color 0.2s' },
  
  celdaTruncadaContainer: { display: 'block', width: '100%', maxWidth: '100%', overflow: 'hidden', boxSizing: 'border-box' },
  txtB: { fontSize: '13px', fontWeight: '600', color: '#1e293b', whiteSpace: 'nowrap', overflow: 'hidden', textOverflow: 'ellipsis', display: 'block', width: '100%' },
  txtS: { fontSize: '11px', color: '#64748b', whiteSpace: 'nowrap', overflow: 'hidden', textOverflow: 'ellipsis', display: 'block', width: '100%' },

  img: { width: '42px', height: '42px', borderRadius: '8px', objectFit: 'cover', border: '1px solid #cbd5e1' },
  photoCountBadge: { position: 'absolute', bottom: '-2px', right: '-2px', backgroundColor: '#1e293b', color: 'white', fontSize: '9px', fontWeight: 'bold', padding: '1px 4px', borderRadius: '6px', border: '1px solid white' },
  
  tableFooterPagination: { display: 'flex', justifyContent: 'flex-end', alignItems: 'center', padding: '12px 16px', borderTop: '1px solid #e2e8f0', backgroundColor: '#ffffff', position: 'relative' },
  selectRows: { padding: '6px 10px', borderRadius: '6px', border: '1px solid #e2e8f0', backgroundColor: '#ffffff', color: '#334155', fontSize: '12px', fontWeight: '600', outline: 'none', cursor: 'pointer' },
  paginationFlex: { display: 'flex', alignItems: 'center', gap: '4px', border: '1px solid #e2e8f0', padding: '4px', borderRadius: '8px', backgroundColor: '#f8fafc' },
  btnPageNew: { display: 'flex', alignItems: 'center', justifyContent: 'center', width: '32px', height: '32px', borderRadius: '6px', border: 'none', backgroundColor: '#ffffff', cursor: 'pointer', boxShadow: '0 1px 2px rgb(0 0 0 / 0.05)' },
  pageInfoWrapper: { fontSize: '12px', fontWeight: '700', color: '#475569', width: '110px', textAlign: 'center', display: 'inline-block', userSelect: 'none' },
  
  overlay: { position: 'fixed', top: 0, left: 0, right: 0, bottom: 0, backgroundColor: 'rgba(15, 23, 42, 0.6)', display: 'flex', justifyContent: 'center', alignItems: 'center', zIndex: 1000, backdropFilter: 'blur(3px)' },
  modalDetail: { backgroundColor: 'white', padding: '24px', borderRadius: '16px', width: '720px', height: '580px', display: 'flex', flexDirection: 'column', boxShadow: '0 25px 50px -12px rgb(0 0 0 / 0.25)', overflow: 'hidden' },
  modalHeader: { display: 'flex', justifyContent: 'space-between', alignItems: 'center', borderBottom: '1px solid #e2e8f0', paddingBottom: '14px', flexShrink: 0 },
  modalBodyScrollable: { flex: 1, overflowY: 'auto', marginTop: '14px', paddingRight: '4px' },
  btnClose: { background: 'none', border: 'none', fontSize: '20px', cursor: 'pointer', color: '#94a3b8' },
  modalGridDobleFila: { display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '0px 24px' },
  infoRowGrid: { display: 'flex', flexDirection: 'row', padding: '10px 0', borderBottom: '1px solid #f1f5f9', fontSize: '13px', alignItems: 'center' },
  infoLabel: { width: '110px', flexShrink: 0, fontWeight: '700', color: '#475569' },
  infoValue: { color: '#1e293b', fontWeight: '500', wordBreak: 'break-word', whiteSpace: 'normal' },
  sectionTitle: { fontSize: '11px', color: '#64748b', textTransform: 'uppercase', letterSpacing: '0.5px', display: 'block', marginBottom: '6px' },
  descBox: { color: '#334155', fontSize: '13px', backgroundColor: '#f8fafc', padding: '12px', borderRadius: '8px', border: '1px solid #e2e8f0', lineHeight: '1.5', margin: 0 },
  galleryGrid: { display: 'grid', gridTemplateColumns: 'repeat(auto-fill, minmax(140px, 1fr))', gap: '10px' },
   badge: { padding: '3px 8px', borderRadius: '12px', color: 'white', fontSize: '10px', fontWeight: '700', display: 'inline-block', marginTop: '4px' },
  
  imgGalleryItem: { width: '100%', height: '95px', borderRadius: '8px', objectFit: 'cover', border: '1px solid #cbd5e1', backgroundColor: '#f8fafc' }
};