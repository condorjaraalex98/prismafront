import { ThemedText } from '@/components/themed-text';
import { ThemedView } from '@/components/themed-view';
import { Ionicons } from '@expo/vector-icons';
import { Picker } from '@react-native-picker/picker';
import React, { useCallback, useEffect, useState } from 'react';
import {
    ActivityIndicator, Alert, FlatList, Modal,
    StyleSheet, TextInput, TouchableOpacity, View
} from 'react-native';

const MJM_BLUE = '#024885';
const API_URL = 'http://192.168.1.11:3000'; 

export default function ViaScreen() {
    const [vias, setVias] = useState([]);
    const [tiposVia, setTiposVia] = useState([]);
    const [distritos, setDistritos] = useState([]);
    const [cargando, setCargando] = useState(true);
    
    const [modalVisible, setModalVisible] = useState(false);
    const [modalBorrarVisible, setModalBorrarVisible] = useState(false); // <--- Nuevo

    const [editandoId, setEditandoId] = useState(null);
    const [idParaBorrar, setIdParaBorrar] = useState(null); // <--- Nuevo

    const [form, setForm] = useState({
        nombre_via: '',
        id_tipo_via: '',
        id_distrito: ''
    });

    const cargarDatos = useCallback(async () => {
        setCargando(true);
        try {
            const [resVias, resTipos, resDis] = await Promise.all([
                fetch(`${API_URL}/vias`),
                fetch(`${API_URL}/tipos-via`),
                fetch(`${API_URL}/distritos/todos`)
            ]);
            if (resVias.ok) setVias(await resVias.json());
            if (resTipos.ok) setTiposVia(await resTipos.json());
            if (resDis.ok) setDistritos(await resDis.json());
        } catch (e) { console.error(e); }
        finally { setCargando(false); }
    }, []);

    useEffect(() => { cargarDatos(); }, [cargarDatos]);

    const guardarVia = async () => {
        if (!form.nombre_via || !form.id_tipo_via || !form.id_distrito) return Alert.alert("Error", "Complete todo");
        const metodo = editandoId ? 'PUT' : 'POST';
        const url = editandoId ? `${API_URL}/vias/${editandoId}` : `${API_URL}/vias`;
        try {
            const resp = await fetch(url, {
                method: metodo,
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ ...form, nombre_via: form.nombre_via.toUpperCase() })
            });
            if (resp.ok) {
                setModalVisible(false);
                cargarDatos();
            }
        } catch (e) { Alert.alert("Error", "No guardó"); }
    };

    // Función para el botón de borrar
    const confirmarBorrado = async () => {
        try {
            const resp = await fetch(`${API_URL}/vias/${idParaBorrar}/desactivar`, { method: 'PATCH' });
            if (resp.ok) {
                setModalBorrarVisible(false);
                cargarDatos();
            }
        } catch (e) { Alert.alert("Error", "No se pudo eliminar"); }
    };

    return (
        <ThemedView style={styles.container}>
            <View style={styles.header}>
                <ThemedText style={styles.headerTitle}>Vías Registradas</ThemedText>
                <TouchableOpacity style={styles.addBtn} onPress={() => { setEditandoId(null); setForm({nombre_via:'', id_tipo_via:'', id_distrito:''}); setModalVisible(true); }}>
                    <Ionicons name="add" size={26} color="white" />
                </TouchableOpacity>
            </View>

            {cargando ? <ActivityIndicator size="large" color={MJM_BLUE} /> : (
                <FlatList
                    data={vias}
                    keyExtractor={(item) => item.id_via.toString()}
                    renderItem={({ item }) => (
                        <View style={styles.card}>
                            <View style={{ flex: 1 }}>
                                <ThemedText style={styles.cardTitle}>{item.abreviatura} {item.nombre_via}</ThemedText>
                                <ThemedText style={styles.cardSub}>{item.descripcion} - {item.nombre_distrito}</ThemedText>
                            </View>
                            
                            {/* AQUÍ ESTÁN LOS BOTONES EDITAR Y BORRAR */}
                            <View style={styles.actionButtons}>
                                <TouchableOpacity onPress={() => {
                                    setEditandoId(item.id_via);
                                    setForm({ nombre_via: item.nombre_via, id_tipo_via: item.id_tipo_via.toString(), id_distrito: item.id_distrito.toString() });
                                    setModalVisible(true);
                                }}>
                                    <Ionicons name="pencil" size={22} color={MJM_BLUE} style={{ marginRight: 15 }} />
                                </TouchableOpacity>

                                <TouchableOpacity onPress={() => {
                                    setIdParaBorrar(item.id_via);
                                    setModalBorrarVisible(true);
                                }}>
                                    <Ionicons name="trash-outline" size={22} color="#ef4444" />
                                </TouchableOpacity>
                            </View>
                        </View>
                    )}
                />
            )}

            {/* MODAL ELIMINAR */}
            <Modal visible={modalBorrarVisible} transparent animationType="fade">
                <View style={styles.overlay}>
                    <View style={styles.modalCardMini}>
                        <ThemedText style={{fontWeight:'bold', fontSize:16, textAlign:'center'}}>¿Desea eliminar esta vía?</ThemedText>
                        <View style={{flexDirection:'row', justifyContent:'space-around', marginTop:20}}>
                            <TouchableOpacity onPress={() => setModalBorrarVisible(false)}>
                                <ThemedText style={{color:'#64748b'}}>No, cancelar</ThemedText>
                            </TouchableOpacity>
                            <TouchableOpacity onPress={confirmarBorrado}>
                                <ThemedText style={{color:'#ef4444', fontWeight:'bold'}}>Sí, eliminar</ThemedText>
                            </TouchableOpacity>
                        </View>
                    </View>
                </View>
            </Modal>

            {/* MODAL FORMULARIO (Igual que antes pero con tus campos abreviatura/descripcion) */}
            <Modal visible={modalVisible} transparent animationType="slide">
                <View style={styles.overlay}>
                    <View style={styles.modalCard}>
                        <ThemedText style={styles.modalTitle}>{editandoId ? 'Editar' : 'Nueva'} Vía</ThemedText>
                        <ThemedText style={styles.label}>TIPO:</ThemedText>
                        <View style={styles.pickerBox}>
                            <Picker selectedValue={form.id_tipo_via} onValueChange={(v) => setForm({...form, id_tipo_via:v})}>
                                <Picker.Item label="Seleccione..." value="" />
                                {tiposVia.map(t => <Picker.Item key={t.id_tipo_via} label={`${t.abreviatura} - ${t.descripcion}`} value={t.id_tipo_via.toString()} />)}
                            </Picker>
                        </View>
                        <ThemedText style={styles.label}>DISTRITO:</ThemedText>
                        <View style={styles.pickerBox}>
                            <Picker selectedValue={form.id_distrito} onValueChange={(v) => setForm({...form, id_distrito:v})}>
                                <Picker.Item label="Seleccione..." value="" />
                                {distritos.map(d => <Picker.Item key={d.id_distrito} label={d.nombre_distrito} value={d.id_distrito.toString()} />)}
                            </Picker>
                        </View>
                        <ThemedText style={styles.label}>NOMBRE:</ThemedText>
                        <TextInput style={styles.input} value={form.nombre_via} onChangeText={(t) => setForm({...form, nombre_via:t})} autoCapitalize="characters" />
                        <TouchableOpacity style={styles.btnSave} onPress={guardarVia}><ThemedText style={{color:'white', fontWeight:'bold'}}>GUARDAR</ThemedText></TouchableOpacity>
                        <TouchableOpacity onPress={() => setModalVisible(false)} style={{marginTop:15}}><ThemedText style={{textAlign:'center', color:'#64748b'}}>CERRAR</ThemedText></TouchableOpacity>
                    </View>
                </View>
            </Modal>
        </ThemedView>
    );
}

const styles = StyleSheet.create({
    container: { flex: 1, backgroundColor: '#f8fafc' },
    header: { padding: 40, paddingTop: 60, paddingBottom: 20, backgroundColor: '#fff', flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center' },
    headerTitle: { color: MJM_BLUE, fontWeight: 'bold', fontSize: 20 },
    addBtn: { backgroundColor: MJM_BLUE, padding: 10, borderRadius: 12 },
    card: { backgroundColor: 'white', padding: 15, borderRadius: 15, marginBottom: 10, marginHorizontal:15, elevation: 2, flexDirection: 'row', alignItems: 'center' },
    cardTitle: { fontWeight: 'bold', fontSize: 16 },
    cardSub: { fontSize: 12, color: '#64748b' },
    actionButtons: { flexDirection: 'row', alignItems: 'center' },
    overlay: { flex: 1, backgroundColor: 'rgba(0,0,0,0.5)', justifyContent: 'center', alignItems: 'center' },
    modalCard: { backgroundColor: 'white', width: '85%', borderRadius: 20, padding: 25 },
    modalCardMini: { backgroundColor: 'white', width: '70%', borderRadius: 15, padding: 20 },
    modalTitle: { fontSize: 18, fontWeight: 'bold', color: MJM_BLUE, marginBottom: 20 },
    label: { fontSize: 11, fontWeight: 'bold', color: MJM_BLUE, marginBottom: 5 },
    pickerBox: { backgroundColor: '#f1f5f9', borderRadius: 10, marginBottom: 15 },
    input: { backgroundColor: '#f1f5f9', padding: 15, borderRadius: 10, marginBottom: 20 },
    btnSave: { backgroundColor: MJM_BLUE, padding: 15, borderRadius: 10, alignItems: 'center' }
});