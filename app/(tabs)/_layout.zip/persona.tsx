import { ThemedText } from '@/components/themed-text';
import { Ionicons } from '@expo/vector-icons';
import { Picker } from '@react-native-picker/picker';
import * as ImagePicker from 'expo-image-picker';
import React, { useCallback, useEffect, useState } from 'react';
import {
    ActivityIndicator,
    Dimensions,
    FlatList,
    Image, Modal,
    ScrollView,
    StyleSheet,
    TextInput,
    TouchableOpacity,
    View
} from 'react-native';
const { width } = Dimensions.get('window');
const isDesktop = width > 1000; // Umbral mayor para asegurar columnas en Web
const MJM_BLUE = '#024885';
export default function PersonaScreen() {
    const pickImage = async () => {
    let result = await ImagePicker.launchImageLibraryAsync({
        mediaTypes: ImagePicker.MediaTypeOptions.Images,
        allowsEditing: true,
        aspect: [1, 1],
        quality: 0.7,
        base64: true, // Importante para enviar al backend como en tu ejemplo
    });

    if (!result.canceled) {
        // Guardamos la base64 en el objeto personaEdit para enviarlo después
        setPersonaEdit({
            ...personaEdit,
            foto_perfil: result.assets[0].uri, // Para previsualización local
            foto_perfil_base64: `data:image/jpeg;base64,${result.assets[0].base64}` // Para el servidor
        });
    }
};
interface Unidad {
    id_unidad: number | string;
    nombre_unidad: string;
}
    const [personas, setPersonas] = useState<any[]>([]);
    const [unidades, setUnidades] = useState([]);
    const [counts, setCounts] = useState<any>({ total: 0, activos: 0, inactivos: 0, regimenes: {} });
    const [searchText, setSearchText] = useState('');
    const [regimenSel, setRegimenSel] = useState('TODOS');
    const [estadoSel, setEstadoSel] = useState('TODOS');
    const [unidadSel, setUnidadSel] = useState('');
    const [page, setPage] = useState(1);
    const [loading, setLoading] = useState(false);
    const [hasMore, setHasMore] = useState(true);
    const [errors, setErrors] = useState<any>({}); // Para pintar bordes rojos
const [customAlert, setCustomAlert] = useState({ visible: false, title: '', message: '', type: 'success' });
    // Modal de Edición
    const [personaEdit, setPersonaEdit] = useState<any>(null);
    const [modalVisible, setModalVisible] = useState(false);
//MODAL PARA INSERTAR 

// [cite: 5, 9] Dentro de PersonaScreen...
const [modalCrearVisible, setModalCrearVisible] = useState(false);
const [nuevaPersona, setNuevaPersona] = useState({
    nombres: '',
    apellido_paterno: '',
    apellido_materno: '',
    documento_numero: '',
    celular: ''
});

// Función para enviar los datos al backend
const handleGuardarNuevo = async () => {
    let newErrors: any = {};
    const { nombres, apellido_paterno, apellido_materno, documento_numero , celular} = nuevaPersona;

    // Validación de campos
    if (!nombres.trim()) newErrors.nombres = true;
    if (!apellido_paterno.trim()) newErrors.apellido_paterno = true;
    if (!apellido_materno.trim()) newErrors.apellido_materno = true;
    if (!documento_numero.trim()) newErrors.documento_numero = true;
  if (!documento_numero.trim()) newErrors.documento_numero = true;
  if (!celular || !celular.trim()) newErrors.celular = true;
    if (Object.keys(newErrors).length > 0) {
        setErrors(newErrors);
        setCustomAlert({ visible: true, title: 'Campos Faltantes', message: 'Por favor complete los campos marcados en rojo.', type: 'error' });
        return;
    }

    setErrors({}); // Limpiar errores si pasa la validación inicial

    try {
        setLoading(true);
        const checkRes = await fetch(`http://192.168.1.11:3000/personas/check/${documento_numero}`);
        const checkData = await checkRes.json();

        if (checkData.exists) {
            setCustomAlert({ visible: true, title: 'DNI Duplicado', message: 'Este número de documento ya está registrado.', type: 'error' });
            setLoading(false);
            return;
        }

        const res = await fetch('http://192.168.1.11:3000/insertpersonas', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify(nuevaPersona)
        });

        if (res.ok) {
            setModalCrearVisible(false);
            setNuevaPersona({ nombres: '', apellido_paterno: '', apellido_materno: '', documento_numero: '', celular: '' });
            setCustomAlert({ visible: true, title: '¡Éxito!', message: 'El personal ha sido registrado correctamente.', type: 'success' });
            cargarDatos(true);
        }
    } catch (e) {
        setCustomAlert({ visible: true, title: 'Error de Red', message: 'No se pudo conectar con el servidor.', type: 'error' });
    } finally {
        setLoading(false);
    }
};


// 2. Función para cargar las unidades desde el servidor


const handleGuardarCambios = async () => {
    if (!personaEdit) return;
    try {
        setLoading(true);
        const res = await fetch(`http://192.168.1.11:3000/updatepersona/${personaEdit.id_persona}`, {
            method: 'PUT',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify(personaEdit)
        });

        const data = await res.json(); 

        if (res.ok) {
            setModalVisible(false);
            setCustomAlert({ 
                visible: true, 
                title: '¡Éxito!', 
                message: 'La información se actualizó correctamente.', 
                type: 'success' 
            }); 
            cargarDatos(true); 
        } else {
            // MOSTRAR ERROR DEL BACKEND (DNI DUPLICADO)
            setCustomAlert({ 
                visible: true, 
                title: 'Error', 
                message: data.message || 'No se pudo actualizar la información.', 
                type: 'error' 
            });
        }
    } catch (e) {
        setCustomAlert({ 
            visible: true, 
            title: 'Error de Red', 
            message: 'No se pudo conectar con el servidor.', 
            type: 'error' 
        }); 
    } finally {
        setLoading(false);
    }
};
  const cargarCatalogos = async () => {
    try {
        // CAMBIO: Usar la ruta correcta definida en tu backend
        const res = await fetch('http://192.168.1.11:3000/unidades'); 
        const data = await res.json();
        setUnidades(data);
    } catch (e) { 
        console.error("Error al cargar unidades:", e); 
    }
};
    const cargarDatos = useCallback(async (reset = false) => {
        if (loading || (!hasMore && !reset)) return;
        setLoading(true);
        try {
            const nextPage = reset ? 1 : page;
            const query = new URLSearchParams({ 
                q: searchText, regimen: regimenSel, 
                unidad: unidadSel, estado: estadoSel, page: nextPage.toString()
            });
            const res = await fetch(`http://192.168.1.11:3000/personas1?${query}`);
            const result = await res.json();
            const regCounts = result.counts.reduce((acc: any, curr: any) => ({ ...acc, [curr.regimen]: curr.reg_total }), {});
            
            setCounts({
                total: result.counts[0]?.total || 0,
                activos: result.counts[0]?.activos || 0,
                inactivos: result.counts[0]?.inactivos || 0,
                regimenes: regCounts
            });
            setPersonas(prev => reset ? result.data : [...prev, ...result.data]);
            setHasMore(result.hasMore);
            setPage(nextPage + 1);
        } catch (e) { console.error(e); }
        finally { setLoading(false); }
    }, [searchText, regimenSel, unidadSel, estadoSel, page, loading, hasMore]);

    useEffect(() => { cargarCatalogos(); }, []);
    useEffect(() => { setHasMore(true); cargarDatos(true); }, [searchText, regimenSel, unidadSel, estadoSel]);

    const BadgeEstado = ({ estado }: { estado: string }) => (
        <View style={[styles.badge, { backgroundColor: estado === 'ACTIVO' ? '#E8F5E9' : '#FFEBEE' }]}>
            <ThemedText style={{ color: estado === 'ACTIVO' ? '#2E7D32' : '#C62828', fontSize: 10, fontWeight: 'bold' }}>{estado}</ThemedText>
        </View>
    );

    const renderHeaderTable = () => isDesktop && (
        <View style={styles.tableHeader}>
            <ThemedText style={[styles.cell, { flex: 0.6 }]}>FOTO</ThemedText>
            <ThemedText style={[styles.cell, { flex: 1.5 }]}>APELLIDOS Y NOMBRES</ThemedText>
            <ThemedText style={[styles.cell, { flex: 0.8 }]}>DNI</ThemedText>
            <ThemedText style={[styles.cell, { flex: 1.2 }]}>CARGO / UNIDAD</ThemedText>
            <ThemedText style={[styles.cell, { flex: 0.8 }]}>RÉGIMEN</ThemedText>
            <ThemedText style={[styles.cell, { flex: 0.6, textAlign: 'center' }]}>ESTADO</ThemedText>
        </View>
    );

    return (
     <View style={styles.container}>
    <View style={styles.header}>
        <View style={styles.headerTop}>
            <ThemedText style={styles.headerTitle}>Gestión de Personal</ThemedText>
            
            <View style={{ flexDirection: 'row', alignItems: 'center', gap: 10 }}>
                {/* BOTÓN NUEVO PERSONAL */}
                <TouchableOpacity 
                    style={[styles.btnEstado, { backgroundColor: '#024885', flexDirection: 'row', alignItems: 'center', paddingHorizontal: 12 }]}
                    onPress={() => setModalCrearVisible(true)}
                >
                    <Ionicons name="person-add" size={25} color="white" />
                
                </TouchableOpacity>

                <View style={styles.estadoToggle}>
                    {[{ id: 'TODOS', l: 'TODOS', c: counts.total }, { id: 'ACTIVO', l: 'ACTIVOS', c: counts.activos }, { id: 'INACTIVO', l: 'INACTIVOS', c: counts.inactivos }].map(e => (
                        <TouchableOpacity key={e.id} onPress={() => setEstadoSel(e.id)} style={[styles.btnEstado, estadoSel === e.id && styles.btnEstadoActive]}>
                            <ThemedText style={[styles.btnText, estadoSel === e.id && { color: 'white' }]}>{e.l} ({e.c})</ThemedText>
                        </TouchableOpacity>
                    ))}
                </View>
            </View>
        </View>

        <View style={styles.searchRow}>
            <View style={styles.searchBar}>
                <Ionicons name="search" size={18} color="#888" />
               <TextInput 
  placeholder="Buscar por DNI y/o Nombres" 
  placeholderTextColor="#94a3b8"
  style={styles.input} 
  onChangeText={setSearchText} 
  clearButtonMode="while-editing" // Útil en iOS para borrar rápido
/>
            </View>
         
        </View>

        <ScrollView horizontal showsHorizontalScrollIndicator={false} style={{ marginTop: 12 }}>
            {['TODOS', 'CAS', 'LOCADOR', 'D.L. 728', 'D.L. 276'].map(reg => (
                <TouchableOpacity key={reg} onPress={() => setRegimenSel(reg)} style={[styles.btnReg, regimenSel === reg && styles.btnActive]}>
                    <ThemedText style={[styles.btnText, regimenSel === reg && { color: 'white' }]}>
                        {reg} ({reg === 'TODOS' ? (counts.total || 0) : (counts.regimenes[reg] || 0)})
                    </ThemedText>
                </TouchableOpacity>
            ))}
        </ScrollView>
    </View>

    {renderHeaderTable()}

    <FlatList
        data={personas}
        keyExtractor={(item, index) => item.id_persona.toString() + index}
        onEndReached={() => cargarDatos()}
        onEndReachedThreshold={0.5}
        ListFooterComponent={loading ? <ActivityIndicator size="small" color={MJM_BLUE} style={{ margin: 15 }} /> : null}
        renderItem={({ item }) => (
            <TouchableOpacity 
                style={isDesktop ? styles.tableRow : styles.card} 
                onPress={() => { setPersonaEdit(item); setModalVisible(true); }}
            >
              <View style={isDesktop ? { flex: 0.6 } : null}> 
    <Image 
        source={item.foto_perfil ? { uri: item.foto_perfil } : require('@/assets/images/roles/default.png')} 
        style={isDesktop ? styles.avatarTable : styles.avatarCard} 
    />
</View>

                {isDesktop ? (
                    <>
                        <ThemedText style={[styles.cell, { flex: 1.5, fontWeight: 'bold' }]}>{`${item.apellido_paterno} ${item.apellido_materno || ''} , ${item.nombres}`.toUpperCase()}</ThemedText>
                        <ThemedText style={[styles.cell, { flex: 0.8 }]}>{item.documento_numero}</ThemedText>
                        <ThemedText style={[styles.cell, { flex: 1.2, color: MJM_BLUE }]}>{item.nombre_unidad}</ThemedText>
                        <ThemedText style={[styles.cell, { flex: 0.8 }]}>{item.regimen}</ThemedText>
                        <View style={[styles.cell, { flex: 0.6, alignItems: 'center' }]}><BadgeEstado estado={item.estado_laboral} /></View>
                    </>
                ) : (
                    <View style={{ flex: 1, marginLeft: 15 }}>
                        <ThemedText style={{ fontWeight: 'bold' }}>{`${item.apellido_paterno} ${item.nombres}`.toUpperCase()}</ThemedText>
                        <ThemedText style={{ color: MJM_BLUE, fontSize: 11 }}>{item.nombre_unidad}</ThemedText>
                        <BadgeEstado estado={item.estado_laboral} />
                    </View>
                )}
            </TouchableOpacity>
        )}
    />

    {/* MODAL DE EDICIÓN PROFESIONAL */}
<Modal visible={modalVisible} transparent animationType="slide">
    <View style={styles.modalOverlay}>
        <View style={styles.modalContent}>
            <View style={styles.modalHeader}>
                <ThemedText style={styles.modalTitle}>Editar Personal</ThemedText>
                <TouchableOpacity onPress={() => setModalVisible(false)}>
                    <Ionicons name="close" size={24} />
                </TouchableOpacity>
            </View>

            {personaEdit && (
                <ScrollView showsVerticalScrollIndicator={false}>
                    {/* SECCIÓN DE FOTO */}
                    <View style={{ alignItems: 'center', marginBottom: 20 }}>
                        <Image 
                            source={personaEdit.foto_perfil ? { uri: personaEdit.foto_perfil } : require('@/assets/images/roles/default.png')} 
                            style={styles.largeAvatar} 
                        />
                        <TouchableOpacity onPress={pickImage}>
                            <ThemedText style={{ color: MJM_BLUE, fontWeight: 'bold' }}>CAMBIAR FOTO</ThemedText>
                        </TouchableOpacity>
                    </View>

                    {/* CAMPOS DE TEXTO */}
                    <ThemedText style={styles.label}>Nombres</ThemedText>
                    <TextInput 
                        style={styles.modalInput} 
                        value={personaEdit.nombres} 
                        onChangeText={(t) => setPersonaEdit({...personaEdit, nombres: t})} 
                    />

                    <ThemedText style={styles.label}>Apellidos</ThemedText>
                    <View style={{ flexDirection: 'row', gap: 10 }}>
                        <TextInput 
                            style={[styles.modalInput, { flex: 1 }]} 
                            placeholder="Paterno"
                            value={personaEdit.apellido_paterno} 
                            onChangeText={(t) => setPersonaEdit({...personaEdit, apellido_paterno: t})} 
                        />
                        <TextInput 
                            style={[styles.modalInput, { flex: 1 }]} 
                            placeholder="Materno"
                            value={personaEdit.apellido_materno} 
                            onChangeText={(t) => setPersonaEdit({...personaEdit, apellido_materno: t})} 
                        />
                    </View>

                    <View style={{ flexDirection: 'row', gap: 10 }}>
                        <View style={{ flex: 1 }}>
                            <ThemedText style={styles.label}>DNI</ThemedText>
                       <TextInput 
    style={styles.modalInput} 
    value={personaEdit.documento_numero} 
    keyboardType="numeric"
    maxLength={10} // Límite de 10 dígitos
    onChangeText={(t) => {
        // Filtrar para permitir solo números
        const numericValue = t.replace(/[^0-9]/g, '');
        
        // Actualizar el estado de la persona en edición
        setPersonaEdit({
            ...personaEdit, 
            documento_numero: numericValue 
        });
    }} 
/>
                        </View>
                        <View style={{ flex: 1 }}>
                            <ThemedText style={styles.label}>Celular</ThemedText>
                          <TextInput 
    style={styles.modalInput} 
    value={personaEdit.celular} 
    keyboardType="phone-pad" // Muestra el teclado numérico 
    onChangeText={(t) => {
        // Reemplaza cualquier carácter que NO sea un número (0-9) con un string vacío
        const numericValue = t.replace(/[^0-9]/g, ''); 
        setPersonaEdit({ ...personaEdit, celular: numericValue }); // 
    }} 
    maxLength={9} // Opcional: limita la cantidad de dígitos si es necesario
/>
                        </View>
                    </View>

                    {/* SELECTOR DE UNIDAD ORGÁNICA */}
                    <ThemedText style={styles.label}>Unidad Orgánica</ThemedText>
               <View style={styles.modalPicker}>
    <Picker
        selectedValue={personaEdit.id_unidad}
        onValueChange={(val) => setPersonaEdit({ ...personaEdit, id_unidad: val })}
    >
        <Picker.Item label="Seleccionar Unidad..." value={null} />
        {unidades.map((u: Unidad) => ( // Agregamos :Unidad aquí
            <Picker.Item 
                key={u.id_unidad.toString()} 
                label={u.nombre_unidad} 
                value={u.id_unidad} 
            />
        ))}
    </Picker>
</View>

                    {/* RÉGIMEN Y ESTADO */}
                    <ThemedText style={styles.label}>Régimen</ThemedText>
                    <View style={styles.modalPicker}>
                        <Picker 
                            selectedValue={personaEdit.regimen}
                            onValueChange={(v) => setPersonaEdit({...personaEdit, regimen: v})}
                        >
                            <Picker.Item label="CAS" value="CAS" />
                            <Picker.Item label="LOCADOR" value="LOCADOR" />
                            <Picker.Item label="D.L. 728" value="D.L. 728" />
                                 <Picker.Item label="D.L. 276" value="D.L. 276" />
                        </Picker>
                    </View>
<View style={{ flex: 1 }}>
        <ThemedText style={styles.label}>Estado Laboral</ThemedText>
        <View style={styles.modalPicker}>
            <Picker 
                selectedValue={personaEdit.estado_laboral}
                onValueChange={(v) => setPersonaEdit({...personaEdit, estado_laboral: v})}
            >
                <Picker.Item label="ACTIVO" value="ACTIVO" />
                <Picker.Item label="INACTIVO" value="INACTIVO" />
            </Picker>
        </View>
    </View>
                    <TouchableOpacity 
                        style={[styles.btnGuardar, { marginTop: 30, marginBottom: 20 }]} 
                        onPress={handleGuardarCambios}
                    >
                        {loading ? <ActivityIndicator color="white" /> : <ThemedText style={{ color: 'white', fontWeight: 'bold' }}>GUARDAR CAMBIOS</ThemedText>}
                    </TouchableOpacity>
                </ScrollView>
            )}
        </View>
    </View>
</Modal>

    {/* MODAL PARA INSERTAR NUEVO PERSONAL */}
   {/* MODAL DE REGISTRO */}
<Modal visible={modalCrearVisible} transparent animationType="slide">
    <View style={styles.modalOverlay}>
        <View style={styles.modalContent}>
            <View style={styles.modalHeader}>
                <ThemedText style={styles.modalTitle}>Nuevo Personal</ThemedText>
                <TouchableOpacity onPress={() => {setModalCrearVisible(false); setErrors({}); }}>
                    <Ionicons name="close" size={24} color="#666" />
                </TouchableOpacity>
            </View>
            <ScrollView showsVerticalScrollIndicator={false}>
                <ThemedText style={styles.label}>Nombres *</ThemedText>
                <TextInput 
                    style={[styles.modalInput, errors.nombres && { borderColor: '#E53935', borderWidth: 1.5 }]} 
                    placeholder="" 
                    value={nuevaPersona.nombres} 
                  
                  onChangeText={(t) => setNuevaPersona({...nuevaPersona, nombres: t})} 
                    
                    
                />
                
                <ThemedText style={styles.label}>Apellido Paterno *</ThemedText>
                <TextInput 
                autoCapitalize="characters" // <--- Esto fuerza el teclado a mayúsculas
                    style={[styles.modalInput, errors.apellido_paterno && { borderColor: '#E53935', borderWidth: 1.5 }]} 
                    placeholder="" 
                    value={nuevaPersona.apellido_paterno} 
                    onChangeText={(t) => setNuevaPersona({...nuevaPersona, apellido_paterno: t})} 
                />
                
                <ThemedText style={styles.label}>Apellido Materno *</ThemedText>
                <TextInput 
                    style={[styles.modalInput, errors.apellido_materno && { borderColor: '#E53935', borderWidth: 1.5 }]} 
                    placeholder="" 
                    value={nuevaPersona.apellido_materno} 
                    onChangeText={(t) => setNuevaPersona({...nuevaPersona, apellido_materno: t})} 
                />
                
                <ThemedText style={styles.label}>DNI / Documento *</ThemedText>
               <TextInput 
    style={[
        styles.modalInput, 
        errors.documento_numero && { borderColor: '#E53935', borderWidth: 1.5 }
    ]} 
    keyboardType="numeric" 
    maxLength={10} // Cambiado de 12 a 10 
    value={nuevaPersona.documento_numero} 
    onChangeText={(t) => {
        // Filtra para que solo queden números
        const numericValue = t.replace(/[^0-9]/g, ''); 
        
        // Actualiza el estado con el valor filtrado 
        setNuevaPersona({ ...nuevaPersona, documento_numero: numericValue });

        // Opcional: limpia el error visual si existe
        if (errors.documento_numero) {
            setErrors({ ...errors, documento_numero: false });
        }
    }} 
/>
                
                <ThemedText style={styles.label}>Celular *</ThemedText>
<TextInput 
    style={[
        styles.modalInput, 
        errors.celular && { borderColor: '#E53935', borderWidth: 1.5 } // Se pone rojo si hay error [cite: 100]
    ]} 
    keyboardType="phone-pad" 
    placeholder="" 
    value={nuevaPersona.celular} 
    maxLength={9} // Limita a 9 dígitos para celulares en Perú
    onChangeText={(t) => {
        // 1. Filtrar para que solo pasen números
        const numericValue = t.replace(/[^0-9]/g, ''); 
        
        // 2. Actualizar el estado con el valor limpio 
        setNuevaPersona({ ...nuevaPersona, celular: numericValue });

        // 3. Limpiar el estado de error (el borde rojo) mientras escribe [cite: 102]
        if (errors.celular) {
            setErrors({ ...errors, celular: false });
        }
    }} 
/>
                <TouchableOpacity style={[styles.btnGuardar, { backgroundColor: '#024885', marginTop: 25 }]} onPress={handleGuardarNuevo} disabled={loading}>
                    {loading ? <ActivityIndicator color="white" /> : <ThemedText style={{ color: 'white', fontWeight: 'bold' }}>REGISTRAR PERSONAL</ThemedText>}
                </TouchableOpacity>
            </ScrollView>
        </View>
    </View>
</Modal>

{/* MODAL DE ALERTA PERSONALIZADO (Reemplaza al alert nativo) */}
<Modal visible={customAlert.visible} transparent animationType="fade">
    <View style={styles.modalOverlay}>
        <View style={[styles.modalContent, { height: 'auto', width: 320, padding: 30, alignItems: 'center' }]}>
            <Ionicons 
                name={customAlert.type === 'success' ? "checkmark-circle" : "alert-circle"} 
                size={60} 
                color={customAlert.type === 'success' ? "#2E7D32" : "#E53935"} 
            />
            <ThemedText style={{ fontSize: 18, fontWeight: 'bold', marginTop: 10 }}>{customAlert.title}</ThemedText>
            <ThemedText style={{ textAlign: 'center', color: '#666', marginTop: 10 }}>{customAlert.message}</ThemedText>
            
            <TouchableOpacity 
                style={[styles.btnGuardar, { width: '100%', marginTop: 20 }]} 
                onPress={() => setCustomAlert({ ...customAlert, visible: false })}
            >
                <ThemedText style={{ color: 'white', fontWeight: 'bold' }}>ENTENDIDO</ThemedText>
            </TouchableOpacity>
        </View>
    </View>
</Modal>
</View>
    );
}

const styles = StyleSheet.create({
    container: { flex: 1, backgroundColor: '#F4F6F9' },

    input: {
    height: 40,
    backgroundColor: '#ffffff',
    borderRadius: 12,
    paddingHorizontal: 16,
    fontSize: 16,
    color: '#1e293b', // Azul oscuro profesional
    borderWidth: 1,
    borderColor: '#e2e8f0', // Gris suave
    shadowColor: '#000', // Sombra ligera para elevación
    flex: 1,
    shadowOffset: {
      width: 0,
      height: 2,
    },
    shadowOpacity: 0.05,
    shadowRadius: 3.84,
    elevation: 2,
    marginVertical: 10,
  },
    header: { padding: 20, backgroundColor: 'white', borderBottomWidth: 1, borderBottomColor: '#EEE' },
    headerTop: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', marginBottom: 15 },
    headerTitle: { fontSize: 16, fontWeight: 'bold', color: MJM_BLUE },
    estadoToggle: { flexDirection: 'row', backgroundColor: '#F0F2F5', borderRadius: 8, padding: 2 },
    btnEstado: { paddingHorizontal: 10, paddingVertical: 6, borderRadius: 6 },
    btnEstadoActive: { backgroundColor: MJM_BLUE },
    searchRow: { flexDirection: isDesktop ? 'row' : 'column', gap: 10 },
    searchBar: { flex: 1, flexDirection: 'row', backgroundColor: '#F0F2F5', borderRadius: 10, paddingHorizontal: 10, alignItems: 'center', height: 40 },
  
    pickerWrapper: { flex: 1, backgroundColor: '#F0F2F5', borderRadius: 10, height: 40, justifyContent: 'center' },
    picker: { backgroundColor: 'transparent' },
    btnReg: { paddingHorizontal: 15, paddingVertical: 8, backgroundColor: '#EEE', borderRadius: 20, marginRight: 8 },
    btnActive: { backgroundColor: MJM_BLUE },
    btnText: { fontSize: 10, fontWeight: 'bold', color: '#666' },
    // Estilos Tabla
    tableHeader: { flexDirection: 'row', padding: 15, backgroundColor: '#FAFAFA', marginHorizontal: 20, marginTop: 10, borderTopLeftRadius: 10, borderTopRightRadius: 10 },
   tableRow: { 
  flexDirection: 'row', 
  paddingVertical: 20, // Aumenta este valor (estaba en 12)
  paddingHorizontal: 12, 
  alignItems: 'center', 
  borderBottomWidth: 1, 
  borderBottomColor: '#EEE', 
  backgroundColor: 'white', 
  marginHorizontal: 20 
},
    cell: { fontSize: 12, paddingHorizontal: 5 },
   // En tu StyleSheet.create al final del archivo:
avatarTable: { 
    width: 60,          // Antes era 35 
    height: 60,         // Antes era 35 
    borderRadius: 30    // Antes era 17.5 
},  card: { flexDirection: 'row', backgroundColor: 'white', padding: 15, borderRadius: 15, marginBottom: 10, marginHorizontal: 15, alignItems: 'center' },
    avatarCard: { width: 50, height: 50, borderRadius: 25 },
    badge: { paddingHorizontal: 10, paddingVertical: 4, borderRadius: 6 },
    // Modal
    modalOverlay: { flex: 1, backgroundColor: 'rgba(0,0,0,0.5)', justifyContent: 'center', alignItems: 'center' },
    modalContent: { width: isDesktop ? 500 : '90%', height: '90%', backgroundColor: 'white', borderRadius: 20, padding: 20 },
    modalHeader: { flexDirection: 'row', justifyContent: 'space-between', marginBottom: 20 },
    modalTitle: { fontSize: 18, fontWeight: 'bold', color: MJM_BLUE },
    label: { fontSize: 11, fontWeight: 'bold', color: '#666', marginTop: 15, marginBottom: 5 },
    modalInput: { backgroundColor: '#F8F9FA', borderRadius: 8, padding: 12, borderWidth: 1, borderColor: '#DDD', fontSize: 13 },
    inputDisabled: { backgroundColor: '#EEE', color: '#888' },
    modalPicker: { backgroundColor: '#F8F9FA', borderRadius: 8, borderWidth: 1, borderColor: '#DDD' },
    btnGuardar: { backgroundColor: MJM_BLUE, padding: 15, borderRadius: 10, alignItems: 'center', marginTop: 30 },

  
  
    dot: {
        width: 6,
        height: 6,
        borderRadius: 3,
        marginRight: 6,
    },
    badgeText: {
        fontSize: 11,
        fontWeight: 'bold',
        textTransform: 'uppercase',
    },

    largeAvatar: { width: 100, height: 100, borderRadius: 50, marginBottom: 10, borderWidth: 3, borderColor: MJM_BLUE },

    
});
