import { ThemedText } from '@/components/themed-text';
import { ThemedView } from '@/components/themed-view';
import { Ionicons } from '@expo/vector-icons';
import DateTimePicker from '@react-native-community/datetimepicker';
import * as ImagePicker from 'expo-image-picker';
import * as Location from 'expo-location';
import { useRouter } from 'expo-router';
import React, { useEffect, useState } from 'react';
interface ChecklistItem {
    id_item: number;
    id_categoria: number;
    nombre_categoria: string;
    nombre_item: string;
}

interface Respuesta {
    conforme: boolean;
    obs: string;
}

// El estado de respuestas es un objeto donde la llave es el ID del item
interface ChecklistEstado {
    [key: number]: Respuesta;
}

import {
    Alert, // <--- DEBES AGREGAR ESTO
    Image,
    Modal, Platform,
    Pressable, ScrollView, StyleSheet,
    TextInput, View, useColorScheme
} from 'react-native';
import { Dropdown } from 'react-native-element-dropdown';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { useAuth } from '../../context/userContext';

const API_URL = 'http://192.168.1.11:3000';
const MJM_BLUE = '#024885';
const ID_CAMIONETA = 1;
const ID_PATRULLAJE_MOTORIZADO = 3;
const MAX_FOTOS = 5;
interface Unidad {
    id_unidad: string | number;
    id_tipo_vehiculo: string | number;
    placa: string;
    // Agrega otros campos que tenga tu objeto unidad
}

interface UnidadForm {
    id_tipo_vehiculo: number | string | null; // El que viene del dropdown
    id_unidad: number | string | null;       // El que viene del dropdown
    placa: string;
    // Agrega aquí cualquier otro campo que tenga unidadForm
}
export default function RegistroOcurrencia() {
const [checklistItems, setChecklistItems] = useState<{id_item: number, nombre_item: string}[]>([]);
    const [checklistRespuestas, setChecklistRespuestas] = useState<Record<number, { conforme: boolean, obs: string }>>({});
    const [modalChecklistVisible, setModalChecklistVisible] = useState(false);
    const [odometroInicial, setOdometroInicial] = useState("");
    const [unidadTemporal, setUnidadTemporal] = useState<any>(null);
const cargarChecklist = async (idTipoVehiculo: string | number) => {
    try {
        const response = await fetch(`${API_URL}/catalogos/checklist-itemsfiltro1?id_tipo_vehiculo=${idTipoVehiculo}`);
        const data = await response.json();
        setChecklistItems(data); 
    } catch (error) {
        console.error("Error al cargar checklist:", error);
    }
};
const abrirChecklist = (unidad:Unidad) => {
    // Aquí validamos qué ID tiene el vehículo actual
    const idTipo = unidad.id_tipo_vehiculo;
    
    console.log("Cargando checklist para ID_TIPO_VEHICULO:", idTipo);

    setUnidadTemporal(unidad);
    setChecklistRespuestas({});
    
    // Al llamar a esta función, le pasamos el ID detectado
    cargarChecklist(idTipo); 
    
    setModalChecklistVisible(true);
};
    const [modoBusquedaManual, setModoBusquedaManual] = useState(false);
    const insets = useSafeAreaInsets();
    const { userData } = useAuth();
    const router = useRouter();
    const colorScheme = useColorScheme();
    const isDark = colorScheme === 'dark';

    // --- ESTADOS ---
    const [step, setStep] = useState(1);
    const [loading, setLoading] = useState(false);
    const [uploadProgress, setUploadProgress] = useState(0);
    const [uploadStatus, setUploadStatus] = useState('Subiendo...');
    const [isFinished, setIsFinished] = useState(false);
    const [fotos, setFotos] = useState<{ uri: string; base64: string }[]>([]);
   
    const [showPicker, setShowPicker] = useState(false);
    const [pickerMode, setPickerMode] = useState<'time' | 'date'>('time');
    const [activeField, setActiveField] = useState<string | null>(null);
    const [tempDate, setTempDate] = useState<Date>(new Date());
    const [tiposVia, setTiposVia] = useState([]);
    const [vias, setVias] = useState([]);        
    const [cuadras, setCuadras] = useState([]);  
    const [selTipoVia, setSelTipoVia] = useState<any>(null);
    const [selVia, setSelVia] = useState<any>(null);

    // --- NUEVOS ESTADOS EXCLUSIVOS PARA EL MODAL DE CHECKLIST ---


    const [catalogos, setCatalogos] = useState({
        usuarios: [], modalidades: [], origenes: [], camaras: [],
        tipos_patrullaje: [], modalidades_patrullaje: [],
        tipos_vehiculo: [], unidades: [], pnps: [], lugares: []
    });

    const [unidadForm, setUnidadForm] = useState({
        id_tipo_vehiculo: null as number | null,
        id_unidad: null as number | null,
        placa: '',
        tipo_asignacion: 'MUNICIPAL' as 'MUNICIPAL' | 'INTEGRADO',
        id_pnp: null as number | null
    });

    const getHoy = () => {
        const d = new Date();
        return new Date(d.getTime() - d.getTimezoneOffset() * 60000).toISOString().split('T')[0];
    };

    const [form, setForm] = useState({
        id_usuario: null,
        id_lugar: null,
        id_modalidad: '136',
        id_origen: '2',
        id_tipo_patrullaje: null,
        id_modalidad_patrullaje: '2',
        vehiculos_detalle: [] as any[],
        id_camara: [] as any[],
        descripcion: '',
        hora_alerta: '',
        hora_llegada: '',
        hora_repliegue: '',
        latitud_gps: '0',
        longitud_gps: '0',
        nombre_punto_gps: '',
        referencia: '',
        unidad_encargada: 'SERENAZGO',
        fecha_evento: getHoy(),
        grupo: null
    });

    // --- LÓGICA DE VALIDACIÓN ---
    const canAdvance = () => {
        if (step === 1) {
            const hasBasics = !!form.id_tipo_patrullaje && !!form.id_modalidad_patrullaje && !!form.id_origen && !!form.grupo;
            if (form.id_tipo_patrullaje === ID_PATRULLAJE_MOTORIZADO) return hasBasics && form.vehiculos_detalle.length > 0;
            return hasBasics;
        }
        if (step === 2) {
            const { hora_alerta, hora_llegada, hora_repliegue, fecha_evento } = form;
            const camposLlenos = !!hora_alerta && !!hora_llegada && !!hora_repliegue && !!fecha_evento;
            if (!camposLlenos) return false;
            const esCronologico = (form.hora_alerta <= form.hora_llegada) && (form.hora_llegada <= form.hora_repliegue);
            return esCronologico;
        }
        if (step === 3) return !!form.id_lugar;
        if (step === 4) return !!form.id_modalidad && form.descripcion.length > 0;
        return false;
    };

    const getDynamicBorderStyle = (value: any) => ({
        borderColor: value ? MJM_BLUE : (isDark ? '#444' : '#ddd'),
        borderWidth: value ? 1.5 : 1
    });

    // --- FUNCIÓN PARA FORMATEAR FECHA EN ESPAÑOL ---
    const formatearFechaEspañol = (fechaStr: string) => {
        if (!fechaStr) return "Seleccione fecha";
        const fecha = new Date(fechaStr + 'T12:00:00');
        const diasSemana = ['Domingo', 'Lunes', 'Martes', 'Miércoles', 'Jueves', 'Viernes', 'Sábado'];
        const meses = ['Enero', 'Febrero', 'Marzo', 'Abril', 'Mayo', 'Junio', 'Julio', 'Agosto', 'Septiembre', 'Octubre', 'Noviembre', 'Diciembre'];
        const diaSemana = diasSemana[fecha.getDay()];
        const dia = fecha.getDate();
        const mes = meses[fecha.getMonth()];
        const año = fecha.getFullYear();
        return `${diaSemana}, ${dia} de ${mes} de ${año}`;
    };

    // --- FUNCIÓN PARA FORMATEAR HORA EN 24H ---
    const formatearHora24h = (horaStr: string) => {
        if (!horaStr) return "00:00";
        if (/^([0-1][0-9]|2[0-3]):[0-5][0-9]$/.test(horaStr)) {
            return horaStr;
        }
        return "00:00";
    };

    // --- MANEJADOR DE CAMBIO DE FECHA ---
    const handleDateChange = (event: any, selectedDate?: Date) => {
        if (Platform.OS === 'android') {
            setShowPicker(false);
        }
        if (selectedDate) {
            const fechaStr = selectedDate.toISOString().split('T')[0];
            if (Platform.OS === 'android') {
                setTimeout(() => {
                    setForm(f => ({ ...f, fecha_evento: fechaStr }));
                }, 100);
            } else {
                setForm(f => ({ ...f, fecha_evento: fechaStr }));
            }
        }
        if (Platform.OS === 'ios') {
            setTempDate(selectedDate || new Date());
        }
    };

    // --- MANEJADOR DE CAMBIO DE HORA ---
    const handleTimeChange = (event: any, selectedTime?: Date) => {
        if (Platform.OS === 'android') {
            setShowPicker(false);
        }
        if (selectedTime && activeField) {
            const horaStr = selectedTime.toLocaleTimeString('en-GB', { 
                hour: '2-digit', 
                minute: '2-digit',
                hour12: false 
            });
            if (Platform.OS === 'android') {
                setTimeout(() => {
                    setForm(f => ({ ...f, [activeField!]: horaStr }));
                    setActiveField(null);
                }, 100);
            } else {
                setForm(f => ({ ...f, [activeField!]: horaStr }));
            }
        }
        if (Platform.OS === 'ios') {
            setTempDate(selectedTime || new Date());
        }
    };

    // --- CONFIRMAR SELECCIÓN EN iOS ---
    const confirmIOSSelection = () => {
        if (activeField === 'fecha_evento') {
            const fechaStr = tempDate.toISOString().split('T')[0];
            setForm(f => ({ ...f, fecha_evento: fechaStr }));
        } else if (activeField) {
            const horaStr = tempDate.toLocaleTimeString('en-GB', { 
                hour: '2-digit', 
                minute: '2-digit',
                hour12: false 
            });
            setForm(f => ({ ...f, [activeField]: horaStr }));
        }
        setShowPicker(false);
    };

    // --- EFECTOS E INICIALIZACIÓN ---
    useEffect(() => {
        if (userData) setForm(prev => ({ ...prev, id_usuario: userData.id || (userData as any).id_usuario }));
        setForm(prev => ({ ...prev, fecha_evento: getHoy() }));
        cargarCatalogosInit();
        obtenerGpsAutomatico();
    }, [userData]);

    const obtenerGpsAutomatico = async () => {
        try {
            let lat, lon;
            if (Platform.OS === 'web') { lat = -12.073769; lon = -77.039673; }
            else {    
                let { status } = await Location.requestForegroundPermissionsAsync();
                if (status !== 'granted') return;
                const loc = await Location.getCurrentPositionAsync({ accuracy: Location.Accuracy.Balanced });
                lat = loc.coords.latitude; lon = loc.coords.longitude;
            }
            setForm(prev => ({ ...prev, latitud_gps: lat.toString(), longitud_gps: lon.toString() }));
            const reverseGeocode = await Location.reverseGeocodeAsync({ latitude: lat, longitude: lon });
            if (reverseGeocode.length > 0) {
                const p = reverseGeocode[0];
                const direccionNombre = `${p.street || ''} ${p.streetNumber || ''}, ${p.district || p.city || ''}`.trim();
                setForm(prev => ({ ...prev, nombre_punto_gps: direccionNombre || 'Ubicación identificada' }));
            }
        } catch (e) { console.error("Error GPS:", e); }
    };
const checklist_final = checklistItems.map(item => ({
    id_item: item.id_item,
    esta_conforme: checklistRespuestas[item.id_item]?.conforme ? 1 : 0,
    observacion: checklistRespuestas[item.id_item]?.obs || ""
}));


    const cargarCatalogosInit = async () => {
        try {
            const [resGral, resTiposV, resPnps] = await Promise.all([
                fetch(`${API_URL}/catalogos/completo/unificadov?tipoLugar=2&idTipoP=1&idTipoP=2&idTipoP=3&idTipoP=4`),
                fetch(`${API_URL}/catalogos/tipos-vehiculo`),
                fetch(`${API_URL}/catalogos/pnp-activos`)
            ]);
            const data = await resGral.json();
            setCatalogos({
                usuarios: data.usuarios || [], modalidades: data.modalidades || [], origenes: data.origenes || [],
                camaras: data.camara || [], tipos_patrullaje: data.tipos_patrullaje || [],
                modalidades_patrullaje: data.modalidades_patrullaje || [],
                tipos_vehiculo: await resTiposV.json() || [], unidades: [], pnps: await resPnps.json() || [], lugares: data.lugares|| []
            });
            setTiposVia(data.tipos_via || []);
        } catch (err) { console.error("Error catálogos:", err); }
    };

    const fetchUnidades = async (idTipo: any) => {
        try {
            const res = await fetch(`${API_URL}/catalogos/vehiculos-por-tipo/${idTipo}`);
            const data = await res.json();
            setCatalogos(prev => ({ ...prev, unidades: data }));
        } catch (e) { console.error(e); }
    };

    // --- ACCIONES DE FORMULARIO MODIFICADA SÓLO EN PASO 1 ---
    const agregarVehiculo = () => {
        if (!unidadForm.id_unidad) return Alert.alert("Atención", "Seleccione una unidad/placa.");
        
        const yaExiste = form.vehiculos_detalle.some(v => v.id_unidad === unidadForm.id_unidad);
        if (yaExiste) return Alert.alert("Atención", `La placa ${unidadForm.placa} ya ha sido agregada.`);

        const esCamioneta = unidadForm.id_tipo_vehiculo === ID_CAMIONETA;
        const asignacionFinal = esCamioneta ? unidadForm.tipo_asignacion : 'MUNICIPAL';
        const pnpFinal = (esCamioneta && asignacionFinal === 'INTEGRADO') ? unidadForm.id_pnp : null;
        if (asignacionFinal === 'INTEGRADO' && !pnpFinal) return Alert.alert("Atención", "Efectivo PNP requerido.");

        // En vez de inyectarlo directo, guardamos la configuración en un estado temporal y abrimos el Modal
        setUnidadTemporal({
            id_tipo_vehiculo: unidadForm.id_tipo_vehiculo,
            id_unidad: unidadForm.id_unidad,
            placa: unidadForm.placa,
            tipo_asignacion: asignacionFinal,
            id_pnp: pnpFinal,
            nombre_pnp: (catalogos.pnps.find((p: any) => String(p.value) === String(unidadForm.id_pnp)) as any)?.label || ''
        });
        
        setOdometroInicial('');
      
        setModalChecklistVisible(true); 
    };

  const confirmarChecklistUnidad = () => {
    if (!odometroInicial.trim()) { 
        Alert.alert("Error", "Odómetro requerido"); 
        return; 
    }
    
    const checklist_items = checklistItems.map(item => {
        // Obtenemos la respuesta guardada
        const respuesta = checklistRespuestas[item.id_item];
        
        // Lógica: Si existe respuesta, usamos su valor. 
        // Si no existe (es undefined), asumimos que está conforme (1).
        const esConforme = respuesta !== undefined ? respuesta.conforme : true;

        return {
            id_item: item.id_item,
            esta_conforme: esConforme ? 1 : 0,
            observacion: respuesta?.obs || ""
        };
    });

    setForm((prev: any) => ({
        ...prev,
        vehiculos_detalle: [...prev.vehiculos_detalle, { 
            ...unidadTemporal,
            odometro_inicial: odometroInicial,
            checklist_items: checklist_items 
        }]
    }));

    setModalChecklistVisible(false);
};
    const handleTipoViaChange = async (idTipo: any) => {
        setSelTipoVia(idTipo); setSelVia(null); setCuadras([]);
        setForm(f => ({ ...f, id_lugar: null }));
        try {
            const res = await fetch(`${API_URL}/catalogos/vias/${idTipo}`);
            setVias(await res.json());
        } catch (err) { console.error(err); }
    };

    const handleViaChange = async (idVia: any) => {
        setSelVia(idVia);
        setForm(f => ({ ...f, id_lugar: null }));
        try {
            const res = await fetch(`${API_URL}/catalogos/cuadras/${idVia}`);
            setCuadras(await res.json());
        } catch (err) { console.error(err); }
    };

    const capturarHoraActual = (campo: string) => {
        const ahora = new Date().toLocaleTimeString('en-GB', { hour12: false, hour: '2-digit', minute: '2-digit' });
        setForm(f => ({ ...f, [campo]: ahora }));
    };

    const tomarFoto = async () => {
        if (fotos.length >= MAX_FOTOS) return Alert.alert("Límite", "Máximo 5 fotos.");
        const { status } = await ImagePicker.requestCameraPermissionsAsync();
        if (status !== 'granted') return Alert.alert("Error", "Sin permiso de cámara");
        let res = await ImagePicker.launchCameraAsync({ base64: true, quality: 0.3 });
        if (!res.canceled) setFotos(p => [...p, { uri: res.assets[0].uri, base64: `data:image/jpeg;base64,${res.assets[0].base64}` }]);
    };

    const seleccionarGaleria = async () => {
        if (fotos.length >= MAX_FOTOS) return Alert.alert("Límite", "Máximo 5 fotos.");
        let res = await ImagePicker.launchImageLibraryAsync({ base64: true, allowsMultipleSelection: true, quality: 0.3, selectionLimit: MAX_FOTOS - fotos.length });
        if (!res.canceled) {
            const nuevas = res.assets.map(a => ({ uri: a.uri, base64: `data:image/jpeg;base64,${a.base64}` }));
            setFotos(p => [...p, ...nuevas].slice(0, MAX_FOTOS));
        }
    };

    const enviarRegistro = async () => {
        const idFinal = form.id_usuario || userData?.id || (userData as any)?.id_usuario;

        if (!idFinal) {
            Alert.alert("Atención", "No se pudo identificar al usuario. Verifique su conexión o reinicie sesión.");
            return;
        }

        setLoading(true); 
        setUploadProgress(0); 
        setUploadStatus('Subiendo...'); 
        setIsFinished(false);

        const interval = setInterval(() => setUploadProgress(p => (p < 90 ? p + 10 : p)), 150);
        try {
            const res = await fetch(`${API_URL}/api/vehiculo/iniciar-servicio-checkcompleto`, {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({
                    ...form,
                    id_usuario: Number(idFinal),
                    id_tipop: form.id_tipo_patrullaje,
                    id_modalidadp: form.id_modalidad_patrullaje,
                    id_camara: form.id_camara.map(c => (c as any).value).join(','),
                    fotos: fotos.map(f => ({ base64_data: f.base64 }))
                })
            });
            clearInterval(interval);
            
            if (res.ok) {
                setUploadProgress(100); 
                setUploadStatus('¡Listo! Subido');
                setIsFinished(true);
                setTimeout(() => { 
                    setLoading(false); 
                    router.replace('/(tabs)' as any); 
                }, 1200);
            } else { 
                const errorData = await res.json();
                setLoading(false); 
                Alert.alert("Error", errorData.error || "No se pudo guardar el registro.");
            }
        } catch (e) { 
            clearInterval(interval); 
            setLoading(false);
            Alert.alert("Error", "Error de conexión con el servidor."); 
        }
    };

    const renderMosaicos = (data: any[], currentId: any, field: string, iconDefault: string) => (
        <View style={styles.mosaicoGrid}>
            {data.map((item: any) => (
                <Pressable key={item.value} onPress={() => setForm({ ...form, [field]: item.value })} style={[styles.mosaicoItem, currentId === item.value && styles.mosaicoSelected]}>
                    <Ionicons name={iconDefault as any} size={18} color={currentId === item.value ? 'white' : MJM_BLUE} />
                    <ThemedText style={[styles.mosaicoText, currentId === item.value && { color: 'white' }]}>{item.label}</ThemedText>
                </Pressable>
            ))}
        </View>
    );

    const dynamicStyles = {
        card: { backgroundColor: 'white' },
        textInput: { backgroundColor: 'white', color: '#000000', borderColor: isDark ? '#cccccc' : '#eeeeee' },
        label: { color: '#333333' },
        sectionTitle: { color: MJM_BLUE },
        dropdown: { backgroundColor: 'white', color: '#000000' },
        timeText: { color: MJM_BLUE }
    };

    return (
        <ThemedView style={[styles.main, { paddingTop: insets.top, backgroundColor: isDark ? '#ffffff' : '#f4f7f6' }]}>
            
            <View style={styles.stepperContainer}>
                <ThemedText style={[styles.sectionTitle, dynamicStyles.sectionTitle]}>CUADERNOS DE CONTROL:</ThemedText>
                {[1, 2, 3, 4].map(i => (
                    <View key={i} style={[styles.circle, step >= i && { backgroundColor: MJM_BLUE }]}>
                        <ThemedText style={{color:'white', fontWeight:'bold', fontSize: 11}}>{i}</ThemedText>
                    </View>
                ))}
            </View>

            <ScrollView contentContainerStyle={styles.scroll} keyboardShouldPersistTaps="handled">
              {step === 1 && (
                                <View style={[styles.card, dynamicStyles.card]}>
                                    <ThemedText style={[styles.sectionTitle, dynamicStyles.sectionTitle]}>PASO 1: DESPACHO</ThemedText>
                                  
                                    <View style={{backgroundColor: isDark ? '#ffffff' : '#eef2ff', padding: 10, borderRadius: 8, marginBottom: 15, borderWidth: 1, borderColor: MJM_BLUE}}>
                                        <View style={{flexDirection:'row', alignItems:'center', gap:5}}>
                                            <Ionicons name="location" size={14} color={MJM_BLUE} />
                                            <ThemedText style={{fontSize: 10, color: MJM_BLUE, fontWeight: 'bold'}}>ENVIAR REPORTE DESDE:</ThemedText>
                                        </View>
                                        <ThemedText style={{fontSize: 11, color: '#000000', marginTop: 2}}>{form.nombre_punto_gps || "CSI MDJM"}</ThemedText>
                                    </View>
                                    
                                    <ThemedText style={styles.label}>GRUPO</ThemedText>
                                    <ScrollView showsHorizontalScrollIndicator={false} contentContainerStyle={styles.label}>
                                        {renderMosaicos(
                                            [
                                                {label: 'GRUPO 1', value: '1'}, 
                                                {label: 'GRUPO 2', value: '2'}, 
                                                {label: 'GRUPO 3', value: '3'},
                                                {label: 'GRUPO 4', value: '4'}
                                            ], 
                                            form.grupo, 
                                            'grupo', 
                                            'people-outline'
                                        )}
                                    </ScrollView>
            
                                    <ThemedText style={[styles.label, dynamicStyles.label]}>TIPO DE PATRULLAJE</ThemedText>
                                    {renderMosaicos(catalogos.tipos_patrullaje, form.id_tipo_patrullaje, 'id_tipo_patrullaje', 'shield-checkmark-outline')}
                          
                                    {form.id_tipo_patrullaje === ID_PATRULLAJE_MOTORIZADO && (
                                        <View style={[styles.cascadaContainer, getDynamicBorderStyle(form.vehiculos_detalle.length > 0)]}>
                                            <View style={styles.cascadaHeader}>
                                                <Ionicons name="car-sport" size={16} color={MJM_BLUE} />
                                                <ThemedText style={styles.cascadaTitle}>UNIDADES ASIGNADAS</ThemedText>
                                            </View>
            
 <Dropdown 
    style={[styles.dropdown, dynamicStyles.dropdown]} 
    data={catalogos.tipos_vehiculo} // Aquí asegúrate que tus datos tengan value="1" para moto, "2" para camioneta
    labelField="label" 
    valueField="value" 
    placeholder="Tipo Vehículo" 
    value={unidadForm.id_tipo_vehiculo} 
    onChange={v => { 
        // AL SELECCIONAR: actualizas el ID y reseteas lo demás
        setUnidadForm({ 
            ...unidadForm, 
            id_tipo_vehiculo: v.value, // Esto será '1' o '2'
            id_unidad: null, 
            placa: ''
        });
        fetchUnidades(v.value); 
    }} 
/>

                {/* ... (Tu lógica de TIPO DE ASIGNACIÓN e INTEGRADO se mantiene igual) ... */}

                {/* SECCIÓN DE SELECCIÓN DE UNIDAD Y BOTÓN CHECKLIST */}
                <View style={{ flexDirection: 'row', gap: 10, alignItems: 'flex-end', marginTop: 10 }}>
                    <View style={{ flex: 1 }}>
                        <Dropdown 
                            style={[styles.dropdown, dynamicStyles.dropdown]} 
                            data={catalogos.unidades} 
                            labelField="label" 
                            valueField="value" 
                            placeholder="Seleccione Placa" 
                            value={unidadForm.id_unidad} 
                            onChange={v => setUnidadForm({ ...unidadForm, id_unidad: v.value, placa: v.label })} 
                        />
                    </View>
<Pressable 
    style={[styles.btnAddUnit, { backgroundColor: MJM_BLUE }]} 
    onPress={() => {
        // Validamos que los valores no sean nulos antes de llamar
        if (!unidadForm.id_unidad || !unidadForm.id_tipo_vehiculo) {
            Alert.alert("Error", "Seleccione una unidad y tipo de vehículo");
            return;
        }

        // Pasamos la copia del objeto asegurando que no sea nulo
        abrirChecklist({
            ...unidadForm,
            id_unidad: unidadForm.id_unidad,
            id_tipo_vehiculo: unidadForm.id_tipo_vehiculo
        } as Unidad);
    }}
>
    <Ionicons name="checkbox" size={24} color="white" />
</Pressable>
                </View>

                {/* LISTADO DE UNIDADES YA AGREGADAS */}
          {form.vehiculos_detalle.length > 0 && (
                                             <View style={styles.listadoUnidadesContainer}>
                                                 <View style={styles.listadoHeader}>
                                                     <ThemedText style={styles.listadoTitle}>UNIDADES EN EL REPORTE ({form.vehiculos_detalle.length})</ThemedText>
                                                 </View>
                                                 {form.vehiculos_detalle.map((v, index) => (
                                                     <View key={index} style={[styles.unitCard, { backgroundColor: isDark ? '#262626' : '#fff' }]}>
                                                         <View style={styles.unitCardIcon}>
                                                             <Ionicons name={v.id_tipo_vehiculo === ID_CAMIONETA ? "car" : "bicycle"} size={20} color={MJM_BLUE} />
                                                         </View>
                                                         <View style={{ flex: 1, marginLeft: 10 }}>
                                                             <ThemedText style={styles.unitCardPlaca}>{v.placa} {v.odometro_inicial ? `(KM: ${v.odometro_inicial})` : ''}</ThemedText>
                                                             <ThemedText style={styles.unitCardSub}>
                                                                 {v.tipo_asignacion} {v.nombre_pnp ? `| PNP: ${v.nombre_pnp}` : ''}
                                                             </ThemedText>
                                                         </View>
                                                         <Pressable 
                                                             onPress={() => {
                                                                 const nuevos = form.vehiculos_detalle.filter((_, i) => i !== index);
                                                                 setForm({ ...form, vehiculos_detalle: nuevos });
                                                             }}
                                                             style={styles.unitCardRemove}
                                                         >
                                                             <Ionicons name="trash-outline" size={18} color="#ff4444" />
                                                         </Pressable>
                                                     </View>
                                                 ))}
                                             </View>
                                         )}
            </View>
        )}
    </View>
)}

                {step === 2 && (
                    <View style={[styles.card, dynamicStyles.card, { backgroundColor: '#FFF' }]}>
                        <ThemedText style={[styles.sectionTitle, dynamicStyles.sectionTitle]}>PASO 2: TIEMPOS</ThemedText>
                        
                        <View style={{ flexDirection: 'row', justifyContent: 'space-between', marginBottom: 10 }}>
                            <ThemedText style={[styles.cascadaTitle, { marginLeft: 5, fontSize: 12 }]}>FECHA DEL EVENTO</ThemedText>
                            <Pressable 
                                onPress={() => setForm({...form, fecha_evento: getHoy()})}
                                style={{ backgroundColor: MJM_BLUE, paddingHorizontal: 12, paddingVertical: 6, borderRadius: 6 }}
                            >
                                <ThemedText style={{ color: 'white', fontSize: 11, fontWeight: 'bold' }}>PONER HOY</ThemedText>
                            </Pressable>
                        </View>

                        {Platform.OS === 'web' ? (
                            <input
                                type="date"
                                value={form.fecha_evento}
                                onChange={(e) => setForm({ ...form, fecha_evento: e.target.value })}
                                style={styles.webPickerInput}
                            />
                        ) : (
                            <Pressable 
                                onPress={() => { 
                                    setPickerMode('date'); 
                                    setActiveField('fecha_evento'); 
                                    setTempDate(new Date(form.fecha_evento + 'T12:00:00'));
                                    setShowPicker(true); 
                                }} 
                                style={[
                                    styles.pickerPressable, 
                                    { backgroundColor: '#FFFFFF', borderColor: MJM_BLUE, borderWidth: 1 }, 
                                    getDynamicBorderStyle(form.fecha_evento)
                                ]}
                            >
                                <Ionicons name="calendar-outline" size={20} color={MJM_BLUE} />
                                <ThemedText style={{ color: '#000', marginLeft: 10 }}>
                                    {formatearFechaEspañol(form.fecha_evento)}
                                </ThemedText>
                            </Pressable>
                        )}

                        {['hora_alerta', 'hora_llegada', 'hora_repliegue'].map((k) => (
                            <View key={k} style={{ marginTop: 15 }}>
                                <ThemedText style={[styles.label, dynamicStyles.label]}>
                                    {k.toUpperCase().replace('_', ' ')}
                                </ThemedText>
                                <View style={styles.timeRow}>
                                    {Platform.OS === 'web' ? (
                                        <input 
                                            type="time" 
                                            value={(form as any)[k]} 
                                            onChange={(e) => setForm({ ...form, [k]: e.target.value })} 
                                            style={styles.webTimeInput} 
                                        />
                                    ) : (
                                        <Pressable 
                                            onPress={() => { 
                                                setPickerMode('time'); 
                                                setActiveField(k); 
                                                const currentTime = (form as any)[k];
                                                const date = new Date(); 
                                                if (currentTime && currentTime !== '00:00') { 
                                                    const [hours, minutes] = currentTime.split(':'); 
                                                    date.setHours(parseInt(hours), parseInt(minutes)); 
                                                } 
                                                setTempDate(date); 
                                                setShowPicker(true); 
                                            }} 
                                            style={[styles.pickerPressable, { flex: 1, backgroundColor: '#FFF' }]} 
                                        >
                                            <Ionicons name="time-outline" size={20} color={MJM_BLUE} />
                                            <ThemedText style={{ color: '#000', marginLeft: 10 }}>
                                                {formatearHora24h((form as any)[k]) || "00:00"}
                                            </ThemedText>
                                        </Pressable>
                                    )}
                                    <Pressable style={styles.btnTime} onPress={() => capturarHoraActual(k)}>
                                        <Ionicons name="flash" size={20} color="white" />
                                    </Pressable>
                                </View>
                            </View>
                        ))}

                        {form.hora_alerta && form.hora_llegada && form.hora_repliegue && !(form.hora_alerta <= form.hora_llegada && form.hora_llegada <= form.hora_repliegue) && (
                            <View style={styles.errorSecuenciaContainer}>
                                <Ionicons name="alert-circle" size={20} color="#D32F2F" style={{ marginRight: 10 }} />
                                <View style={{ flex: 1 }}>
                                    <ThemedText style={{ color: '#D32F2F', fontSize: 13, fontWeight: 'bold' }}> Error en secuencia de tiempo </ThemedText>
                                    <ThemedText style={{ color: '#555', fontSize: 11 }}> {"El orden debe ser: Repliegue > Llegada > Alerta"} </ThemedText>
                                </View>
                            </View>
                        )}
                    </View>
                )}

                {step === 3 && (
                    <View style={styles.cascadaContainer}>
                        <ThemedText style={[styles.sectionTitle, dynamicStyles.sectionTitle]}>PASO 3: UBICACIÓN</ThemedText>
                        <View style={{ flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', marginBottom: 15 }}>
                            <View style={{ flexDirection: 'row', alignItems: 'center' }}>
                                <Ionicons name="location" size={18} color={MJM_BLUE} />
                                <ThemedText style={[styles.cascadaTitle, { marginLeft: 5 }]}> 
                                    {modoBusquedaManual ? "BÚSQUEDA MANUAL" : "DIRECCIÓN DIRECTA"} 
                                </ThemedText>
                            </View>
                            <Pressable 
                                onPress={() => { setModoBusquedaManual(!modoBusquedaManual); setForm({...form, id_lugar: null}); }} 
                                style={[styles.btnToggleModo, modoBusquedaManual && { backgroundColor: '#E3F2FD' }]}
                            >
                                <ThemedText style={{ color: MJM_BLUE, fontSize: 10, fontWeight: 'bold' }}> 
                                    {modoBusquedaManual ? "USAR LISTADO" : "POR CALLE/CUADRA"} 
                                </ThemedText>
                            </Pressable>
                        </View>

                        {!modoBusquedaManual && (
                            <View style={{ marginBottom: 10 }}>
                                <Dropdown 
                                    style={styles.dropdownUbicacionDirecta} 
                                    data={catalogos?.lugares || []} 
                                    search 
                                    searchPlaceholder="Buscar dirección..." 
                                    labelField="label" 
                                    valueField="value" 
                                    placeholder="Seleccione la ubicación..." 
                                    value={form.id_lugar} 
                                    onChange={item => setForm({...form, id_lugar: item.value})} 
                                />
                            </View>
                        )}

                        {modoBusquedaManual && (
                            <View style={styles.cascadaGrid}>
                                <View style={{ flex: 1 }}>
                                    <ThemedText style={styles.labelSubCascada}>TIPO</ThemedText>
                                    <Dropdown style={styles.dropdownCascadaItem} data={tiposVia || []} labelField="label" valueField="value" placeholder="Tipo" value={selTipoVia} onChange={item => handleTipoViaChange(item.value)} placeholderStyle={{ fontSize: 11, color: '#999' }} selectedTextStyle={{ fontSize: 11, fontWeight: 'bold', color: MJM_BLUE }} />
                                </View>
                                <View style={{ flex: 2.2 }}>
                                    <ThemedText style={styles.labelSubCascada}>CALLE / VÍA</ThemedText>
                                    <Dropdown style={[styles.dropdownCascadaItem, !selTipoVia && styles.dropdownDisabled]} disable={!selTipoVia} data={vias || []} search searchPlaceholder="Calle..." labelField="label" valueField="value" placeholder="Nombre de vía..." value={selVia} onChange={item => handleViaChange(item.value)} placeholderStyle={{ fontSize: 11, color: '#999' }} selectedTextStyle={{ fontSize: 11, fontWeight: 'bold', color: MJM_BLUE }} />
                                </View>
                                <View style={{ flex: 0.9 }}>
                                    <ThemedText style={styles.labelSubCascada}>CDRA</ThemedText>
                                    <Dropdown style={[styles.dropdownCascadaItem, !selVia && styles.dropdownDisabled]} disable={!selVia} data={cuadras || []} labelField="label" valueField="value" placeholder="N°" value={form.id_lugar} onChange={item => setForm({...form, id_lugar: item.value})} placeholderStyle={{ fontSize: 11, color: '#999' }} selectedTextStyle={{ fontSize: 11, fontWeight: 'bold', color: MJM_BLUE }} />
                                </View>
                            </View>
                        )}

                        <View style={{ marginTop: 20 }}>
                            <View style={{ flexDirection: 'row', alignItems: 'center', marginBottom: 5 }}>
                                <Ionicons name="map-outline" size={14} color={MJM_BLUE} />
                                <ThemedText style={[styles.cascadaTitle, { marginLeft: 5, fontSize: 12 }]}>REFERENCIA / INTERSECCIÓN</ThemedText>
                            </View>
                            <TextInput style={[styles.textAreaSmall, { borderColor: form.referencia.length >= 3 ? MJM_BLUE : '#DDD' }]} placeholder="Ej: A media cuadra del grifo Primax..." placeholderTextColor="#AAA" value={form.referencia} onChangeText={t => setForm({...form, referencia: t})} multiline />
                        </View>
                    </View>
                )}

                {step === 4 && (
                    <View style={[styles.card, dynamicStyles.card]}>
                        <ThemedText style={[styles.sectionTitle, dynamicStyles.sectionTitle]}>PASO 4: EVENTO Y SUCESO</ThemedText>
                        
                        <ThemedText style={[styles.label, dynamicStyles.label]}>MODALIDAD DE OCURRENCIA</ThemedText>
                        <Dropdown style={[styles.dropdown, dynamicStyles.dropdown]} data={catalogos.modalidades} search labelField="label" valueField="value" placeholder="Seleccione Modalidad" value={form.id_modalidad} onChange={v => setForm({ ...form, id_modalidad: v.value })} />

                        <ThemedText style={[styles.label, dynamicStyles.label, { marginTop: 15 }]}>DESCRIPCIÓN DE HECHOS</ThemedText>
                        <TextInput style={styles.textArea} multiline numberOfLines={4} placeholder="Detalles de lo acontecido..." placeholderTextColor="#999" value={form.descripcion} onChangeText={t => setForm({ ...form, descripcion: t })} />

                        <ThemedText style={[styles.label, dynamicStyles.label, { marginTop: 15 }]}>EVIDENCIA FOTOGRÁFICA ({fotos.length}/{MAX_FOTOS})</ThemedText>
                        <View style={{ flexDirection: 'row', gap: 10, marginTop: 5 }}>
                            <Pressable style={styles.btnFoto} onPress={tomarFoto}>
                                <Ionicons name="camera" size={22} color="white" />
                                <ThemedText style={styles.btnFotoText}>Cámara</ThemedText>
                            </Pressable>
                            <Pressable style={[styles.btnFoto, { backgroundColor: '#6c757d' }]} onPress={seleccionarGaleria}>
                                <Ionicons name="images" size={22} color="white" />
                                <ThemedText style={styles.btnFotoText}>Galería</ThemedText>
                            </Pressable>
                        </View>

                        <ScrollView horizontal style={{ marginTop: 10 }} showsHorizontalScrollIndicator={false}>
                            {fotos.map((f, i) => (
                                <View key={i} style={styles.wrapperFoto}>
                                    <Image source={{ uri: f.uri }} style={styles.previewFoto} />
                                    <Pressable style={styles.btnBorrarFoto} onPress={() => setFotos(p => p.filter((_, idx) => idx !== i))}>
                                        <Ionicons name="close-circle" size={20} color="red" />
                                    </Pressable>
                                </View>
                            ))}
                        </ScrollView>
                    </View>
                )}

                {/* BOTONES DE NAVEGACIÓN GENERAL */}
                <View style={styles.navRow}>
                    {step > 1 && (
                        <Pressable style={styles.btnBack} onPress={() => setStep(step - 1)}>
                            <ThemedText style={{ color: MJM_BLUE, fontWeight: 'bold' }}>Atrás</ThemedText>
                        </Pressable>
                    )}
                    
                    {step < 4 ? (
                        <Pressable style={[styles.btnNext, !canAdvance() && styles.btnDisabled]} disabled={!canAdvance()} onPress={() => setStep(step + 1)}>
                            <ThemedText style={{ color: 'white', fontWeight: 'bold' }}>Siguiente</ThemedText>
                        </Pressable>
                    ) : (
                        <Pressable style={[styles.btnNext, { backgroundColor: '#28a745' }, !canAdvance() && styles.btnDisabled]} disabled={!canAdvance() || loading} onPress={enviarRegistro}>
                            <ThemedText style={{ color: 'white', fontWeight: 'bold' }}>{loading ? "Subiendo..." : "Finalizar"}</ThemedText>
                        </Pressable>
                    )}
                </View>
            </ScrollView>

            {/* PICKERS NATIVOS */}
            {showPicker && (
                <DateTimePicker
                    value={tempDate}
                    mode={pickerMode}
                    is24Hour={true}
                    display={Platform.OS === 'ios' ? 'spinner' : 'default'}
                    onChange={pickerMode === 'date' ? handleDateChange : handleTimeChange}
                />
            )}

            {/* MODAL CHECKLIST (SE ABRE EN EL PASO 1 LUEGO DE DAR CLIC EN "+" MÓVIL) */}
{/* MODAL DE CHECKLIST */}
   <Modal 
    animationType="slide" 
    transparent={true} 
    visible={modalChecklistVisible} 
    onRequestClose={() => setModalChecklistVisible(false)}
>
    <View style={styles.modalOverlay}>
        <View style={[styles.modalContent, { width: '94%', maxHeight: '90%', padding: 0 }]}>
            
            {/* HEADER */}
            <View style={{ 
                flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', 
                padding: 20, borderBottomWidth: 1, borderBottomColor: '#eee' 
            }}>
                <View>
                    <ThemedText style={{ fontSize: 18, fontWeight: 'bold', color: MJM_BLUE }}>📋 CHECKLIST OPERATIVO</ThemedText>
                    <ThemedText style={{ fontSize: 12, color: '#666' }}>UNIDAD: {unidadTemporal?.placa}</ThemedText>
                </View>
                <Pressable onPress={() => setModalChecklistVisible(false)} style={{ padding: 8, backgroundColor: '#f0f0f0', borderRadius: 20 }}>
                    <Ionicons name="close" size={20} color="#333" />
                </Pressable>
            </View>

            {/* CUERPO */}
            <ScrollView style={{ padding: 20 }} showsVerticalScrollIndicator={false}>
                
                <View style={{ marginBottom: 25 }}>
                    <ThemedText style={{ fontSize: 13, fontWeight: '700', marginBottom: 8, color: '#444' }}>🔢 ODÓMETRO INICIAL (KM)</ThemedText>
                   <TextInput 
  style={[styles.modalInputText, { backgroundColor: '#f8fafc', fontSize: 16 }]} 
  placeholder="Ingrese kilometraje..." 
  keyboardType="numeric" 
  value={odometroInicial} 
  onChangeText={(text) => {
    // Reemplaza cualquier carácter que no sea un número por una cadena vacía
    const numericValue = text.replace(/[^0-9]/g, '');
    setOdometroInicial(numericValue);
  }}
/>
                </View>

                {/* RENDERIZADO AGRUPADO EN 2 COLUMNAS */}
                {Object.entries(
                    (checklistItems || []).reduce((acc: Record<string, any[]>, item: any) => {
                        const cat = item.nombre_categoria || "GENERAL";
                        if (!acc[cat]) acc[cat] = [];
                        acc[cat].push(item);
                        return acc;
                    }, {})
                ).map(([categoria, items]) => (
                    <View key={categoria} style={{ marginBottom: 20 }}>
                        <ThemedText style={{ 
                            fontSize: 12, fontWeight: '800', color: MJM_BLUE, letterSpacing: 1, 
                            marginBottom: 10, backgroundColor: '#eef2ff', paddingHorizontal: 10, 
                            paddingVertical: 4, alignSelf: 'flex-start', borderRadius: 4 
                        }}>
                            {categoria.toUpperCase()}
                        </ThemedText>

                        <View style={{ flexDirection: 'row', flexWrap: 'wrap', justifyContent: 'space-between' }}>
                            {items.map((item: any) => {
                                const resp = checklistRespuestas[item.id_item] || { conforme: true, obs: "" };
                                
                                return (
                                    <View key={item.id_item} style={{ width: '48%', marginBottom: 15 }}>
                                        <Pressable 
                                            style={{
                                                flexDirection: 'column', alignItems: 'center', justifyContent: 'center',
                                                backgroundColor: resp.conforme ? '#fff' : '#fff5f5',
                                                padding: 10, borderRadius: 12, borderWidth: 1,
                                                borderColor: resp.conforme ? '#e2e8f0' : '#feb2b2',
                                                minHeight: 85
                                            }}
                                            onPress={() => setChecklistRespuestas(prev => ({
                                                ...prev,
                                                [item.id_item]: { 
                                                    conforme: !(prev[item.id_item]?.conforme ?? true),
                                                    obs: !(prev[item.id_item]?.conforme ?? true) ? "" : (prev[item.id_item]?.obs || "")
                                                }
                                            }))}
                                        >
                                            <Ionicons 
                                                name={resp.conforme ? "checkmark-circle" : "alert-circle"} 
                                                size={28} color={resp.conforme ? "#22c55e" : "#ef4444"} 
                                            />
                                            <ThemedText style={{ 
                                                fontSize: 11, textAlign: 'center', marginTop: 6,
                                                color: resp.conforme ? '#334155' : '#c53030',
                                                fontWeight: resp.conforme ? '500' : '700' 
                                            }}>
                                                {item.nombre_item}
                                            </ThemedText>
                                        </Pressable>

                                        {!resp.conforme && (
                                            <TextInput 
                                                style={{
                                                    marginTop: 5, backgroundColor: '#fff', borderWidth: 1, 
                                                    borderColor: '#feb2b2', padding: 8, borderRadius: 8, 
                                                    fontSize: 10, color: '#c53030'
                                                }}
                                                placeholder="Falla..."
                                                value={resp.obs}
                                                onChangeText={(text) => setChecklistRespuestas(prev => ({
                                                    ...prev, 
                                                    [item.id_item]: { conforme: false, obs: text }
                                                }))}
                                            />
                                        )}
                                    </View>
                                );
                            })}
                        </View>
                    </View>
                ))}
            </ScrollView>

            {/* FOOTER */}
            <View style={{ padding: 20, borderTopWidth: 1, borderTopColor: '#eee' }}>
                <Pressable 
                    style={{ 
                        backgroundColor: MJM_BLUE, paddingVertical: 15, borderRadius: 12, 
                        alignItems: 'center', elevation: 5 
                    }} 
                    onPress={confirmarChecklistUnidad}
                >
                    <ThemedText style={{ color: 'white', fontWeight: 'bold', fontSize: 16 }}>GUARDAR CHECKLIST</ThemedText>
                </Pressable>
            </View>
        </View>
    </View>
</Modal>

            {/* MODAL DE PROGRESO DE SUBIDA */}
            <Modal transparent visible={loading && uploadProgress > 0} animationType="fade">
                <View style={styles.modalOverlay}>
                    <View style={styles.modalContent}>
                        <ThemedText style={styles.progressTitle}>{uploadStatus}</ThemedText>
                        <View style={styles.progressBarBackground}>
                            <View style={[styles.progressBarFill, { width: `${uploadProgress}%` }]} />
                        </View>
                        <ThemedText style={styles.progressPercentage}>{uploadProgress}%</ThemedText>
                    </View>
                </View>
            </Modal>
        </ThemedView>
    );
}

const styles = StyleSheet.create({

  
    sectionTitle: { color: MJM_BLUE, fontSize: 18, fontWeight: 'bold', marginBottom: 15 },
   
    checklistRow: { flexDirection: 'row', alignItems: 'center', paddingVertical: 10, borderBottomWidth: 0.5, borderColor: '#eee' },
    obsInput: { borderBottomWidth: 1, borderColor: '#ccc', fontSize: 12, paddingVertical: 2 },
    btnConfirmar: { backgroundColor: MJM_BLUE, padding: 15, borderRadius: 8, alignItems: 'center', marginTop: 10 },
    main: { flex: 1 },
    scroll: { padding: 15, paddingBottom: 40 },
    stepperContainer: { flexDirection: 'row', alignItems: 'center', justifyContent: 'center', gap: 10, marginVertical: 10, paddingHorizontal: 15 },
    circle: { width: 24, height: 24, borderRadius: 12, backgroundColor: '#ccc', justifyContent: 'center', alignItems: 'center' },
    card: { padding: 15, borderRadius: 12, elevation: 3, shadowColor: '#000', shadowOpacity: 0.1, shadowRadius: 4, marginBottom: 15 },
    
    label: { fontSize: 12, fontWeight: '700', marginBottom: 5, marginTop: 10 },
    mosaicoGrid: { flexDirection: 'row', flexWrap: 'wrap', gap: 8, marginTop: 5 },
    mosaicoItem: { flexDirection: 'row', alignItems: 'center', gap: 6, paddingVertical: 10, paddingHorizontal: 12, borderRadius: 8, borderWidth: 1, borderColor: '#e2e8f0', backgroundColor: 'white' },
    mosaicoSelected: { backgroundColor: MJM_BLUE, borderColor: MJM_BLUE },
    mosaicoText: { fontSize: 12, fontWeight: '500', color: '#333' },
    cascadaContainer: { marginTop: 15, backgroundColor: 'white', padding: 12, borderRadius: 10, borderWidth: 1, borderColor: '#ddd' },
    cascadaHeader: { flexDirection: 'row', alignItems: 'center', gap: 6, marginBottom: 10 },
    cascadaTitle: { fontSize: 12, fontWeight: 'bold', color: MJM_BLUE },
    dropdown: { height: 45, borderRadius: 8, paddingHorizontal: 10, backgroundColor: 'white', borderWidth: 1, borderColor: '#ccc' },
    asignacionContainer: { flexDirection: 'row', gap: 10 },
    asignacionBtn: { flex: 1, padding: 10, borderRadius: 8, borderWidth: 1, borderColor: MJM_BLUE, alignItems: 'center' },
    asignacionText: { fontSize: 12, fontWeight: 'bold' },
    btnAddUnit: { height: 45, width: 50, backgroundColor: MJM_BLUE, borderRadius: 8, justifyContent: 'center', alignItems: 'center' },
    listadoUnidadesContainer: { marginTop: 15, borderTopWidth: 1, borderTopColor: '#eee', paddingTop: 10 },
    listadoHeader: { marginBottom: 8 },
    listadoTitle: { fontSize: 11, fontWeight: 'bold', color: '#666' },
    unitCard: { flexDirection: 'row', alignItems: 'center', padding: 10, borderRadius: 8, marginBottom: 6, borderWidth: 0.5, borderColor: '#e0e0e0' },
    unitCardIcon: { width: 32, height: 32, borderRadius: 16, backgroundColor: '#eef2ff', justifyContent: 'center', alignItems: 'center' },
    unitCardPlaca: { fontSize: 13, fontWeight: 'bold', color: '#333' },
    unitCardSub: { fontSize: 11, color: '#666' },
    unitCardRemove: { padding: 5 },
    timeRow: { flexDirection: 'row', gap: 10, alignItems: 'center' },
    btnTime: { height: 45, width: 45, backgroundColor: MJM_BLUE, borderRadius: 8, justifyContent: 'center', alignItems: 'center' },
    pickerPressable: { height: 45, borderRadius: 8, flexDirection: 'row', alignItems: 'center', paddingHorizontal: 12 },
    textArea: { height: 100, borderRadius: 8, padding: 10, borderStyle: 'solid', borderWidth: 1, borderColor: '#ccc', backgroundColor: 'white', color: '#000', textAlignVertical: 'top' },
    btnFoto: { flex: 1, flexDirection: 'row', backgroundColor: MJM_BLUE, padding: 12, borderRadius: 8, justifyContent: 'center', alignItems: 'center', gap: 8 },
    btnFotoText: { color: 'white', fontWeight: 'bold', fontSize: 13 },
    wrapperFoto: { marginRight: 10, position: 'relative' },
    previewFoto: { width: 70, height: 70, borderRadius: 8 },
    btnBorrarFoto: { position: 'absolute', top: -5, right: -5 },
    navRow: { flexDirection: 'row', justifyContent: 'space-between', gap: 15, marginTop: 15 },
    btnBack: { flex: 1, height: 48, borderRadius: 8, borderWidth: 1.5, borderColor: MJM_BLUE, justifyContent: 'center', alignItems: 'center' },
    btnNext: { flex: 1, height: 48, backgroundColor: MJM_BLUE, borderRadius: 8, justifyContent: 'center', alignItems: 'center' },
    btnDisabled: { opacity: 0.4 },
     progressTitle: { fontSize: 16, fontWeight: 'bold', marginBottom: 15, color: MJM_BLUE },
    progressBarBackground: { width: '100%', height: 10, backgroundColor: '#eee', borderRadius: 5, overflow: 'hidden' },
    progressBarFill: { height: '100%', backgroundColor: MJM_BLUE },
    progressPercentage: { marginTop: 10, fontSize: 12, color: '#666', fontWeight: 'bold' },
    
    // Estilos internos de Ubicación y Checklist
    btnToggleModo: { paddingHorizontal: 12, paddingVertical: 6, borderRadius: 8, backgroundColor: '#F5F5F5', borderWidth: 1.5, borderColor: MJM_BLUE },
    dropdownUbicacionDirecta: { borderColor: MJM_BLUE, borderWidth: 1, backgroundColor: '#F9FCFF', height: 45, borderRadius: 8, paddingHorizontal: 10 },
    cascadaGrid: { flexDirection: 'row', gap: 6, backgroundColor: '#F0F7FF', padding: 10, borderRadius: 10, borderWidth: 1, borderColor: '#BBDEFB' },
    labelSubCascada: { fontSize: 9, color: MJM_BLUE, fontWeight: '800', marginBottom: 3, marginLeft: 2 },
    dropdownCascadaItem: { height: 42, backgroundColor: '#FFF', borderColor: MJM_BLUE, borderWidth: 1, borderRadius: 8, paddingHorizontal: 8 },
    dropdownDisabled: { backgroundColor: '#F5F5F5', borderColor: '#CCC' },
    textAreaSmall: { minHeight: 85, textAlignVertical: 'top', color: '#000', backgroundColor: '#FFF', padding: 12, fontSize: 14, borderWidth: 1.5, borderRadius: 10 },
    webPickerInput: { height: 45, borderWidth: 1, borderColor: '#ccc', borderRadius: 8, padding: 10, fontSize: 16, backgroundColor: '#FFFFFF', color: '#000000', width: '100%', outline: 'none', borderStyle: 'solid' },
    webTimeInput: { flex: 1, height: 45, borderWidth: 1, borderStyle: 'solid', borderColor: '#ccc', borderRadius: 8, padding: 10, backgroundColor: '#FFFFFF', color: '#000000', outline: 'none' },
    errorSecuenciaContainer: { backgroundColor: '#FFF5F5', borderLeftWidth: 4, borderLeftColor: '#D32F2F', padding: 12, borderRadius: 8, marginTop: 20, flexDirection: 'row', alignItems: 'center', shadowColor: "#000", shadowOffset: { width: 0, height: 1 }, shadowOpacity: 0.1, shadowRadius: 2, elevation: 2 },
    
    modalLabelInput: { alignSelf: 'flex-start', fontWeight: '600', color: '#4A5568', marginBottom: 5 },
    modalInputText: { width: '100%', backgroundColor: '#F8FAFC', borderColor: '#CBD5E1', borderWidth: 1, borderRadius: 10, padding: 12, color: '#333', fontSize: 16 },
   
    modalAccionesRow: { flexDirection: 'row', justifyContent: 'space-between', width: '100%', marginTop: 20 },
    btnModalAccion: { flex: 0.47, paddingVertical: 14, borderRadius: 10, alignItems: 'center' },
   
    checkboxRow: { flexDirection: 'row', alignItems: 'center', marginBottom: 10 },
  modalOverlay: { flex: 1, backgroundColor: 'rgba(0,0,0,0.5)', justifyContent: 'center', padding: 20 },
modalContent: { backgroundColor: 'white', borderRadius: 15, padding: 20, maxHeight: '80%' },
modalTitle: { fontSize: 18, fontWeight: 'bold', color: MJM_BLUE, marginBottom: 15, textAlign: 'center' },
inputModal: { borderWidth: 1, borderColor: '#ddd', borderRadius: 8, padding: 10, marginBottom: 15 },
listContainer: { flexGrow: 0 },
checkItem: { marginBottom: 15, borderBottomWidth: 1, borderBottomColor: '#eee', paddingBottom: 10 },
checkLabel: { fontSize: 14, marginBottom: 5 },
checkActions: { flexDirection: 'row', alignItems: 'center' },
btnConforme: { padding: 10, borderRadius: 5, marginRight: 10 },
activeConforme: { backgroundColor: '#28a745' },
inactive: { backgroundColor: '#ccc' },
inputObs: { flex: 1, borderWidth: 1, borderColor: '#eee', borderRadius: 5, padding: 5, fontSize: 12 },
btnGuardar: { backgroundColor: MJM_BLUE, padding: 15, borderRadius: 8, alignItems: 'center', marginTop: 15 }
});