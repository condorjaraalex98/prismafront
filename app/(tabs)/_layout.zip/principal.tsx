import { ThemedText } from '@/components/themed-text';
import { ThemedView } from '@/components/themed-view';
import { Ionicons } from '@expo/vector-icons';
import { useRouter } from 'expo-router';
import React from 'react';
import {
  ScrollView,
  StyleSheet,
  TouchableOpacity,
  View
} from 'react-native';
import { useSafeAreaInsets } from 'react-native-safe-area-context';

const MODULOS = [
    { 
        id: '1', 
        nombre: 'CUADERNO DE CONTROL', 
        ruta: '/cuaderno', 
        icono: 'book', 
        color: '#dc3545', 
        bg: '#fff5f5'
    },
    { 
        id: '2', 
        nombre: 'TÁCTICO PRIORIZADO', 
        ruta: '/tactp', 
        icono: 'shield-checkmark', 
        color: '#0056b3', 
        bg: '#f0f7ff'
    },
    { 
        id: '3', 
        nombre: 'ESCUELA SEGURA', 
        ruta: '/escseg', 
        icono: 'school', 
        color: '#ffc107', 
        bg: '#fffdf0'
    },
    { 
        id: '4', 
        nombre: 'PATRULLAJE INTEGRADO', 
        ruta: '/formularios/PatrullajeIntegrado', 
        icono: 'shield', 
        color: '#28a745', 
        bg: '#f6fff8'
    },
    { 
        id: '5', 
        nombre: 'SERENAZGO SIN FRONTERAS', 
        ruta: '/formularios/SerenazgoFronteras', 
        icono: 'map', 
        color: '#6f42c1', 
        bg: '#f8f4ff'
    },
    { 
        id: '6', 
        nombre: 'OTRAS NOVEDADES', 
        ruta: '/formularios/OtrasNovedades', 
        icono: 'alert-circle', 
        color: '#fd7e14', 
        bg: '#fff9f2'
    },
    { 
        id: '7', 
        nombre: 'AUXILIO MECÁNICO', 
        ruta: '/formularios/AuxilioMecanico', 
        icono: 'construct', 
        color: '#20c997', 
        bg: '#f2fcf9'
    },
    { 
        id: '8', 
        nombre: 'APOYO AL CIUDADANO', 
        ruta: '/formularios/ApoyoCiudadano', 
        icono: 'people', 
        color: '#e83e8c', 
        bg: '#fff5f9'
    }
];

export default function PrincipalScreen() {
    const router = useRouter();
    const insets = useSafeAreaInsets();

    return (
        <ThemedView style={[styles.main, { paddingTop: insets.top + 20 }]}>
            <ScrollView contentContainerStyle={styles.scrollContent}>
                <ThemedText style={styles.sectionTitle}>SELECCIONE UNA ACTIVIDAD</ThemedText>
                
                <View style={styles.grid}>
                    {MODULOS.map((item) => (
                        <TouchableOpacity 
                            key={item.id} 
                            style={[styles.card, { borderColor: item.color }]}
                            activeOpacity={0.8}
                            onPress={() => router.push(item.ruta as any)}
                        >
                            <View style={[styles.iconCircle, { backgroundColor: item.bg }]}>
                                <Ionicons name={item.icono as any} size={32} color={item.color} />
                            </View>
                            <ThemedText style={[styles.cardTitle, { color: item.color }]}>
                                {item.nombre}
                            </ThemedText>
                            <View style={[styles.indicator, { backgroundColor: item.color }]} />
                        </TouchableOpacity>
                    ))}
                </View>
            </ScrollView>
        </ThemedView>
    );
}

const styles = StyleSheet.create({
    main: { flex: 1, backgroundColor: '#f8fafc' },
    scrollContent: { padding: 15 },
    sectionTitle: { 
        fontSize: 12, 
        fontWeight: 'bold', 
        color: '#64748b', 
        marginBottom: 25, 
        textAlign: 'center',
        letterSpacing: 1.5
    },
    grid: { 
        flexDirection: 'row', 
        flexWrap: 'wrap', 
        justifyContent: 'space-between' 
    },
    card: { 
        backgroundColor: 'white', 
        width: '48%', 
        padding: 15, 
        borderRadius: 24, 
        marginBottom: 15, 
        elevation: 3,
        shadowColor: '#000',
        shadowOffset: { width: 0, height: 2 },
        shadowOpacity: 0.05,
        shadowRadius: 8,
        borderLeftWidth: 6,
        alignItems: 'center',
        justifyContent: 'center',
        height: 150
    },
    iconCircle: { 
        padding: 14, 
        borderRadius: 50, 
        marginBottom: 12 
    },
    cardTitle: { 
        fontSize: 10, 
        fontWeight: '900', 
        textAlign: 'center',
        lineHeight: 14,
        textTransform: 'uppercase'
    },
    indicator: {
        width: 24,
        height: 4,
        borderRadius: 2,
        marginTop: 10
    }
});