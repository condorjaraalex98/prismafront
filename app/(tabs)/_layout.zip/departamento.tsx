import { ThemedText } from '@/components/themed-text';
import { ThemedView } from '@/components/themed-view';
import { Ionicons } from '@expo/vector-icons';
import React, { useCallback, useEffect, useState } from 'react';
import {
    ActivityIndicator,
    Alert,
    FlatList,
    Modal,
    RefreshControl,
    StyleSheet,
    TextInput,
    TouchableOpacity,
    View
} from 'react-native';

const MJM_BLUE = '#024885';
const API_URL = 'http://192.168.1.11:3000/departamentos';

export default function DepartamentoScreen() {
    const [departamentos, setDepartamentos] = useState<any[]>([]);
    const [cargando, setCargando] = useState(true);
    const [refreshing, setRefreshing] = useState(false);

    // Modales
    const [modalFormVisible, setModalFormVisible] = useState(false);
    const [modalEliminarVisible, setModalEliminarVisible] = useState(false);
    
    // Estados de Formulario
    const [editandoId, setEditandoId] = useState<number | null>(null);
    const [idParaAccion, setIdParaAccion] = useState<number | null>(null);
    const [nombre, setNombre] = useState('');

    const cargarDepartamentos = useCallback(async () => {
        try {
            const response = await fetch(API_URL);
            const data = await response.json();
            setDepartamentos(Array.isArray(data) ? data : []);
        } catch (error) {
            console.error("Error:", error);
        } finally {
            setCargando(false);
            setRefreshing(false);
        }
    }, []);

    useEffect(() => { cargarDepartamentos(); }, [cargarDepartamentos]);

    const guardarDepartamento = async () => {
        if (!nombre.trim()) return Alert.alert("Error", "Ingrese el nombre del departamento");

        const metodo = editandoId ? 'PUT' : 'POST';
        const url = editandoId ? `${API_URL}/${editandoId}` : API_URL;

        try {
            const resp = await fetch(url, {
                method: metodo,
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ nombre_departamento: nombre.trim() })
            });

            const data = await resp.json();

            if (!resp.ok) {
                // Aquí capturamos la validación del backend (Nombre duplicado)
                return Alert.alert("Validación", data.message || "Error al procesar");
            }

            setModalFormVisible(false);
            setNombre('');
            setEditandoId(null);
            cargarDepartamentos();
            Alert.alert("Éxito", "Datos guardados correctamente");
        } catch (error) {
            Alert.alert("Error", "No se pudo conectar con el servidor");
        }
    };

    const ejecutarBajaLogica = async () => {
        if (!idParaAccion) return;
        try {
            const resp = await fetch(`${API_URL}/${idParaAccion}`, { method: 'DELETE' });
            const data = await resp.json();

            if (!resp.ok) {
                return Alert.alert("Atención", data.message || "No se pudo desactivar");
            }

            setModalEliminarVisible(false);
            cargarDepartamentos();
        } catch (error) {
            Alert.alert("Error", "Error de conexión");
        }
    };

    return (
        <ThemedView style={styles.container}>
            {/* CABECERA */}
            <View style={styles.customHeader}>
                <View>
                    <ThemedText style={styles.headerTitle}>Departamentos</ThemedText>
                    <ThemedText style={styles.headerSub}>Regiones del Perú</ThemedText>
                </View>
                <TouchableOpacity 
                    style={styles.addBtn} 
                    onPress={() => { setEditandoId(null); setNombre(''); setModalFormVisible(true); }}
                >
                    <Ionicons name="add" size={28} color="white" />
                </TouchableOpacity>
            </View>

            {/* LISTADO */}
            <View style={styles.content}>
                {cargando ? (
                    <ActivityIndicator size="large" color={MJM_BLUE} />
                ) : (
                    <FlatList
                        data={departamentos}
                        keyExtractor={(item) => item.id_departamento.toString()}
                        refreshControl={<RefreshControl refreshing={refreshing} onRefresh={cargarDepartamentos} />}
                        renderItem={({ item }) => (
                            <View style={styles.card}>
                                <ThemedText style={styles.cardText}>{item.nombre_departamento}</ThemedText>
                                <View style={styles.actions}>
                                    <TouchableOpacity onPress={() => { setEditandoId(item.id_departamento); setNombre(item.nombre_departamento); setModalFormVisible(true); }}>
                                        <Ionicons name="pencil" size={20} color={MJM_BLUE} />
                                    </TouchableOpacity>
                                    <TouchableOpacity 
                                        style={{marginLeft: 15}}
                                        onPress={() => { setIdParaAccion(item.id_departamento); setModalEliminarVisible(true); }}
                                    >
                                        <Ionicons name="eye-off" size={20} color="#f87171" />
                                    </TouchableOpacity>
                                </View>
                            </View>
                        )}
                    />
                )}
            </View>

            {/* MODAL: REGISTRO / EDICIÓN */}
            <Modal visible={modalFormVisible} transparent animationType="slide">
                <View style={styles.overlay}>
                    <View style={styles.modalCard}>
                        <ThemedText style={styles.modalTitle}>{editandoId ? 'Editar' : 'Nuevo'} Departamento</ThemedText>
                        <TextInput 
                            style={styles.input} 
                            placeholder="Ej. LIMA, AREQUIPA..." 
                            value={nombre}
                            onChangeText={setNombre}
                            autoCapitalize="characters"
                        />
                        <TouchableOpacity style={styles.btnSave} onPress={guardarDepartamento}>
                            <ThemedText style={{color:'white', fontWeight:'bold'}}>GUARDAR</ThemedText>
                        </TouchableOpacity>
                        <TouchableOpacity style={styles.btnCancel} onPress={() => setModalFormVisible(false)}>
                            <ThemedText style={{color:'#64748b'}}>CERRAR</ThemedText>
                        </TouchableOpacity>
                    </View>
                </View>
            </Modal>

            {/* MODAL: CONFIRMAR ELIMINACIÓN (ESTADO) */}
            <Modal visible={modalEliminarVisible} transparent animationType="fade">
                <View style={styles.overlay}>
                    <View style={[styles.modalCard, {alignItems: 'center'}]}>
                        <Ionicons name="alert-circle" size={50} color="#f87171" />
                        <ThemedText style={[styles.modalTitle, {marginTop:10}]}>¿Desactivar?</ThemedText>
                        <ThemedText style={{textAlign:'center', marginBottom:20, color: '#64748b'}}>
                            El departamento se ocultará de la lista pero no se borrará la información histórica.
                        </ThemedText>
                        <TouchableOpacity style={[styles.btnSave, {backgroundColor:'#f87171'}]} onPress={ejecutarBajaLogica}>
                            <ThemedText style={{color:'white', fontWeight:'bold'}}>DESACTIVAR</ThemedText>
                        </TouchableOpacity>
                        <TouchableOpacity style={styles.btnCancel} onPress={() => setModalEliminarVisible(false)}>
                            <ThemedText style={{color:'#64748b'}}>CANCELAR</ThemedText>
                        </TouchableOpacity>
                    </View>
                </View>
            </Modal>
        </ThemedView>
    );
}

const styles = StyleSheet.create({
    container: { flex: 1, backgroundColor: '#f8fafc' },
    customHeader: { backgroundColor: '#fff', paddingHorizontal: 25, paddingTop: 50, paddingBottom: 20, flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', borderBottomWidth: 1, borderBottomColor: '#f1f5f9' },
    headerTitle: { color: MJM_BLUE, fontWeight: 'bold', fontSize: 20 },
    headerSub: { color: '#94a3b8', fontSize: 13 },
    addBtn: { backgroundColor: MJM_BLUE, padding: 10, borderRadius: 15 },
    content: { flex: 1, padding: 15 },
    card: { backgroundColor: 'white', padding: 18, borderRadius: 15, marginBottom: 10, flexDirection: 'row', justifyContent: 'space-between', elevation: 2 },
    cardText: { fontWeight: 'bold', fontSize: 16, color: '#1e293b' },
    actions: { flexDirection: 'row' },
    overlay: { flex: 1, backgroundColor: 'rgba(15, 23, 42, 0.7)', justifyContent: 'center', alignItems: 'center' },
    modalCard: { backgroundColor: 'white', width: '85%', borderRadius: 25, padding: 25 },
    modalTitle: { fontSize: 18, fontWeight: 'bold', color: MJM_BLUE, marginBottom: 15 },
    input: { backgroundColor: '#f1f5f9', padding: 16, borderRadius: 12, marginBottom: 20, borderWidth: 1, borderColor: '#e2e8f0' },
    btnSave: { backgroundColor: MJM_BLUE, padding: 16, borderRadius: 12, alignItems: 'center', width: '100%' },
    btnCancel: { marginTop: 15 }
});