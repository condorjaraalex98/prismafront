import { ThemedText } from '@/components/themed-text';
import { ThemedView } from '@/components/themed-view';
import { Ionicons } from '@expo/vector-icons';
import React, { useCallback, useEffect, useMemo, useState } from 'react';
import {
    Dimensions,
    FlatList,
    Modal,
    Platform,
    RefreshControl,
    ScrollView,
    StyleSheet,
    TextInput,
    TouchableOpacity,
    View
} from 'react-native';

// Soporte multiplataforma para WebView
let WebView: any;
if (Platform.OS !== 'web') {
    try {
        WebView = require('react-native-webview').WebView;
    } catch (e) {
        console.warn("WebView no disponible");
    }
}

const { width } = Dimensions.get('window');
const isDesktop = width > 768;
const MJM_BLUE = '#024885';
const API_URL = 'http://192.168.1.11:3000/puntost'; // Ruta actualizada

export default function PuntostScreen() {
    const [ocurrencias, setOcurrencias] = useState<any[]>([]);
    const [searchText, setSearchText] = useState('');
    const [refreshing, setRefreshing] = useState(false);
    const [modalDetalleVisible, setModalDetalleVisible] = useState(false);
    const [itemSeleccionado, setItemSeleccionado] = useState<any>(null);

    const cargarDatos = useCallback(async () => {
        setRefreshing(true);
        try {
            const response = await fetch(API_URL);
            const data = await response.json();
            setOcurrencias(data);
        } catch (error) { 
            console.error("Error cargando API:", error);
        } finally { 
            setRefreshing(false); 
        }
    }, []);

    useEffect(() => { cargarDatos(); }, []);

    const datosFiltrados = useMemo(() => {
        return ocurrencias.filter(o => 
            (o.descripcion?.toLowerCase() || "").includes(searchText.toLowerCase()) || 
            (o.modalidad?.toLowerCase() || "").includes(searchText.toLowerCase()) ||
            (o.lugar?.toLowerCase() || "").includes(searchText.toLowerCase())
        );
    }, [searchText, ocurrencias]);

    const renderItem = ({ item }: { item: any }) => (
        <TouchableOpacity 
            style={styles.card} 
            onPress={() => { setItemSeleccionado(item); setModalDetalleVisible(true); }}
        >
            <View style={styles.cardBody}>
                <View style={styles.rowBetween}>
                    <ThemedText style={styles.idLabel}>ID: {item.id}</ThemedText>
                    <ThemedText style={styles.dateLabel}>{new Date(item.fecha).toLocaleDateString()}</ThemedText>
                </View>
                <ThemedText style={styles.areaLabel}>{item.modalidad || 'General'}</ThemedText>
                <ThemedText style={styles.descLabel} numberOfLines={2}>{item.descripcion}</ThemedText>
                <View style={styles.locationFooter}>
                    <Ionicons name="location-sharp" size={12} color="#888" />
                    <ThemedText style={styles.lugarLabel}>{item.lugar}</ThemedText>
                </View>
            </View>
        </TouchableOpacity>
    );

    const mapHTML = useMemo(() => {
        const puntosJS = JSON.stringify(datosFiltrados.filter(o => o.latitud && o.longitud));
        return `
            <!DOCTYPE html>
            <html>
            <head>
                <meta name="viewport" content="width=device-width, initial-scale=1.0">
                <link rel="stylesheet" href="https://unpkg.com/leaflet@1.9.4/dist/leaflet.css" />
                <script src="https://unpkg.com/leaflet@1.9.4/dist/leaflet.js"></script>
                <style>
                    #map { height: 100vh; width: 100vw; margin: 0; }
                    .emoji-icon { background: none; border: none; }
                </style>
            </head>
            <body>
                <div id="map"></div>
                <script>
                    var map = L.map('map').setView([-12.046, -77.042], 13);
                    L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png').addTo(map);

                    function getIcon(nombre) {
                        let emoji = '📍';
                        // Personaliza estos nombres según tu tabla cat_modalidad
                        if (nombre === 'Robo') emoji = '🚨';
                        if (nombre === 'Accidente') emoji = '🚑';
                        if (nombre === 'Incendio') emoji = '🔥';
                        if (nombre === 'Soporte') emoji = '🛠️';

                        return L.divIcon({
                            html: '<div style="font-size: 24px;">' + emoji + '</div>',
                            className: 'emoji-icon',
                            iconSize: [30, 30],
                            iconAnchor: [15, 15]
                        });
                    }

                    var data = ${puntosJS};
                    if(data.length > 0){
                        var markers = data.map(o => {
                            return L.marker([o.latitud, o.longitud], { icon: getIcon(o.modalidad) })
                                    .addTo(map)
                                    .bindPopup("<b>" + (o.modalidad || 'Incidencia') + "</b><br>" + o.descripcion);
                        });
                        var group = new L.featureGroup(markers);
                        map.fitBounds(group.getBounds(), { padding: [20, 20] });
                    }
                </script>
            </body>
            </html>
        `;
    }, [datosFiltrados]);

    return (
        <ThemedView style={styles.container}>
            <View style={styles.header}>
                <ThemedText style={styles.title}>Ocurrencias MJM</ThemedText>
                <View style={styles.searchBox}>
                    <TextInput 
                        placeholder="Buscar por modalidad o descripción..." 
                        style={styles.input}
                        value={searchText}
                        onChangeText={setSearchText}
                    />
                    <TouchableOpacity onPress={cargarDatos}>
                        <Ionicons name="reload" size={20} color={MJM_BLUE} />
                    </TouchableOpacity>
                </View>
            </View>

            <View style={isDesktop ? styles.layoutDesktop : { flex: 1 }}>
                <FlatList
                    data={datosFiltrados}
                    keyExtractor={(item) => item.id.toString()}
                    renderItem={renderItem}
                    contentContainerStyle={{ padding: 15 }}
                    refreshControl={<RefreshControl refreshing={refreshing} onRefresh={cargarDatos} />}
                />

                {isDesktop && (
                    <View style={styles.mapSide}>
                        {Platform.OS === 'web' ? (
                            <iframe srcDoc={mapHTML} style={{ width: '100%', height: '100%', border: 'none' }} />
                        ) : (
                            WebView && <WebView originWhitelist={['*']} source={{ html: mapHTML }} />
                        )}
                    </View>
                )}
            </View>

            <Modal visible={modalDetalleVisible} transparent animationType="fade">
                <View style={styles.modalBackdrop}>
                    <View style={styles.modalCard}>
                        {itemSeleccionado && (
                            <>
                                <ThemedText style={styles.modalTitle}>DETALLE #{itemSeleccionado.id}</ThemedText>
                                <ScrollView>
                                    <ThemedText style={styles.modalLabel}>Modalidad:</ThemedText>
                                    <ThemedText style={styles.modalText}>{itemSeleccionado.modalidad || 'N/A'}</ThemedText>
                                    
                                    <ThemedText style={styles.modalLabel}>Descripción:</ThemedText>
                                    <ThemedText style={styles.modalText}>{itemSeleccionado.descripcion}</ThemedText>
                                    
                                    <ThemedText style={styles.modalLabel}>Ubicación:</ThemedText>
                                    <ThemedText style={styles.modalText}>{itemSeleccionado.lugar}</ThemedText>
                                </ScrollView>
                                <TouchableOpacity style={styles.closeBtn} onPress={() => setModalDetalleVisible(false)}>
                                    <ThemedText style={{ color: 'white', fontWeight: 'bold' }}>Cerrar</ThemedText>
                                </TouchableOpacity>
                            </>
                        )}
                    </View>
                </View>
            </Modal>
        </ThemedView>
    );
}

const styles = StyleSheet.create({
    container: { flex: 1, backgroundColor: '#f8f9fa' },
    header: { padding: 20, paddingTop: 50, backgroundColor: 'white', borderBottomWidth: 1, borderBottomColor: '#eee' },
    title: { fontSize: 22, fontWeight: 'bold', color: MJM_BLUE, marginBottom: 10 },
    searchBox: { flexDirection: 'row', backgroundColor: '#f1f3f5', paddingHorizontal: 15, paddingVertical: 8, borderRadius: 12, alignItems: 'center' },
    input: { flex: 1, fontSize: 16 },
    layoutDesktop: { flex: 1, flexDirection: 'row' },
    card: { backgroundColor: 'white', padding: 15, borderRadius: 12, marginBottom: 10, elevation: 2, shadowColor: '#000', shadowOpacity: 0.1, shadowRadius: 4, shadowOffset: { width: 0, height: 2 } },
    cardBody: { flex: 1 },
    rowBetween: { flexDirection: 'row', justifyContent: 'space-between', marginBottom: 5 },
    idLabel: { fontSize: 11, color: MJM_BLUE, fontWeight: 'bold' },
    dateLabel: { fontSize: 11, color: '#999' },
    areaLabel: { fontSize: 16, fontWeight: 'bold', color: '#333' },
    descLabel: { fontSize: 14, color: '#666', marginTop: 4 },
    locationFooter: { flexDirection: 'row', alignItems: 'center', marginTop: 8, gap: 4 },
    lugarLabel: { fontSize: 12, color: '#888' },
    mapSide: { flex: 1.5, borderLeftWidth: 1, borderLeftColor: '#ddd' },
    modalBackdrop: { flex: 1, backgroundColor: 'rgba(0,0,0,0.6)', justifyContent: 'center', alignItems: 'center' },
    modalCard: { backgroundColor: 'white', width: '85%', padding: 25, borderRadius: 20, maxHeight: '80%' },
    modalTitle: { fontSize: 20, fontWeight: 'bold', marginBottom: 15, color: MJM_BLUE, textAlign: 'center' },
    modalLabel: { fontWeight: 'bold', fontSize: 13, color: MJM_BLUE, marginTop: 15 },
    modalText: { fontSize: 16, color: '#444', marginTop: 4 },
    closeBtn: { backgroundColor: MJM_BLUE, padding: 15, borderRadius: 12, alignItems: 'center', marginTop: 25 }
});