import { ThemedText } from '@/components/themed-text';
import { ThemedView } from '@/components/themed-view';
import { Ionicons } from '@expo/vector-icons';
import { Picker } from '@react-native-picker/picker';
import React, { useCallback, useEffect, useState } from 'react';
import {
    ActivityIndicator, Alert, FlatList, Modal,
    StyleSheet, TextInput, TouchableOpacity, View
} from 'react-native';

const MJM_BLUE = '#024885';
const API_URL = 'http://192.168.1.11:3000'; 

export default function DistritoScreen() {
    const [distritos, setDistritos] = useState<any[]>([]);
    const [departamentos, setDepartamentos] = useState<any[]>([]);
    const [provinciasFiltradas, setProvinciasFiltradas] = useState<any[]>([]);
    const [cargando, setCargando] = useState(true);
    
    // Modales
    const [modalVisible, setModalVisible] = useState(false);
    const [modalBorrarVisible, setModalBorrarVisible] = useState(false);

    // Formulario y Estados de ID
    const [editandoId, setEditandoId] = useState<number | null>(null);
    const [idParaBorrar, setIdParaBorrar] = useState<number | null>(null);
    const [form, setForm] = useState({
        nombre_distrito: '',
        id_departamento: '',
        id_provincia: ''
    });

    const cargarDatos = useCallback(async () => {
        setCargando(true);
        try {
            const [resDis, resDep] = await Promise.all([
                fetch(`${API_URL}/distritos`),
                fetch(`${API_URL}/departamentos`)
            ]);
            setDistritos(await resDis.json());
            setDepartamentos(await resDep.json());
        } catch (e) { console.error(e); }
        finally { setCargando(false); }
    }, []);

    useEffect(() => { cargarDatos(); }, [cargarDatos]);

    const manejarCambioDepartamento = async (idDep: string, idProvPreseleccionada = '') => {
        setForm(prev => ({ ...prev, id_departamento: idDep, id_provincia: idProvPreseleccionada }));
        if (!idDep) return setProvinciasFiltradas([]);
        
        try {
            const res = await fetch(`${API_URL}/provincias/filtro/${idDep}`);
            const data = await res.json();
            setProvinciasFiltradas(data);
        } catch (e) { console.error(e); }
    };

    const guardarDistrito = async () => {
        if (!form.nombre_distrito.trim() || !form.id_provincia) {
            return Alert.alert("Error", "Complete todos los campos");
        }

        const metodo = editandoId ? 'PUT' : 'POST';
        const url = editandoId ? `${API_URL}/distritos/${editandoId}` : `${API_URL}/distritos`;

        try {
            const resp = await fetch(url, {
                method: metodo,
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({
                    nombre_distrito: form.nombre_distrito.toUpperCase(),
                    id_provincia: parseInt(form.id_provincia)
                })
            });

            if (resp.ok) {
                Alert.alert("Éxito", editandoId ? "Actualizado" : "Creado");
                setModalVisible(false);
                setEditandoId(null);
                setForm({ nombre_distrito: '', id_departamento: '', id_provincia: '' });
                cargarDatos();
            }
        } catch (e) { Alert.alert("Error", "No se pudo conectar"); }
    };

    const confirmarBorrado = async () => {
        try {
            await fetch(`${API_URL}/distritos/${idParaBorrar}/desactivar`, { method: 'PATCH' });
            setModalBorrarVisible(false);
            cargarDatos();
        } catch (e) { Alert.alert("Error", "No se pudo borrar"); }
    };

    return (
        <ThemedView style={styles.container}>
            <View style={styles.header}>
                <ThemedText style={styles.headerTitle}>Distritos</ThemedText>
                <TouchableOpacity style={styles.addBtn} onPress={() => {
                    setEditandoId(null);
                    setForm({ nombre_distrito: '', id_departamento: '', id_provincia: '' });
                    setModalVisible(true);
                }}>
                    <Ionicons name="add" size={26} color="white" />
                </TouchableOpacity>
            </View>

            <View style={styles.content}>
                {cargando ? (
                    <ActivityIndicator size="large" color={MJM_BLUE} />
                ) : (
                    <FlatList
                        data={distritos}
                        keyExtractor={(item) => item.id_distrito.toString()}
                        renderItem={({ item }) => (
                            <View style={styles.card}>
                                <View style={{ flex: 1 }}>
                                    <ThemedText style={styles.cardTitle}>{item.nombre_distrito}</ThemedText>
                                    <ThemedText style={styles.cardSub}>{item.nombre_provincia} - {item.nombre_departamento}</ThemedText>
                                </View>
                                <View style={styles.row}>
                                    <TouchableOpacity onPress={() => {
                                        setEditandoId(item.id_distrito);
                                        setForm({ ...form, nombre_distrito: item.nombre_distrito });
                                        manejarCambioDepartamento(item.id_departamento.toString(), item.id_provincia.toString());
                                        setModalVisible(true);
                                    }}>
                                        <Ionicons name="pencil" size={20} color={MJM_BLUE} style={{marginRight: 15}} />
                                    </TouchableOpacity>
                                    <TouchableOpacity onPress={() => {
                                        setIdParaBorrar(item.id_distrito);
                                        setModalBorrarVisible(true);
                                    }}>
                                        <Ionicons name="trash-outline" size={20} color="#f87171" />
                                    </TouchableOpacity>
                                </View>
                            </View>
                        )}
                    />
                )}
            </View>

            {/* MODAL FORMULARIO (NUEVO / EDITAR) */}
            <Modal visible={modalVisible} transparent animationType="slide">
                <View style={styles.overlay}>
                    <View style={styles.modalCard}>
                        <ThemedText style={styles.modalTitle}>{editandoId ? 'Editar' : 'Nuevo'} Distrito</ThemedText>
                        
                        <ThemedText style={styles.label}>Departamento:</ThemedText>
                        <View style={styles.pickerBox}>
                            <Picker
                                selectedValue={form.id_departamento}
                                onValueChange={(val) => manejarCambioDepartamento(val)}
                            >
                                <Picker.Item label="Seleccione..." value="" />
                                {departamentos.map(d => (
                                    <Picker.Item key={d.id_departamento} label={d.nombre_departamento} value={d.id_departamento.toString()} />
                                ))}
                            </Picker>
                        </View>

                        <ThemedText style={styles.label}>Provincia:</ThemedText>
                        <View style={[styles.pickerBox, !form.id_departamento && {opacity: 0.5}]}>
                            <Picker
                                enabled={!!form.id_departamento}
                                selectedValue={form.id_provincia}
                                onValueChange={(val) => setForm({ ...form, id_provincia: val })}
                            >
                                <Picker.Item label="Seleccione..." value="" />
                                {provinciasFiltradas.map(p => (
                                    <Picker.Item key={p.id_provincia} label={p.nombre_provincia} value={p.id_provincia.toString()} />
                                ))}
                            </Picker>
                        </View>

                        <ThemedText style={styles.label}>Nombre Distrito:</ThemedText>
                        <TextInput 
                            style={styles.input} 
                            value={form.nombre_distrito}
                            onChangeText={(t) => setForm({ ...form, nombre_distrito: t })}
                            autoCapitalize="characters"
                        />

                        <TouchableOpacity style={styles.btnSave} onPress={guardarDistrito}>
                            <ThemedText style={{ color: 'white', fontWeight: 'bold' }}>{editandoId ? 'ACTUALIZAR' : 'CREAR'}</ThemedText>
                        </TouchableOpacity>
                        <TouchableOpacity style={{ marginTop: 15 }} onPress={() => setModalVisible(false)}>
                            <ThemedText style={{ color: '#64748b', textAlign: 'center' }}>CANCELAR</ThemedText>
                        </TouchableOpacity>
                    </View>
                </View>
            </Modal>

            {/* MODAL BORRAR */}
            <Modal visible={modalBorrarVisible} transparent animationType="fade">
                <View style={styles.overlay}>
                    <View style={[styles.modalCard, {alignItems: 'center'}]}>
                        <Ionicons name="trash" size={50} color="#f87171" />
                        <ThemedText style={styles.modalTitle}>¿Eliminar Distrito?</ThemedText>
                        <TouchableOpacity style={[styles.btnSave, {backgroundColor: '#f87171'}]} onPress={confirmarBorrado}>
                            <ThemedText style={{color: 'white', fontWeight: 'bold'}}>SÍ, ELIMINAR</ThemedText>
                        </TouchableOpacity>
                        <TouchableOpacity style={{marginTop: 15}} onPress={() => setModalBorrarVisible(false)}>
                            <ThemedText style={{color: '#64748b'}}>CANCELAR</ThemedText>
                        </TouchableOpacity>
                    </View>
                </View>
            </Modal>
        </ThemedView>
    );
}

const styles = StyleSheet.create({
    container: { flex: 1, backgroundColor: '#f8fafc' },
    header: { padding: 50, paddingBottom: 20, backgroundColor: '#fff', flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center' },
    headerTitle: { color: MJM_BLUE, fontWeight: 'bold', fontSize: 20 },
    addBtn: { backgroundColor: MJM_BLUE, padding: 10, borderRadius: 12 },
    content: { flex: 1, padding: 15 },
    card: { backgroundColor: 'white', padding: 15, borderRadius: 15, marginBottom: 10, elevation: 2, flexDirection: 'row', alignItems: 'center' },
    cardTitle: { fontWeight: 'bold', fontSize: 16 },
    cardSub: { fontSize: 12, color: '#64748b' },
    row: { flexDirection: 'row' },
    overlay: { flex: 1, backgroundColor: 'rgba(0,0,0,0.5)', justifyContent: 'center', alignItems: 'center' },
    modalCard: { backgroundColor: 'white', width: '85%', borderRadius: 20, padding: 25 },
    modalTitle: { fontSize: 18, fontWeight: 'bold', color: MJM_BLUE, marginBottom: 20 },
    label: { fontSize: 11, fontWeight: 'bold', color: MJM_BLUE, marginBottom: 5 },
    pickerBox: { backgroundColor: '#f1f5f9', borderRadius: 10, marginBottom: 15 },
    input: { backgroundColor: '#f1f5f9', padding: 15, borderRadius: 10, marginBottom: 20 },
    btnSave: { backgroundColor: MJM_BLUE, padding: 15, borderRadius: 10, alignItems: 'center', width: '100%' }
});