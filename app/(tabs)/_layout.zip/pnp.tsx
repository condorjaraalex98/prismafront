import React, { useEffect, useMemo, useState } from 'react';
import { ActivityIndicator, Platform, StyleSheet, Text, TouchableOpacity, View } from 'react-native';
const WebView = Platform.OS !== 'web' ? require('react-native-webview').WebView : null;

export default function MapaCuadrantes() {
    const [datos, setDatos] = useState([]);
    const [loading, setLoading] = useState(true);
    const [tipo, setTipo] = useState('jv'); // 'jv', 'pnp' o 'ambos'

    useEffect(() => {
        setLoading(true);
        // Llamamos a una ruta que maneje la lógica de qué mostrar
        fetch(`http://192.168.1.11:3000/poligonos?tipo=${tipo}`)
            .then(res => res.json())
            .then(json => { 
                setDatos(json); 
                setLoading(false); 
            })
            .catch(e => {
                console.log(e);
                setLoading(false);
            });
    }, [tipo]); // Se recarga cada vez que cambias el tipo

    const mapHTML = useMemo(() => {
        const jsonString = JSON.stringify(datos);

        return `
            <!DOCTYPE html><html><head>
            <meta name="viewport" content="width=device-width, initial-scale=1.0">
            <link rel="stylesheet" href="https://unpkg.com/leaflet@1.9.4/dist/leaflet.css" />
            <script src="https://unpkg.com/leaflet@1.9.4/dist/leaflet.js"></script>
            <style>
                body, html, #map { height: 100vh; width: 100vw; margin: 0; }
                .label-style { 
                    background: white; border: 1px solid #333; 
                    padding: 1px 4px; font-weight: bold; font-size: 10px;
                }
            </style></head>
            <body><div id="map"></div><script>
                var map = L.map('map', { zoomControl: false }).setView([-12.04, -77.03], 13);
                L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png').addTo(map);

                var lista = ${jsonString};
                var group = L.featureGroup();

                lista.forEach(function(item) {
                    if(item.geometria) {
                        var color = item.fuente === 'pnp' ? '#e74c3c' : '#024885'; // Rojo PNP, Azul JV
                        var poly = L.geoJSON(item.geometria, {
                            coordsToLatLng: function (coords) {
                                return (coords[0] > coords[1]) ? L.latLng(coords[0], coords[1]) : L.latLng(coords[1], coords[0]);
                            },
                            style: { color: color, weight: 2, fillOpacity: 0.3 }
                        }).addTo(group);

                        if(item.nombre) {
                            poly.bindTooltip(item.nombre, { permanent: true, direction: 'center', className: 'label-style' });
                        }
                    }
                });

                group.addTo(map);
                if(lista.length > 0) setTimeout(function(){ map.fitBounds(group.getBounds()); }, 500);
            </script></body></html>
        `;
    }, [datos]);

    return (
        <View style={{ flex: 1 }}>
            {/* Selector de Capas */}
            <View style={styles.selectorContainer}>
                <TouchableOpacity onPress={() => setTipo('jv')} style={[styles.btn, tipo === 'jv' && styles.btnActive]}>
                    <Text style={styles.btnText}>JV (Azul)</Text>
                </TouchableOpacity>
                <TouchableOpacity onPress={() => setTipo('pnp')} style={[styles.btn, tipo === 'pnp' && styles.btnActive]}>
                    <Text style={styles.btnText}>PNP (Rojo)</Text>
                </TouchableOpacity>
                <TouchableOpacity onPress={() => setTipo('ambos')} style={[styles.btn, tipo === 'ambos' && styles.btnActive]}>
                    <Text style={styles.btnText}>Ambos</Text>
                </TouchableOpacity>
            </View>

            {loading && <ActivityIndicator style={StyleSheet.absoluteFill} size="large" color="#0000ff" />}
            
            {Platform.OS === 'web' ? (
                <iframe srcDoc={mapHTML} style={{ flex: 1, border: 'none' }} />
            ) : (
                <WebView originWhitelist={['*']} source={{ html: mapHTML }} style={{ flex: 1 }} />
            )}
        </View>
    );
}

const styles = StyleSheet.create({
    selectorContainer: {
        flexDirection: 'row',
        justifyContent: 'space-around',
        padding: 10,
        backgroundColor: '#fff',
        elevation: 4,
        zIndex: 10
    },
    btn: { padding: 8, borderRadius: 5, backgroundColor: '#eee' },
    btnActive: { backgroundColor: '#024885' },
    btnText: { fontWeight: 'bold' }
});