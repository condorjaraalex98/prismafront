import { ThemedText } from '@/components/themed-text';
import { ThemedView } from '@/components/themed-view';
import { Ionicons } from '@expo/vector-icons';
import DateTimePicker from '@react-native-community/datetimepicker';
import * as ImagePicker from 'expo-image-picker';
import * as Location from 'expo-location';
import { useRouter } from 'expo-router';
import React, { useEffect, useState } from 'react';
import {
    Alert,
    Image,
    Modal, Platform,
    Pressable, ScrollView, StyleSheet,
    TextInput, View, useColorScheme
} from 'react-native';
import { Dropdown } from 'react-native-element-dropdown';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { useAuth } from '../../context/userContext';

const API_URL = 'http://192.168.1.11:3000';
const MJM_BLUE = '#024885';
const ID_CAMIONETA = 1;
const ID_PATRULLAJE_MOTORIZADO = 3;
const MAX_FOTOS = 5;


export default function RegistroOcurrencia() {

    const [modoBusquedaManual, setModoBusquedaManual] = useState(false);
    const insets = useSafeAreaInsets();
    const { userData } = useAuth();
    const router = useRouter();
    const colorScheme = useColorScheme();
    const isDark = colorScheme === 'dark';

    // --- ESTADOS ---
    const [step, setStep] = useState(1);
    const [loading, setLoading] = useState(false);
    const [uploadProgress, setUploadProgress] = useState(0);
    const [uploadStatus, setUploadStatus] = useState('Subiendo...');
    const [isFinished, setIsFinished] = useState(false);
    const [fotos, setFotos] = useState<{ uri: string; base64: string }[]>([]);
   
    const [showPicker, setShowPicker] = useState(false);
    const [pickerMode, setPickerMode] = useState<'time' | 'date'>('time');
    const [activeField, setActiveField] = useState<string | null>(null);
    const [tempDate, setTempDate] = useState<Date>(new Date());

    const [tiposVia, setTiposVia] = useState([]);
    const [vias, setVias] = useState([]);        
    const [cuadras, setCuadras] = useState([]);  
    const [selTipoVia, setSelTipoVia] = useState<any>(null);
    const [selVia, setSelVia] = useState<any>(null);

    const [catalogos, setCatalogos] = useState({
        usuarios: [], modalidades: [], origenes: [], camaras: [],
        tipos_patrullaje: [], modalidades_patrullaje: [],
        tipos_vehiculo: [], unidades: [], pnps: [], lugares: []
    });

    const [unidadForm, setUnidadForm] = useState({
        id_tipo_vehiculo: null as number | null,
        id_unidad: null as number | null,
        placa: '',
        tipo_asignacion: 'MUNICIPAL' as 'MUNICIPAL' | 'INTEGRADO',
        id_pnp: null as number | null
    });
const getHoy = () => {
    const d = new Date();
    return new Date(d.getTime() - d.getTimezoneOffset() * 60000).toISOString().split('T')[0];
};
    const [form, setForm] = useState({
        id_usuario: null,
        id_lugar: null,
        id_modalidad: null,
        id_origen: null,
        id_tipo_patrullaje: null,
        id_modalidad_patrullaje: '2',
        vehiculos_detalle: [] as any[],
        id_camara: [] as any[],
        descripcion: '',
        hora_alerta: '',
        hora_llegada: '',
        hora_repliegue: '',
        latitud_gps: '0',
        longitud_gps: '0',
        nombre_punto_gps: '',
        referencia: '',
        unidad_encargada: 'SERENAZGO',
      fecha_evento: getHoy(),
        grupo: null
    });

    // --- LÓGICA DE VALIDACIÓN ---
    const canAdvance = () => {
        if (step === 1) {
            const hasBasics = !!form.id_tipo_patrullaje && !!form.id_modalidad_patrullaje && !!form.id_origen && !!form.grupo;
            if (form.id_tipo_patrullaje === ID_PATRULLAJE_MOTORIZADO) return hasBasics && form.vehiculos_detalle.length > 0;
            return hasBasics;
        }
    if (step === 2) {
        const { hora_alerta, hora_llegada, hora_repliegue, fecha_evento } = form;
        
        // Primero: ¿Están todos los campos llenos?
        const camposLlenos = !!hora_alerta && !!hora_llegada && !!hora_repliegue && !!fecha_evento;
        if (!camposLlenos) return false;

        // Segundo: Validar orden (Alerta <= Llegada y Llegada <= Repliegue)
        const esCronologico = (hora_alerta <= hora_llegada) && (hora_llegada <= hora_repliegue);
        
        return esCronologico;
    }

        if (step === 3) return !!form.id_lugar;
        if (step === 4) return !!form.id_modalidad && form.descripcion.length > 0;
        return false;
    };

    const getDynamicBorderStyle = (value: any) => ({
        borderColor: value ? MJM_BLUE : (isDark ? '#444' : '#ddd'),
        borderWidth: value ? 1.5 : 1
    });

    // --- FUNCIÓN PARA FORMATEAR FECHA EN ESPAÑOL ---
    const formatearFechaEspañol = (fechaStr: string) => {
        if (!fechaStr) return "Seleccione fecha";
        
        const fecha = new Date(fechaStr + 'T12:00:00');
        
        const diasSemana = ['Domingo', 'Lunes', 'Martes', 'Miércoles', 'Jueves', 'Viernes', 'Sábado'];
        const meses = ['Enero', 'Febrero', 'Marzo', 'Abril', 'Mayo', 'Junio', 'Julio', 'Agosto', 'Septiembre', 'Octubre', 'Noviembre', 'Diciembre'];
        
        const diaSemana = diasSemana[fecha.getDay()];
        const dia = fecha.getDate();
        const mes = meses[fecha.getMonth()];
        const año = fecha.getFullYear();
        
        return `${diaSemana}, ${dia} de ${mes} de ${año}`;
    };

    // --- FUNCIÓN PARA FORMATEAR HORA EN 24H ---
    const formatearHora24h = (horaStr: string) => {
        if (!horaStr) return "00:00";
        // Si ya está en formato HH:MM, lo devolvemos
        if (/^([0-1][0-9]|2[0-3]):[0-5][0-9]$/.test(horaStr)) {
            return horaStr;
        }
        return "00:00";
    };

    // --- MANEJADOR DE CAMBIO DE FECHA ---
    const handleDateChange = (event: any, selectedDate?: Date) => {
        if (Platform.OS === 'android') {
            setShowPicker(false);
        }
        if (selectedDate) {
            const fechaStr = selectedDate.toISOString().split('T')[0];
            setForm(f => ({ ...f, fecha_evento: fechaStr }));
        }
        if (Platform.OS === 'ios') {
            setTempDate(selectedDate || new Date());
        }
    };

    // --- MANEJADOR DE CAMBIO DE HORA ---
    const handleTimeChange = (event: any, selectedTime?: Date) => {
        if (Platform.OS === 'android') {
            setShowPicker(false);
        }
        if (selectedTime && activeField) {
            const horaStr = selectedTime.toLocaleTimeString('en-GB', { 
                hour: '2-digit', 
                minute: '2-digit',
                hour12: false 
            });
            setForm(f => ({ ...f, [activeField]: horaStr }));
        }
        if (Platform.OS === 'ios') {
            setTempDate(selectedTime || new Date());
        }
    };

    // --- CONFIRMAR SELECCIÓN EN iOS ---
    const confirmIOSSelection = () => {
        if (activeField === 'fecha_evento') {
            const fechaStr = tempDate.toISOString().split('T')[0];
            setForm(f => ({ ...f, fecha_evento: fechaStr }));
        } else if (activeField) {
            const horaStr = tempDate.toLocaleTimeString('en-GB', { 
                hour: '2-digit', 
                minute: '2-digit',
                hour12: false 
            });
            setForm(f => ({ ...f, [activeField]: horaStr }));
        }
        setShowPicker(false);
    };

    // --- EFECTOS E INICIALIZACIÓN ---
    useEffect(() => {
        if (userData) setForm(prev => ({ ...prev, id_usuario: userData.id || (userData as any).id_usuario }));
        setForm(prev => ({ ...prev, fecha_evento: getHoy() }));
        cargarCatalogosInit();
        obtenerGpsAutomatico();
    }, [userData]);

    const obtenerGpsAutomatico = async () => {
        try {
            let lat, lon;
            if (Platform.OS === 'web') { lat = -12.073769; lon = -77.039673; }
            else {    
                let { status } = await Location.requestForegroundPermissionsAsync();
                if (status !== 'granted') return;
                const loc = await Location.getCurrentPositionAsync({ accuracy: Location.Accuracy.Balanced });
                lat = loc.coords.latitude; lon = loc.coords.longitude;
            }
            setForm(prev => ({ ...prev, latitud_gps: lat.toString(), longitud_gps: lon.toString() }));
            const reverseGeocode = await Location.reverseGeocodeAsync({ latitude: lat, longitude: lon });
            if (reverseGeocode.length > 0) {
                const p = reverseGeocode[0];
                const direccionNombre = `${p.street || ''} ${p.streetNumber || ''}, ${p.district || p.city || ''}`.trim();
                setForm(prev => ({ ...prev, nombre_punto_gps: direccionNombre || 'Ubicación identificada' }));
            }
        } catch (e) { console.error("Error GPS:", e); }
    };

    const cargarCatalogosInit = async () => {
        try {
            const [resGral, resTiposV, resPnps] = await Promise.all([
                fetch(`${API_URL}/catalogos/completo/unificado?tipoLugar=5`),
                fetch(`${API_URL}/catalogos/tipos-vehiculo`),
                fetch(`${API_URL}/catalogos/pnp-activos`)
            ]);
            const data = await resGral.json();
            setCatalogos({
                usuarios: data.usuarios || [], modalidades: data.modalidades || [], origenes: data.origenes || [],
                camaras: data.camara || [], tipos_patrullaje: data.tipos_patrullaje || [],
                modalidades_patrullaje: data.modalidades_patrullaje || [],
                tipos_vehiculo: await resTiposV.json() || [], unidades: [], pnps: await resPnps.json() || [],  lugares: data.lugares|| []
            });
            setTiposVia(data.tipos_via || []);
        } catch (err) { console.error("Error catálogos:", err); }
    };

    const fetchUnidades = async (idTipo: any) => {
        try {
            const res = await fetch(`${API_URL}/catalogos/vehiculos-por-tipo/${idTipo}`);
            const data = await res.json();
            setCatalogos(prev => ({ ...prev, unidades: data }));
        } catch (e) { console.error(e); }
    };

    // --- ACCIONES DE FORMULARIO ---
    const agregarVehiculo = () => {
    if (!unidadForm.id_unidad) return Alert.alert("Atención", "Seleccione una unidad/placa.");
    
    // --- VALIDACIÓN DE DUPLICADOS ---
    const yaExiste = form.vehiculos_detalle.some(v => v.id_unidad === unidadForm.id_unidad);
    if (yaExiste) return Alert.alert("Atención", `La placa ${unidadForm.placa} ya ha sido agregada.`);
    // --------------------------------

    const esCamioneta = unidadForm.id_tipo_vehiculo === ID_CAMIONETA;
    const asignacionFinal = esCamioneta ? unidadForm.tipo_asignacion : 'MUNICIPAL';
    const pnpFinal = (esCamioneta && asignacionFinal === 'INTEGRADO') ? unidadForm.id_pnp : null;
    
    if (asignacionFinal === 'INTEGRADO' && !pnpFinal) return Alert.alert("Atención", "Efectivo PNP requerido.");

    setForm(f => ({
        ...f,
        vehiculos_detalle: [...f.vehiculos_detalle, { 
            ...unidadForm, 
            tipo_asignacion: asignacionFinal, 
            id_pnp: pnpFinal,
            // Guardamos el nombre del PNP si existe para mostrarlo en el resumen
      nombre_pnp: (catalogos.pnps.find((p: any) => String(p.value) === String(unidadForm.id_pnp)) as any)?.label || ''
        }]
    }));

    // Resetear formulario de unidad
    setUnidadForm({ id_tipo_vehiculo: null, id_unidad: null, placa: '', tipo_asignacion: 'MUNICIPAL', id_pnp: null });
};

    const handleTipoViaChange = async (idTipo: any) => {
        setSelTipoVia(idTipo); setSelVia(null); setCuadras([]);
        setForm(f => ({ ...f, id_lugar: null }));
        try {
            const res = await fetch(`${API_URL}/catalogos/vias/${idTipo}`);
            setVias(await res.json());
        } catch (err) { console.error(err); }
    };

    const handleViaChange = async (idVia: any) => {
        setSelVia(idVia);
        setForm(f => ({ ...f, id_lugar: null }));
        try {
            const res = await fetch(`${API_URL}/catalogos/cuadras/${idVia}`);
            setCuadras(await res.json());
        } catch (err) { console.error(err); }
    };

    const capturarHoraActual = (campo: string) => {
        const ahora = new Date().toLocaleTimeString('en-GB', { hour12: false, hour: '2-digit', minute: '2-digit' });
        setForm(f => ({ ...f, [campo]: ahora }));
    };
const obtenerFechaLocal = () => {
    const fecha = new Date();
    const offset = fecha.getTimezoneOffset();
    const fechaLocal = new Date(fecha.getTime() - (offset * 60 * 1000));
    return fechaLocal.toISOString().split('T')[0];
};

    const tomarFoto = async () => {
        if (fotos.length >= MAX_FOTOS) return Alert.alert("Límite", "Máximo 5 fotos.");
        const { status } = await ImagePicker.requestCameraPermissionsAsync();
        if (status !== 'granted') return Alert.alert("Error", "Sin permiso de cámara");
        let res = await ImagePicker.launchCameraAsync({ base64: true, quality: 0.3 });
        if (!res.canceled) setFotos(p => [...p, { uri: res.assets[0].uri, base64: `data:image/jpeg;base64,${res.assets[0].base64}` }]);
    };

    const seleccionarGaleria = async () => {
        if (fotos.length >= MAX_FOTOS) return Alert.alert("Límite", "Máximo 5 fotos.");
        let res = await ImagePicker.launchImageLibraryAsync({ base64: true, allowsMultipleSelection: true, quality: 0.3, selectionLimit: MAX_FOTOS - fotos.length });
        if (!res.canceled) {
            const nuevas = res.assets.map(a => ({ uri: a.uri, base64: `data:image/jpeg;base64,${a.base64}` }));
            setFotos(p => [...p, ...nuevas].slice(0, MAX_FOTOS));
        }
    };

   const enviarRegistro = async () => {
    setLoading(true); 
    setUploadProgress(0); 
    setUploadStatus('Subiendo...'); 
    setIsFinished(false);

    const interval = setInterval(() => setUploadProgress(p => (p < 90 ? p + 10 : p)), 150);

    try {
        const res = await fetch(`${API_URL}/ocurrencias/registrar/modvehi`, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({
                ...form,
                id_tipop: form.id_tipo_patrullaje,
                id_modalidadp: form.id_modalidad_patrullaje,
                id_camara: form.id_camara.map(c => (c as any).value).join(','),
                fotos: fotos.map(f => ({ base64_data: f.base64 }))
            })
        });

        clearInterval(interval);
if (res.ok) {
    setUploadProgress(100); 
    setUploadStatus('¡Listo! Subido'); // Este es el texto que se mostrará [cite: 431, 432]
    setIsFinished(true);

    setTimeout(() => { 
        setLoading(false); 
        router.replace('/(tabs)' as any); 
    }, 1200);
} else { 
            setLoading(false); 
            Alert.alert("Error", "No se pudo guardar el registro."); 
        }
    } catch (e) { 
        clearInterval(interval); 
        setLoading(false); 
        Alert.alert("Error", "Error de conexión con el servidor."); 
    }
};
    // --- RENDER HELPERS ---
    const renderMosaicos = (data: any[], currentId: any, field: string, iconDefault: string) => (
        <View style={styles.mosaicoGrid}>
            {data.map((item: any) => (
                <Pressable key={item.value} onPress={() => setForm({ ...form, [field]: item.value })} style={[styles.mosaicoItem, currentId === item.value && styles.mosaicoSelected]}>
                    <Ionicons name={iconDefault as any} size={18} color={currentId === item.value ? 'white' : MJM_BLUE} />
                    <ThemedText style={[styles.mosaicoText, currentId === item.value && { color: 'white' }]}>{item.label}</ThemedText>
                </Pressable>
            ))}
        </View>
    );

    // --- ESTILOS DINÁMICOS PARA MODO OSCURO ---
const dynamicStyles = {
    card: {
        backgroundColor: 'white',
    },
    textInput: {
        // El fondo es blanco, por lo tanto la letra DEBE ser negra
        backgroundColor: 'white',
        // CAMBIO AQUÍ: #000000 es Negro. El que tenías (#f0efef) es casi blanco.
        color: '#000000', 
        borderColor: isDark ? '#cccccc' : '#eeeeee',
    },
    label: {
        // Un gris oscuro para que sea legible sobre el fondo claro
        color: '#333333', 
    },
    sectionTitle: {
        color: MJM_BLUE,
    },
    dropdown: {
        backgroundColor: 'white',
        // CAMBIO AQUÍ: Tenías #ffffff (Blanco), por eso no se veía nada.
        color: '#000000', 
    },
    timeText: {
        color: MJM_BLUE,
    },
};
    return (
        <ThemedView style={[styles.main, { paddingTop: insets.top, backgroundColor: isDark ? '#ffffff' : '#f4f7f6' }]}>
            <View style={styles.stepperContainer}>
                {[1, 2, 3, 4].map(i => (
                    <View key={i} style={[styles.circle, step >= i && { backgroundColor: MJM_BLUE }]}>
                        <ThemedText style={{color:'white', fontWeight:'bold', fontSize: 11}}>{i}</ThemedText>
                    </View>
                ))}
            </View>

            <ScrollView contentContainerStyle={styles.scroll} keyboardShouldPersistTaps="handled">
                {step === 1 && (
                    <View style={[styles.card, dynamicStyles.card]}>
                        <ThemedText style={[styles.sectionTitle, dynamicStyles.sectionTitle]}>PASO 1: DESPACHO</ThemedText>
                        <View style={{backgroundColor: isDark ? '#ffffff' : '#eef2ff', padding: 10, borderRadius: 8, marginBottom: 15, borderWidth: 1, borderColor: MJM_BLUE}}>
                            <View style={{flexDirection:'row', alignItems:'center', gap:5}}>
                                <Ionicons name="location" size={14} color={MJM_BLUE} />
                                <ThemedText style={{fontSize: 10, color: MJM_BLUE, fontWeight: 'bold'}}>ENVIAR REPORTE DESDE:</ThemedText>
                            </View>
                            <ThemedText style={{fontSize: 11, color: isDark ? '#000000' : '#000000', marginTop: 2}}>{form.nombre_punto_gps || "CSI MDJM"}</ThemedText>
                        </View>
                        <ThemedText style={styles.label}>GRUPO</ThemedText>
<ScrollView 

  showsHorizontalScrollIndicator={false} 
  contentContainerStyle={styles.label}
>
  {renderMosaicos(
    [
      {label: 'GRUPO 1', value: '1'}, 
      {label: 'GRUPO 2', value: '2'}, 
      {label: 'GRUPO 3', value: '3'},
      {label: 'GRUPO 4', value: '4'}
    ], 
    form.grupo, 
    'grupo', 
    'people-outline'
  )}
</ScrollView>

                        <ThemedText style={[styles.label, dynamicStyles.label]}>TIPO DE PATRULLAJE</ThemedText>
                        {renderMosaicos(catalogos.tipos_patrullaje, form.id_tipo_patrullaje, 'id_tipo_patrullaje', 'shield-checkmark-outline')}
                       
                        <ThemedText style={[styles.label, dynamicStyles.label]}>ORIGEN</ThemedText>
                        <Dropdown style={[styles.dropdown, dynamicStyles.dropdown, getDynamicBorderStyle(form.id_origen)]} data={catalogos.origenes} labelField="label" valueField="value" placeholder="Seleccione Origen" value={form.id_origen} onChange={i => setForm({...form, id_origen: i.value})} />
                       {form.id_tipo_patrullaje === ID_PATRULLAJE_MOTORIZADO && (
    <View style={[styles.cascadaContainer, getDynamicBorderStyle(form.vehiculos_detalle.length > 0)]}>
        <View style={styles.cascadaHeader}>
            <Ionicons name="car-sport" size={16} color={MJM_BLUE} />
            <ThemedText style={styles.cascadaTitle}>UNIDADES ASIGNADAS</ThemedText>
        </View>

        {/* 1. Selección de Tipo de Vehículo */}
        <Dropdown 
            style={[styles.dropdown, dynamicStyles.dropdown]} 
            data={catalogos.tipos_vehiculo} 
            labelField="label" 
            valueField="value" 
            placeholder="Tipo Vehículo" 
            value={unidadForm.id_tipo_vehiculo} 
            onChange={v => { 
                setUnidadForm({...unidadForm, id_tipo_vehiculo: v.value, id_unidad: null, placa: ''}); 
                fetchUnidades(v.value); 
            }} 
        />

        {/* 2. Lógica exclusiva para CAMIONETAS (ID_CAMIONETA = 1) */}
     {unidadForm.id_tipo_vehiculo === ID_CAMIONETA && (
    <View style={{ marginTop: 15, gap: 10 }}>
        <ThemedText style={[styles.label, { fontSize: 11, marginBottom: 5 }]}>
            TIPO DE ASIGNACIÓN
        </ThemedText>
        <View style={styles.asignacionContainer}> 
            {['MUNICIPAL', 'INTEGRADO'].map((tipo) => (
                <Pressable 
                    key={tipo}
                    onPress={() => setUnidadForm({ ...unidadForm, tipo_asignacion: tipo as any, id_pnp: null })}
                    style={[
                        styles.asignacionBtn, 
                        unidadForm.tipo_asignacion === tipo && styles.mosaicoSelected
                    ]}
                >
                    <ThemedText 
                        numberOfLines={1} 
                        adjustsFontSizeToFit // <-- Esto hace que el texto se encoja si no cabe
                        style={[
                            styles.asignacionText, 
                            { color: unidadForm.tipo_asignacion === tipo ? 'white' : MJM_BLUE }
                        ]}
                    >
                        {tipo}
                    </ThemedText>
                </Pressable>
            ))}
        </View>

        {unidadForm.tipo_asignacion === 'INTEGRADO' && (
            <Dropdown 
                style={[styles.dropdown, dynamicStyles.dropdown]} 
                data={catalogos.pnps} 
                search
                labelField="label" 
                valueField="value" 
                placeholder="Seleccionar Efectivo PNP" 
                value={unidadForm.id_pnp} 
                onChange={v => setUnidadForm({ ...unidadForm, id_pnp: v.value })} 
            />
        )}
    </View>
)}

        {/* 3. Selección de Placa y Botón Agregar */}
        <View style={{ flexDirection: 'row', gap: 10, alignItems: 'flex-end', marginTop: 10 }}>
            <View style={{ flex: 1 }}>
                <Dropdown 
                    style={[styles.dropdown, dynamicStyles.dropdown]} 
                    data={catalogos.unidades} 
                    labelField="label" 
                    valueField="value" 
                    placeholder="Seleccione Placa" 
                    value={unidadForm.id_unidad} 
                    onChange={v => setUnidadForm({ ...unidadForm, id_unidad: v.value, placa: v.label })} 
                />
            </View>
            <Pressable style={styles.btnAddUnit} onPress={agregarVehiculo}>
                <Ionicons name="add" size={24} color="white" />
            </Pressable>
        </View>

        {/* 4. LISTADO DE PLACAS AGREGADAS (Lo que pediste anteriormente) */}
    {form.vehiculos_detalle.length > 0 && (
    <View style={styles.listadoUnidadesContainer}>
        <View style={styles.listadoHeader}>
            <ThemedText style={styles.listadoTitle}>UNIDADES EN EL REPORTE ({form.vehiculos_detalle.length})</ThemedText>
        </View>
        
        {form.vehiculos_detalle.map((v, index) => (
            <View key={index} style={[styles.unitCard, { backgroundColor: isDark ? '#262626' : '#fff' }]}>
                <View style={styles.unitCardIcon}>
                    <Ionicons name={v.id_tipo_vehiculo === ID_CAMIONETA ? "car" : "bicycle"} size={20} color={MJM_BLUE} />
                </View>
                
                <View style={{ flex: 1, marginLeft: 10 }}>
                    <ThemedText style={styles.unitCardPlaca}>{v.placa}</ThemedText>
                    <ThemedText style={styles.unitCardSub}>
                        {v.tipo_asignacion} {v.nombre_pnp ? `| PNP: ${v.nombre_pnp}` : ''}
                    </ThemedText>
                </View>

                <Pressable 
                    onPress={() => {
                        const nuevos = form.vehiculos_detalle.filter((_, i) => i !== index);
                        setForm({ ...form, vehiculos_detalle: nuevos });
                    }}
                    style={styles.unitCardRemove}
                >
                    <Ionicons name="trash-outline" size={18} color="#ff4444" />
                </Pressable>
            </View>
        ))}
    </View>
)}
    </View>
)}
                    </View>
                )}
{step === 2 && (
    <View style={[styles.card, dynamicStyles.card, { backgroundColor: '#FFF' }]}>
        <ThemedText style={[styles.sectionTitle, dynamicStyles.sectionTitle]}>PASO 2: TIEMPOS</ThemedText>
        
        <View style={{ flexDirection: 'row', justifyContent: 'space-between', marginBottom: 10 }}>
            <ThemedText style={[styles.label, dynamicStyles.label]}>FECHA DEL EVENTO</ThemedText>
            <Pressable 
                onPress={() => setForm({...form, fecha_evento: getHoy()})}
                style={{ backgroundColor: MJM_BLUE, paddingHorizontal: 12, paddingVertical: 6, borderRadius: 6 }}
            >
                <ThemedText style={{ color: 'white', fontSize: 11, fontWeight: 'bold' }}>PONER HOY</ThemedText>
            </Pressable>
        </View>

        {Platform.OS === 'web' ? (
            <input
                type="date"
                value={form.fecha_evento}
                onChange={(e) => setForm({ ...form, fecha_evento: e.target.value })}
                style={{
                    height: 45,
                    borderWidth: 1,
                    borderColor: '#ccc',
                    borderRadius: 8,
                    padding: 10,
                    fontSize: 16,
                    backgroundColor: '#FFFFFF',
                    color: '#000000',
                    width: '100%',
                    outline: 'none',
                    borderStyle: 'solid'
                }}
            />
        ) : (
            <Pressable 
                onPress={() => { 
                    setPickerMode('date'); 
                    setActiveField('fecha_evento'); 
                    setTempDate(new Date(form.fecha_evento + 'T12:00:00'));
                    setShowPicker(true); 
                }} 
                style={[
                    styles.pickerPressable, 
                    { backgroundColor: '#FFFFFF', borderColor: MJM_BLUE, borderWidth: 1 }, 
                    getDynamicBorderStyle(form.fecha_evento)
                ]}
            >
                <Ionicons name="calendar-outline" size={20} color={MJM_BLUE} />
                <ThemedText style={{ color: '#000', marginLeft: 10 }}>
                    {formatearFechaEspañol(form.fecha_evento)}
                </ThemedText>
            </Pressable>
        )}

        {/* INPUTS DE HORAS */}
        {['hora_alerta', 'hora_llegada', 'hora_repliegue'].map((k) => (
            <View key={k} style={{ marginTop: 15 }}>
                <ThemedText style={[styles.label, dynamicStyles.label]}>
                    {k.toUpperCase().replace('_', ' ')}
                </ThemedText>
                <View style={styles.timeRow}>
                    {Platform.OS === 'web' ? (
                        <input
                            type="time"
                            value={(form as any)[k]}
                            onChange={(e) => setForm({ ...form, [k]: e.target.value })}
                            style={{
                                flex: 1,
                                height: 45,
                                borderWidth: 1, 
                                borderStyle: 'solid',
                                borderColor: '#ccc',
                                borderRadius: 8,
                                padding: 10,
                                backgroundColor: '#FFFFFF',
                                color: '#000000',
                                outline: 'none'
                            }}
                        />
                    ) : (
                        <Pressable 
                            onPress={() => { 
                                setPickerMode('time'); 
                                setActiveField(k);
                                const currentTime = (form as any)[k];
                                const date = new Date();
                                if (currentTime && currentTime !== '00:00') {
                                    const [hours, minutes] = currentTime.split(':');
                                    date.setHours(parseInt(hours), parseInt(minutes));
                                }
                                setTempDate(date);
                                setShowPicker(true); 
                            }} 
                            style={[styles.pickerPressable, { flex: 1, backgroundColor: '#FFF' }]}
                        >
                            <Ionicons name="time-outline" size={20} color={MJM_BLUE} />
                            <ThemedText style={{ color: '#000', marginLeft: 10 }}>
                                {formatearHora24h((form as any)[k]) || "00:00"}
                            </ThemedText>
                        </Pressable>
                    )}
                    <Pressable style={styles.btnTime} onPress={() => capturarHoraActual(k)}>
                        <Ionicons name="flash" size={20} color="white" />
                    </Pressable>
                </View>
            </View>
        ))}

        {/* VALIDACIÓN VISUAL: Solo aparece si las horas están llenas y el orden es incorrecto */}
        {form.hora_alerta && form.hora_llegada && form.hora_repliegue && 
         !(form.hora_alerta <= form.hora_llegada && form.hora_llegada <= form.hora_repliegue) && (
            <View style={{ 
        backgroundColor: '#FFF5F5', // Rojo muy suave de fondo
        borderLeftWidth: 4, 
        borderLeftColor: '#D32F2F', // Línea roja intensa a la izquierda
        padding: 12, 
        borderRadius: 8, 
        marginTop: 20,
        flexDirection: 'row',
        alignItems: 'center',
        shadowColor: "#000",
        shadowOffset: { width: 0, height: 1 },
        shadowOpacity: 0.1,
        shadowRadius: 2,
        elevation: 2
    }}>
        <Ionicons name="alert-circle" size={20} color="#D32F2F" style={{ marginRight: 10 }} />
        <View style={{ flex: 1 }}>
            <ThemedText style={{ color: '#D32F2F', fontSize: 13, fontWeight: 'bold' }}>
                Error en secuencia de tiempo
            </ThemedText>
            <ThemedText style={{ color: '#555', fontSize: 11 }}>
            {"El orden debe ser:  Repliegue > Llegada > Alerta"}
            </ThemedText>
        </View>
    </View>
        )}
    </View>
)}

{step === 3 && (
    <View style={styles.cascadaContainer}>
        <ThemedText style={[styles.sectionTitle, dynamicStyles.sectionTitle]}>PASO 3: UBICACIÓN</ThemedText>
        
        {/* Cabecera con Botón de Cambio */}
        <View style={{ flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', marginBottom: 15 }}>
            <View style={{ flexDirection: 'row', alignItems: 'center' }}>
                <Ionicons name="location" size={18} color={MJM_BLUE} />
                <ThemedText style={[styles.cascadaTitle, { marginLeft: 5 }]}>
                    {modoBusquedaManual ? "BÚSQUEDA MANUAL" : "DIRECCIÓN DIRECTA"}
                </ThemedText>
            </View>

            <Pressable 
                onPress={() => {
                    setModoBusquedaManual(!modoBusquedaManual);
                    setForm({...form, id_lugar: null});
                }}
                style={({ pressed }) => [
                    {
                        paddingHorizontal: 12,
                        paddingVertical: 6,
                        borderRadius: 8,
                        backgroundColor: modoBusquedaManual ? '#E3F2FD' : '#F5F5F5',
                        borderWidth: 1.5,
                        borderColor: MJM_BLUE,
                        opacity: pressed ? 0.7 : 1
                    }
                ]}
            >
                <ThemedText style={{ color: MJM_BLUE, fontSize: 10, fontWeight: 'bold' }}>
                    {modoBusquedaManual ? "USAR LISTADO" : "POR CALLE/CUADRA"}
                </ThemedText>
            </Pressable>
        </View>

        {/* --- MODO A: DIRECCIÓN DIRECTA --- */}
        {!modoBusquedaManual && (
            <View style={{ marginBottom: 10 }}>
                <Dropdown 
                    style={[styles.dropdown, { borderColor: MJM_BLUE, borderWidth: 1, backgroundColor: '#F9FCFF' }]} 
                    data={catalogos?.lugares || []} 
                    search 
                    searchPlaceholder="Buscar dirección..."
                    labelField="label" 
                    valueField="value" 
                    placeholder="Seleccione la ubicación..."
                    value={form.id_lugar} 
                    onChange={item => setForm({...form, id_lugar: item.value})}
                />   
            </View>
        )}

        {/* --- MODO B: BÚSQUEDA POR CASCADA (AZULITO Y HORIZONTAL) --- */}
        {modoBusquedaManual && (
            <View style={{ 
                flexDirection: 'row', 
                gap: 6, 
                backgroundColor: '#F0F7FF', // Fondo azulito muy suave
                padding: 10, 
                borderRadius: 10,
                borderWidth: 1,
                borderColor: '#BBDEFB'
            }}>
                {/* TIPO DE VÍA */}
                <View style={{ flex: 1 }}>
                    <ThemedText style={{ fontSize: 9, color: MJM_BLUE, fontWeight: '800', marginBottom: 3, marginLeft: 2 }}>TIPO</ThemedText>
                    <Dropdown 
                        style={[styles.dropdown, { height: 42, backgroundColor: '#FFF', borderColor: MJM_BLUE, borderWidth: 1 }]} 
                        data={tiposVia || []} 
                        labelField="label" 
                        valueField="value" 
                        placeholder="Tipo" 
                        value={selTipoVia} 
                        onChange={item => handleTipoViaChange(item.value)} 
                        placeholderStyle={{ fontSize: 11, color: '#999' }}
                        selectedTextStyle={{ fontSize: 11, fontWeight: 'bold', color: MJM_BLUE }}
                    />
                </View>

                {/* NOMBRE DE VÍA */}
                <View style={{ flex: 2.2 }}>
                    <ThemedText style={{ fontSize: 9, color: MJM_BLUE, fontWeight: '800', marginBottom: 3, marginLeft: 2 }}>CALLE / VÍA</ThemedText>
                    <Dropdown 
                        style={[
                            styles.dropdown, 
                            { height: 42, backgroundColor: '#FFF', borderColor: MJM_BLUE, borderWidth: 1 },
                            !selTipoVia && { backgroundColor: '#F5F5F5', borderColor: '#CCC' }
                        ]} 
                        disable={!selTipoVia} 
                        data={vias || []} 
                        search 
                        searchPlaceholder="Calle..."
                        labelField="label" 
                        valueField="value" 
                        placeholder="Nombre de vía..." 
                        value={selVia} 
                        onChange={item => handleViaChange(item.value)} 
                        placeholderStyle={{ fontSize: 11, color: '#999' }}
                        selectedTextStyle={{ fontSize: 11, fontWeight: 'bold', color: MJM_BLUE }}
                    />
                </View>

                {/* CUADRA */}
                <View style={{ flex: 0.9 }}>
                    <ThemedText style={{ fontSize: 9, color: MJM_BLUE, fontWeight: '800', marginBottom: 3, marginLeft: 2 }}>CDRA</ThemedText>
                    <Dropdown 
                        style={[
                            styles.dropdown, 
                            { height: 42, backgroundColor: '#FFF', borderColor: MJM_BLUE, borderWidth: 1 },
                            !selVia && { backgroundColor: '#F5F5F5', borderColor: '#CCC' }
                        ]} 
                        disable={!selVia} 
                        data={cuadras || []} 
                        labelField="label" 
                        valueField="value" 
                        placeholder="N°" 
                        value={form.id_lugar} 
                        onChange={item => setForm({...form, id_lugar: item.value})} 
                        placeholderStyle={{ fontSize: 11, color: '#999' }}
                        selectedTextStyle={{ fontSize: 11, fontWeight: 'bold', color: MJM_BLUE }}
                    />
                </View>
            </View>
        )}

        {/* --- REFERENCIA --- */}
        <View style={{ marginTop: 20 }}>
            <View style={{ flexDirection: 'row', alignItems: 'center', marginBottom: 5 }}>
                <Ionicons name="map-outline" size={14} color={MJM_BLUE} />
                <ThemedText style={[styles.cascadaTitle, { marginLeft: 5, fontSize: 12 }]}>REFERENCIA / INTERSECCIÓN</ThemedText>
            </View>
            <TextInput 
                style={[
                    styles.textAreaSmall, 
                    { 
                        minHeight: 85, 
                        textAlignVertical: 'top', 
                        color: '#000', 
                        backgroundColor: '#FFF',
                        padding: 12,
                        fontSize: 14,
                        borderWidth: 1.5,
                        borderColor: form.referencia.length >= 3 ? MJM_BLUE : '#DDD',
                        borderRadius: 10
                    }
                ]} 
                placeholder="Ej: A media cuadra del grifo Primax..." 
                placeholderTextColor="#AAA"
                value={form.referencia} 
                onChangeText={t => setForm({...form, referencia: t})} 
                multiline 
            />
        </View>
    </View>
)}
          {step === 4 && (
    <View style={[styles.card, dynamicStyles.card]}>
        <ThemedText style={[styles.sectionTitle, dynamicStyles.sectionTitle]}>PASO 4: CIERRE</ThemedText>
        
        {/* MODALIDAD CON BÚSQUEDA ACTIVADA */}
        <ThemedText style={styles.labelSmall}>SELECCIONE LA MODALIDAD</ThemedText>
        <Dropdown 
            style={[styles.dropdown, dynamicStyles.dropdown, getDynamicBorderStyle(form.id_modalidad)]} 
            data={catalogos.modalidades} 
            search 
            searchPlaceholder="Buscar modalidad..."
            labelField="label" 
            valueField="value" 
            placeholder="Modalidad Ocurrencia" 
            value={form.id_modalidad} 
            onChange={i => setForm({...form, id_modalidad: i.value})}
            inputSearchStyle={{
                height: 40,
                fontSize: 14,
                borderRadius: 8,
                color: '#000',
                paddingHorizontal: 10,
                backgroundColor: '#F9F9F9'
            }}
        />

        {/* DESCRIPCIÓN */}
        <View style={{ marginTop: 15, marginBottom: 10 }}>
            <ThemedText style={[styles.labelSmall, { marginBottom: 5 }]}>
                DESCRIPCIÓN DEL EVENTO
            </ThemedText>
            <TextInput 
                style={[
                    styles.textArea, 
                    dynamicStyles.textInput, 
                    { 
                        backgroundColor: '#FFFFFF', 
                        color: '#000000', 
                        minHeight: 120, 
                        textAlignVertical: 'top',
                        padding: 12,
                        fontSize: 14
                    },
                    getDynamicBorderStyle(form.descripcion.length >= 3) 
                ]} 
                placeholder="Escribe todos los detalles aquí..." 
                placeholderTextColor="#999999" 
                multiline={true} 
                value={form.descripcion} 
                onChangeText={(t) => setForm({ ...form, descripcion: t })} 
            />
            <ThemedText style={{ fontSize: 10, textAlign: 'right', marginTop: 2, color: '#888' }}>
                {`${form.descripcion.length} caracteres`}
            </ThemedText>
        </View>

        {/* ACCIONES DE FOTOS */}
        <View style={[styles.photoActions, { marginTop: 5 }]}>
            <Pressable style={styles.btnCamAction} onPress={tomarFoto}>
                <Ionicons name="camera" size={20} color="white" />
                <ThemedText style={styles.btnCamText}>CÁMARA</ThemedText>
            </Pressable>
            <Pressable style={[styles.btnCamAction, {backgroundColor: '#666'}]} onPress={seleccionarGaleria}>
                <Ionicons name="images" size={20} color="white" />
                <ThemedText style={styles.btnCamText}>GALERÍA</ThemedText>
            </Pressable>
        </View>

        <ThemedText style={[
            styles.photoCounter, 
            { marginVertical: 5 }, 
            fotos.length === MAX_FOTOS && { color: 'red', fontWeight: 'bold' }
        ]}>
            {`${fotos.length} de ${MAX_FOTOS} fotos`}
        </ThemedText>

        {/* CAROUSEL DE FOTOS */}
        {fotos.length > 0 && (
            <ScrollView horizontal style={[styles.photoCarousel, { maxHeight: 100 }]} showsHorizontalScrollIndicator={false}>
                {fotos.map((f, i) => (
                    <View key={i} style={styles.photoWrapper}>
                        <Image source={{ uri: f.uri }} style={styles.photoThumb} />
                        <Pressable 
                            style={styles.removePhoto} 
                            onPress={() => setFotos(prev => prev.filter((_, idx) => idx !== i))}
                        >
                            <Ionicons name="close-circle" size={22} color="red" />
                        </Pressable>
                    </View>
                ))}
            </ScrollView>
        )}

        <Pressable 
            style={[styles.btnSave, { marginTop: 15, opacity: canAdvance() ? 1 : 0.6 }]} 
            onPress={enviarRegistro} 
            disabled={!canAdvance() || loading}
        >
            <ThemedText style={{ color: 'white', fontWeight: 'bold' }}>
                {loading ? "ENVIANDO..." : "FINALIZAR REGISTRO"}
            </ThemedText>
        </Pressable>
    </View>
)}
            </ScrollView>

         <View style={[
    styles.navContainer, 
    {
        // Cambiado: siempre blanco, ignorando isDark
        backgroundColor: 'white', 
        // Borde sutil para que se vea sobre el fondo blanco
        borderTopColor: isDark ? '#cccccc' : '#eeeeee' 
    }
]}>
    <Pressable 
        style={[
            styles.navBtn, 
            { borderColor: isDark ? '#bbbbbb' : '#eeeeee' }
        ]} 
        onPress={() => setStep(step - 1)} 
        disabled={step === 1}
    >
        <ThemedText style={{ 
            // Si está deshabilitado, un gris; si no, el azul MJM_BLUE
            color: step === 1 ? (isDark ? '#999' : '#ccc') : MJM_BLUE 
        }}>
            ANTERIOR
        </ThemedText>
    </Pressable>

    {step < 4 && (
        <Pressable 
            style={[
                styles.navBtn, 
                { 
                    // El botón "Siguiente" mantiene su lógica de color
                    backgroundColor: canAdvance() ? MJM_BLUE : (isDark ? '#dddddd' : '#cccccc'), 
                    borderColor: canAdvance() ? MJM_BLUE : (isDark ? '#dddddd' : '#dddddd') 
                }
            ]} 
            onPress={() => setStep(step + 1)} 
            disabled={!canAdvance()}
        >
            <ThemedText style={{ color: 'white' }}>SIGUIENTE</ThemedText>
        </Pressable>
    )}
</View>

            {/* MODALES Y PICKERS */}
         <Modal visible={loading} transparent animationType="fade">
    <View style={styles.modalOverlay}>
        {/* Forzamos el fondo blanco aquí directamente */}
        <View style={[styles.modalContent, { backgroundColor: '#FFFFFF' }]}> 
            <ThemedText style={[styles.progressTitle, { color: MJM_BLUE }]}>
                {uploadStatus}
            </ThemedText>

            {!isFinished ? (
                <>
                    <View style={styles.progressBarBackground}>
                        <View style={[styles.progressBarFill, { width: `${uploadProgress}%` }]} />
                    </View>
                    <ThemedText style={styles.progressPercentage}>{uploadProgress}%</ThemedText>
                </>
            ) : (
                /* Icono de éxito en azul para resaltar sobre el blanco */
                <Ionicons name="checkmark-circle" size={60} color={MJM_BLUE} />
            )}
        </View>
    </View>
</Modal>

            {showPicker && (
                <Modal transparent animationType="fade">
    <View style={styles.modalOverlay}>
        {/* Forzamos fondo blanco y quitamos la dependencia de isDark */}
        <View style={[styles.modalPickerContent, { backgroundColor: '#FFFFFF', padding: 20, borderRadius: 15 }]}>
            
            <ThemedText style={[styles.pickerTitle, { color: MJM_BLUE, marginBottom: 10 }]}>
                {pickerMode === 'date' ? 'Seleccionar Fecha' : 'Seleccionar Hora (24h)'}
            </ThemedText>

            <DateTimePicker
                value={tempDate}
                mode={pickerMode}
                is24Hour={true}
                display={Platform.OS === 'ios' ? 'spinner' : 'default'}
                onChange={pickerMode === 'date' ? handleDateChange : handleTimeChange}
                locale="es-ES"
                // --- LAS 2 PROPIEDADES CLAVE ---
                themeVariant="light"   // Fuerza a iOS a usar el modo claro
                textColor="#000000"    // Fuerza el color del texto en el spinner de iOS
            />

            {Platform.OS === 'ios' && (
                <Pressable 
                    style={[styles.btnConfirmIOS, { backgroundColor: MJM_BLUE, marginTop: 15 }]} 
                    onPress={confirmIOSSelection}
                >
                    <ThemedText style={{ color: 'white', fontWeight: 'bold' }}>ACEPTAR</ThemedText>
                </Pressable>
            )}
        </View>
    </View>
</Modal>
            )}
        </ThemedView>
    );
}


const styles = StyleSheet.create({
   main: { 
        flex: 1, 
        backgroundColor: '#FFFFFF', // Blanco total para combatir el oscurecimiento
    },

    filaMosaicos: {
    flexDirection: 'row', // Fuerza la alineación horizontal
    paddingVertical: 10,
    paddingHorizontal: 5,
  },
  // Asegúrate de que el estilo del mosaico individual NO tenga width: '100%'
  // Lo ideal es un ancho fijo para que quepan varios en la fila
  mosaicoIndividual: {
    width: 100, 
    marginHorizontal: 5,
    aspectRatio: 1,
    justifyContent: 'center',
    alignItems: 'center',
    borderRadius: 10,
    backgroundColor: '#f0f0f0',
  },
    scroll: { paddingHorizontal: 15, paddingBottom: 100 },
    
    // Cambié todos los fondos sutiles por blanco sólido o gris muy brillante
    card: { 
        backgroundColor: '#FFFFFF', 
        padding: 18, 
        borderRadius: 15, 
        elevation: 0, // Quitamos elevación si se ve "sucio"
        borderWidth: 1,
        borderColor: '#EFEFEF',
    },
cascadaContainer: {
        marginTop: 15,
        padding: 12,
        borderRadius: 12,
        backgroundColor: '#F9FBFF', // Fondo casi blanco para contraste suave [cite: 377]
        borderWidth: 1,
        borderColor: '#E1E8F5',
    },
    unitCard: {
        flexDirection: 'row',
        alignItems: 'center',
        padding: 12,
        borderRadius: 10,
        marginBottom: 8,
        backgroundColor: '#FFFFFF', 
        borderWidth: 1,
        borderColor: '#F0F0F0',
    },

    unitCardIcon: {
        width: 36,
        height: 36,
        borderRadius: 18,
        backgroundColor: '#F0F5FF', // Azul muy claro pero sólido
        justifyContent: 'center',
        alignItems: 'center',
    },

    

    asignacionBtn: {
        flex: 1,
        height: 48,
        borderRadius: 10,
        borderWidth: 1.5,
        borderColor: MJM_BLUE,
        alignItems: 'center',
        justifyContent: 'center',
        backgroundColor: '#FFFFFF', 
    },
    listadoUnidadesContainer: {
        marginTop: 20,
        borderTopWidth: 1,
        borderTopColor: '#e0e0e0',
        paddingTop: 15,
    },

    asignacionContainer: {
        flexDirection: 'row',
        gap: 12,
        width: '100%',
        justifyContent: 'space-between'
    },

    

    asignacionText: {
        fontSize: 13,
        fontWeight: 'bold',
        textAlign: 'center',
        color: MJM_BLUE,
    },

    listadoHeader: {
        flexDirection: 'row',
        justifyContent: 'space-between',
        marginBottom: 10,
    },

    listadoTitle: {
        fontSize: 10,
        fontWeight: 'bold',
        color: '#888',
        letterSpacing: 1,
    },

   

    labelSmall: { fontSize: 10, fontWeight: 'bold', marginTop: 10, color: '#666' },

    disabledInput: { backgroundColor: '#f8f9fa', color: '#aaa', padding: 10, borderRadius: 8, marginTop: 5 },

    

    unitCardPlaca: {
        fontSize: 14,
        fontWeight: 'bold',
        color: MJM_BLUE,
    },

    unitCardSub: {
        fontSize: 11,
        color: '#666',
    },

    unitCardRemove: {
        padding: 8,
    },

    stepperContainer: { flexDirection: 'row', justifyContent: 'center', marginVertical: 12, gap: 12 },

    circle: { width: 24, height: 24, borderRadius: 12, backgroundColor: '#ddd', justifyContent: 'center', alignItems: 'center' },

    
    sectionTitle: { fontSize: 14, fontWeight: 'bold', color: MJM_BLUE, marginBottom: 15, textAlign: 'center' },

    label: { fontSize: 11, fontWeight: 'bold', marginTop: 15, color: '#444' },

    timeRow: { flexDirection: 'row', alignItems: 'center', gap: 10 },

    btnTime: { backgroundColor: MJM_BLUE, padding: 10, borderRadius: 10 },

    timeText: { fontSize: 16, color: MJM_BLUE, fontWeight: 'bold' },

    pickerPressable: { flexDirection: 'row', alignItems: 'center', gap: 10, padding: 12, backgroundColor: '#f4f4f4', borderRadius: 10, marginTop: 5, borderWidth: 1 },

    dropdown: { height: 40, borderBottomWidth: 1.5, borderBottomColor: '#eee', marginTop: 8, paddingHorizontal: 8, borderRadius: 6 },

    textArea: { borderWidth: 1.5, borderColor: '#eee', height: 100, marginTop: 15, padding: 12, borderRadius: 10, textAlignVertical: 'top', backgroundColor: 'white' },

    textAreaSmall: { borderWidth: 1.5, borderColor: '#eee', height: 60, marginTop: 15, padding: 10, borderRadius: 10, backgroundColor: 'white' },

    photoActions: { flexDirection: 'row', gap: 10, marginTop: 20 },

    btnCamAction: { flex: 1, backgroundColor: '#444', padding: 12, borderRadius: 12, flexDirection: 'row', justifyContent: 'center', alignItems: 'center', gap: 8 },

    btnCamText: { color: 'white', fontSize: 12, fontWeight: 'bold' },

    photoCounter: { fontSize: 10, color: '#888', marginTop: 8, textAlign: 'right' },

    photoCarousel: { marginTop: 15 },

    selectedUnitsContainer: {
        marginTop: 15,
        paddingTop: 10,
        borderTopWidth: 1,
        borderTopColor: '#eee',
    },

    selectedUnitsTitle: {
        fontSize: 11,
        fontWeight: 'bold',
        color: '#666',
        marginBottom: 8,
        textTransform: 'uppercase'
    },

    chipsWrapper: {
        flexDirection: 'row',
        flexWrap: 'wrap',
        gap: 8,
    },

    unitChip: {
        flexDirection: 'row',
        alignItems: 'center',
        backgroundColor: MJM_BLUE,
        paddingVertical: 6,
        paddingHorizontal: 10,
        borderRadius: 20,
        marginBottom: 5,
    },

    unitChipText: {
        color: 'white',
        fontSize: 12,
        fontWeight: 'bold',
    },

 

    photoWrapper: { marginRight: 15, position: 'relative' },

    photoThumb: { width: 80, height: 80, borderRadius: 12, borderWidth: 1, borderColor: '#ddd' },

    removePhoto: { position: 'absolute', top: -8, right: -8, backgroundColor: 'white', borderRadius: 12 },

    btnSave: { backgroundColor: '#28a745', padding: 15, borderRadius: 12, marginTop: 20, alignItems: 'center', width: '100%' },

    navContainer: { flexDirection: 'row', padding: 15, gap: 12, backgroundColor: 'white', borderTopWidth: 1, borderTopColor: '#eee' },

    navBtn: { flex: 1, padding: 14, borderRadius: 12, alignItems: 'center', borderWidth: 1.5, borderColor: '#eee' },

    cascadaHeader: { flexDirection: 'row', alignItems: 'center', gap: 8, marginBottom: 5 },

    cascadaTitle: { fontSize: 11, fontWeight: 'bold', color: MJM_BLUE },

    btnAddUnit: { backgroundColor: MJM_BLUE, padding: 10, borderRadius: 10 },

    mosaicoGrid: { flexDirection: 'row', flexWrap: 'wrap', gap: 8, marginTop: 10 },

    mosaicoItem: { width: '48%', backgroundColor: '#fff', padding: 12, borderRadius: 10, alignItems: 'center', borderWidth: 1.5, borderColor: '#f0f0f0' },

    mosaicoSelected: { backgroundColor: MJM_BLUE, borderColor: MJM_BLUE },

    mosaicoText: { fontSize: 9, fontWeight: 'bold', marginTop: 6, color: MJM_BLUE, textAlign: 'center' },

    modalOverlay: { flex: 1, backgroundColor: 'rgba(0,0,0,0.5)', justifyContent: 'center', alignItems: 'center' },

 modalContent: { 
    backgroundColor: '#FFFFFF', // Blanco forzado [cite: 334]
    padding: 30, 
    borderRadius: 20, 
    alignItems: 'center', 
    width: '85%',
    // Sombras para resaltar sobre el fondo oscuro del celular
    elevation: 10,           // Sombra en Android
    shadowColor: '#000',     // Sombra en iOS
    shadowOpacity: 0.25,
    shadowRadius: 4,
},
    progressTitle: { fontSize: 16, fontWeight: 'bold', marginBottom: 15, color: MJM_BLUE },

    dropdownContainer: {
        borderRadius: 12,
        marginTop: 5,
        elevation: 5, 
        backgroundColor: 'white',
    },

    inputSearchStyle: {
        height: 40,
        fontSize: 16,
        borderRadius: 8,
        color: 'black',
    },

    progressBarBackground: { width: '100%', height: 10, backgroundColor: '#eee', borderRadius: 5, overflow: 'hidden' },

    progressBarFill: { height: '100%', backgroundColor: MJM_BLUE },

    progressPercentage: { marginTop: 10, fontSize: 12, color: '#666', fontWeight: 'bold' },

    modalPickerContent: { backgroundColor: 'white', borderRadius: 20, padding: 20, width: '85%', alignItems: 'center' },

    pickerTitle: { fontWeight: 'bold', marginBottom: 15, color: MJM_BLUE },

    btnConfirmIOS: { backgroundColor: MJM_BLUE, padding: 12, borderRadius: 10, marginTop: 15, width: '100%', alignItems: 'center' },
});