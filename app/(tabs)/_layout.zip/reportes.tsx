import { ThemedText } from '@/components/themed-text';
import { ThemedView } from '@/components/themed-view';
import { Ionicons } from '@expo/vector-icons';
import { useLocalSearchParams, useRouter } from 'expo-router';
import React, { useCallback, useEffect, useState } from 'react';
import {
    ActivityIndicator,
    Dimensions,
    FlatList,
    Image,
    Modal,
    Platform,
    RefreshControl,
    ScrollView,
    StyleSheet,
    TouchableOpacity,
    View
} from 'react-native';

// Librerías para ZIP (Solo Web)
const JSZip = Platform.OS === 'web' ? require('jszip') : null;
const saveAs = Platform.OS === 'web' ? require('file-saver').saveAs : null;

const MJM_BLUE = '#024885';
const { width: SCREEN_WIDTH } = Dimensions.get('window');

const JM_GEOMETRY_OFICIAL: any = {
  "type": "Feature",
  "geometry": {
    "type": "Polygon",
    "coordinates": [[
      [-77.0628, -12.0862], [-77.0562, -12.0914], [-77.0304, -12.0738], [-77.0417, -12.0605], [-77.0628, -12.0862]
    ]]
  }
};

export default function ReportesScreen() {
  const router = useRouter();
  const params = useLocalSearchParams();
  
  const idUsuario = params.idUsuario || '';
  const rolUsuario = params.rolUsuario || 'sereno';
  const esSuperUsuario = ['observatorio', 'gerente', 'subgerente'].includes(rolUsuario as string);

  const [reportes, setReportes] = useState<any[]>([]);
  const [cargando, setCargando] = useState(true);
  const [refreshing, setRefreshing] = useState(false);
  const [descargando, setDescargando] = useState(false);
  const [modalVisible, setModalVisible] = useState(false);
  const [reporteSeleccionado, setReporteSeleccionado] = useState<any>(null);
  const [tabActiva, setTabActiva] = useState<'foto' | 'mapa'>('foto');
  const [Leaflet, setLeaflet] = useState<any>(null);

  const cargarReportes = useCallback(async () => {
    try {
      const url = esSuperUsuario 
        ? `http://192.168.1.11:3000/reportes` 
        : `http://192.168.1.11:3000/reportes?usuario_id=${idUsuario}`;
      
      const response = await fetch(url);
      if (!response.ok) throw new Error("Error en servidor");
      
      const data = await response.json();
      setReportes(Array.isArray(data) ? data : []);
    } catch (error) { 
      console.error("Error al obtener reportes:", error);
    } finally { 
      setCargando(false);
      setRefreshing(false);
    }
  }, [idUsuario, rolUsuario, esSuperUsuario]);

  useEffect(() => {
    if (Platform.OS === 'web' && typeof window !== 'undefined') {
      const L = require('leaflet');
      const RL = require('react-leaflet');
      require('leaflet/dist/leaflet.css');

      // Fix para iconos de Leaflet en Web
      delete (L.Icon.Default.prototype as any)._getIconUrl;
      L.Icon.Default.mergeOptions({
        iconRetinaUrl: 'https://cdnjs.cloudflare.com/ajax/libs/leaflet/1.7.1/images/marker-icon-2x.png',
        iconUrl: 'https://cdnjs.cloudflare.com/ajax/libs/leaflet/1.7.1/images/marker-icon.png',
        shadowUrl: 'https://cdnjs.cloudflare.com/ajax/libs/leaflet/1.7.1/images/marker-shadow.png',
      });

      setLeaflet({ ...RL });
    }
    cargarReportes();
  }, [cargarReportes]);

  const onRefresh = () => {
    setRefreshing(true);
    cargarReportes();
  };

  const abrirModal = (item: any, tab: 'foto' | 'mapa') => {
    setReporteSeleccionado(item);
    setTabActiva(tab);
    setModalVisible(true);
  };

  const descargarZipWeb = async () => {
    if (Platform.OS !== 'web' || !reporteSeleccionado?.fotos || !JSZip) return;
    setDescargando(true);
    try {
      const zip = new JSZip();
      for (let i = 0; i < reporteSeleccionado.fotos.length; i++) {
        const resp = await fetch(reporteSeleccionado.fotos[i]);
        const blob = await resp.blob();
        zip.file(`evidencia_${i + 1}.jpg`, blob);
      }
      const content = await zip.generateAsync({ type: "blob" });
      saveAs(content, `Reporte_${reporteSeleccionado.id}.zip`);
    } catch (e) { 
      console.error("Error al crear ZIP:", e);
    } finally { 
      setDescargando(false); 
    }
  };

  return (
    <ThemedView style={styles.container}>
      {/* HEADER */}
      <View style={styles.customHeader}>
        <View>
          <ThemedText style={styles.headerTitle}>Historial de Ocurrencias</ThemedText>
          <ThemedText style={styles.headerSub}>Jesús María Reportes</ThemedText>
        </View>
        <TouchableOpacity style={styles.refreshCircle} onPress={onRefresh}>
          <Ionicons name="refresh" size={20} color={MJM_BLUE} />
        </TouchableOpacity>
      </View>

      <View style={styles.content}>
        {cargando ? (
          <View style={styles.center}>
            <ActivityIndicator size="large" color={MJM_BLUE} />
          </View>
        ) : (
          <FlatList
            data={reportes}
            keyExtractor={(item) => item.id.toString()}
            refreshControl={<RefreshControl refreshing={refreshing} onRefresh={onRefresh} />}
            ListHeaderComponent={() => (
              <View style={styles.tableHeader}>
                <ThemedText style={[styles.headerLabel, { flex: 1 }]}>ÁREA</ThemedText>
                <ThemedText style={[styles.headerLabel, { flex: 1 }]}>FOTO</ThemedText>
                <ThemedText style={[styles.headerLabel, { flex: 1.5 }]}>DESCRIPCIÓN</ThemedText>
                <ThemedText style={[styles.headerLabel, { flex: 0.5 }]}>GPS</ThemedText>
              </View>
            )}
            renderItem={({ item }) => (
              <View style={styles.tableRow}>
                <View style={{ flex: 1 }}>
                  <ThemedText style={styles.areaBadge}>{item.area?.toUpperCase() || 'S.A'}</ThemedText>
                </View>
                
                <TouchableOpacity style={{ flex: 1, alignItems: 'center' }} onPress={() => abrirModal(item, 'foto')}>
                  {item.fotos && item.fotos.length > 0 ? (
                    <View style={styles.thumbnailContainer}>
                      <Image source={{ uri: item.fotos[0] }} style={styles.miniThumbnail} />
                      {item.fotos.length > 1 && (
                        <View style={styles.badge}><ThemedText style={styles.badgeTxt}>+{item.fotos.length - 1}</ThemedText></View>
                      )}
                    </View>
                  ) : <Ionicons name="image-outline" size={24} color="#cbd5e1" />}
                </TouchableOpacity>

                <View style={{ flex: 1.5 }}>
                  <ThemedText style={styles.columnDesc} numberOfLines={2}>{item.descripcion || 'Sin descripción'}</ThemedText>
                </View>
                
                <TouchableOpacity style={{ flex: 0.5, alignItems: 'center' }} onPress={() => abrirModal(item, 'mapa')}>
                  <Ionicons name="location" size={22} color={MJM_BLUE} />
                </TouchableOpacity>
              </View>
            )}
          />
        )}
      </View>

      {/* MODAL DETALLE */}
      <Modal visible={modalVisible} transparent animationType="fade">
        <View style={styles.modalOverlay}>
          <View style={styles.modalContent}>
            <View style={styles.modalHeader}>
              <ThemedText style={styles.modalTitle}>{tabActiva === 'foto' ? 'Evidencias' : 'Ubicación'}</ThemedText>
              <TouchableOpacity onPress={() => setModalVisible(false)}>
                <Ionicons name="close-circle" size={32} color="#f87171" />
              </TouchableOpacity>
            </View>

            <View style={{ flex: 1 }}>
              {tabActiva === 'foto' ? (
                <View style={{flex: 1}}>
                  <ScrollView horizontal pagingEnabled>
                    {reporteSeleccionado?.fotos?.map((url: string, i: number) => (
                      <Image key={i} source={{ uri: url }} style={styles.fullImage} resizeMode="contain" />
                    ))}
                  </ScrollView>
                  {Platform.OS === 'web' && reporteSeleccionado?.fotos?.length > 0 && (
                    <TouchableOpacity style={styles.downloadBtn} onPress={descargarZipWeb} disabled={descargando}>
                      {descargando ? <ActivityIndicator color="white" /> : <ThemedText style={styles.downloadBtnTxt}>DESCARGAR ZIP</ThemedText>}
                    </TouchableOpacity>
                  )}
                </View>
              ) : (
                <View style={styles.mapWrapper}>
                  {Leaflet && (reporteSeleccionado?.latitud || reporteSeleccionado?.lat) ? (
                    <Leaflet.MapContainer
                      center={[reporteSeleccionado.latitud || reporteSeleccionado.lat, reporteSeleccionado.longitud || reporteSeleccionado.lng]}
                      zoom={16}
                      style={{ height: '100%', width: '100%' }}
                    >
                      <Leaflet.TileLayer url="https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png" />
                      <Leaflet.GeoJSON data={JM_GEOMETRY_OFICIAL} style={{ color: MJM_BLUE, weight: 2, fillOpacity: 0.1 }} />
                      <Leaflet.Marker position={[reporteSeleccionado.latitud || reporteSeleccionado.lat, reporteSeleccionado.longitud || reporteSeleccionado.lng]} />
                    </Leaflet.MapContainer>
                  ) : (
                    <View style={styles.center}><ThemedText>Sin datos GPS válidos</ThemedText></View>
                  )}
                </View>
              )}
            </View>

            <TouchableOpacity style={styles.closeBtn} onPress={() => setModalVisible(false)}>
              <ThemedText style={{color: 'white', fontWeight: 'bold'}}>CERRAR DETALLE</ThemedText>
            </TouchableOpacity>
          </View>
        </View>
      </Modal>
    </ThemedView>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: '#f8fafc' },
  customHeader: { 
    backgroundColor: '#fff', height: 110, paddingTop: 45, flexDirection: 'row', 
    justifyContent: 'space-between', paddingHorizontal: 25, alignItems: 'center',
    borderBottomWidth: 1, borderBottomColor: '#f1f5f9'
  },
  headerTitle: { color: MJM_BLUE, fontWeight: 'bold', fontSize: 18 },
  headerSub: { color: '#94a3b8', fontSize: 12 },
  refreshCircle: { backgroundColor: '#f1f5f9', padding: 10, borderRadius: 50 },
  content: { flex: 1, padding: 15 },
  tableHeader: { 
    flexDirection: 'row', backgroundColor: '#fff', padding: 15, 
    borderTopLeftRadius: 15, borderTopRightRadius: 15, borderBottomWidth: 1, borderBottomColor: '#f1f5f9' 
  },
  headerLabel: { color: '#64748b', fontWeight: 'bold', fontSize: 11, textAlign: 'center' },
  tableRow: { 
    flexDirection: 'row', backgroundColor: 'white', paddingVertical: 12, 
    paddingHorizontal: 10, borderBottomWidth: 1, borderBottomColor: '#f8fafc', alignItems: 'center' 
  },
  areaBadge: { 
    fontSize: 9, fontWeight: 'bold', color: MJM_BLUE, backgroundColor: '#e0e7ff', 
    paddingVertical: 4, paddingHorizontal: 6, borderRadius: 6, textAlign: 'center'
  },
  thumbnailContainer: { width: 45, height: 45 },
  miniThumbnail: { width: 45, height: 45, borderRadius: 8, backgroundColor: '#f1f5f9' },
  badge: { 
    position: 'absolute', top: -4, right: -4, backgroundColor: '#ef4444', 
    borderRadius: 10, paddingHorizontal: 5, borderWidth: 1, borderColor: 'white'
  },
  badgeTxt: { color: 'white', fontSize: 9, fontWeight: 'bold' },
  columnDesc: { fontSize: 12, color: '#334155', paddingLeft: 10 },
  modalOverlay: { flex: 1, backgroundColor: 'rgba(15, 23, 42, 0.95)', justifyContent: 'center', alignItems: 'center' },
  modalContent: { backgroundColor: 'white', width: Platform.OS === 'web' ? 600 : '95%', height: '85%', borderRadius: 25, padding: 20 },
  modalHeader: { flexDirection: 'row', justifyContent: 'space-between', marginBottom: 15, alignItems: 'center' },
  modalTitle: { fontSize: 18, fontWeight: 'bold', color: MJM_BLUE },
  fullImage: { width: Platform.OS === 'web' ? 560 : SCREEN_WIDTH * 0.85, height: 400, borderRadius: 15 },
  mapWrapper: { flex: 1, backgroundColor: '#f1f5f9', borderRadius: 15, overflow: 'hidden' },
  downloadBtn: { backgroundColor: '#22c55e', padding: 15, borderRadius: 12, marginTop: 15, alignItems: 'center' },
  downloadBtnTxt: { color: 'white', fontWeight: 'bold' },
  closeBtn: { backgroundColor: MJM_BLUE, padding: 16, borderRadius: 12, alignItems: 'center', marginTop: 15 },
  center: { flex: 1, justifyContent: 'center', alignItems: 'center' }
});