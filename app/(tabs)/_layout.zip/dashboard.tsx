import { MaterialCommunityIcons } from '@expo/vector-icons';
import React, { useEffect, useMemo, useRef, useState } from 'react';
import { ActivityIndicator, FlatList, Platform, ScrollView, StyleSheet, Text, TextInput, TouchableOpacity, View } from 'react-native';

let WebView;
if (Platform.OS !== 'web') {
    WebView = require('react-native-webview').WebView;
}

const API_URL = 'http://192.168.1.11:3000';

const TIPOS_CATEGORIA = [
    { id: 'TODOS', label: 'Todos', icon: 'layers-outline', color: '#34495e' },
    { id: 'ESCUELA SEGURA', label: 'ESCUELA SEGURA', icon: 'school', color: '#f1d900' },
     { id: 'TÁCTICO PRIORIZADO', label: 'TÁCTICO PRIORIZADO', icon: 'hospital-building', color: '#0085CA' },
    { id: 'CUADERNOS DE CONTROL', label: 'Cuadernos de Control', icon: 'medical-bag', color: '#e74c3c' },

];

export default function PantallaLugaresGIS() {
    const [lugares, setLugares] = useState([]);
    const [poligonos, setPoligonos] = useState([]);
    const [loading, setLoading] = useState(true);
    const [sectorActivo, setSectorActivo] = useState('pnp');
    const [filtroTipo, setFiltroTipo] = useState('TODOS');
    const [cuadrantesSeleccionados, setCuadrantesSeleccionados] = useState([]);
    const [busqueda, setBusqueda] = useState('');
    const [isFullScreen, setIsFullScreen] = useState(false);
    
    const webViewRef = useRef(null);

    useEffect(() => {
        cargarDatos();
    }, [sectorActivo]);

    const cargarDatos = async () => {
        setLoading(true);
        try {
            const [resLugares, resPoligonos] = await Promise.all([
                fetch(`${API_URL}/lugares-giss`),
                fetch(`${API_URL}/poligonos?tipo=${sectorActivo}`)
            ]);
            const dataLugares = await resLugares.json();
            const dataPoligonos = await resPoligonos.json();
            
            setLugares(dataLugares);
            setPoligonos(dataPoligonos);
        } catch (e) {
            console.error("Error en carga:", e);
        } finally {
            setLoading(false);
        }
    };

    const listaCuadrantes = useMemo(() => {
        const nombres = poligonos.map(p => p.nombre).filter(Boolean);
        return [...new Set(nombres)].sort();
    }, [poligonos]);

    const toggleCuadrante = (nom) => {
        setCuadrantesSeleccionados(prev => 
            prev.includes(nom) ? prev.filter(i => i !== nom) : [...prev, nom]
        );
    };

    // --- LÓGICA DE FILTRADO ---
    const lugaresFiltradosPorCuadrante = useMemo(() => {
        return lugares.filter(l => {
            const cuadranteLugar = sectorActivo === 'pnp' ? l.pnp : l.jv;
            const cLugar = String(cuadranteLugar || "").trim().toUpperCase();
            const nLugar = String(l.nombre || "").toLowerCase();
            
            const matchBusqueda = nLugar.includes(busqueda.toLowerCase());
            const matchCuadrante = cuadrantesSeleccionados.length === 0 || 
                                   cuadrantesSeleccionados.some(c => c.trim().toUpperCase() === cLugar);

            return matchBusqueda && matchCuadrante;
        });
    }, [lugares, cuadrantesSeleccionados, busqueda, sectorActivo]);

    const lugaresVisibles = useMemo(() => {
        if (filtroTipo === 'TODOS') return lugaresFiltradosPorCuadrante;
        return lugaresFiltradosPorCuadrante.filter(l => 
            String(l.tipo || "").toUpperCase().trim() === filtroTipo
        );
    }, [lugaresFiltradosPorCuadrante, filtroTipo]);

    // --- CONTEO DINÁMICO PARA CATEGORÍAS ---
    const obtenerConteo = (categoriaId) => {
        if (categoriaId === 'TODOS') return lugaresFiltradosPorCuadrante.length;
        return lugaresFiltradosPorCuadrante.filter(l => 
            String(l.tipo || "").toUpperCase().trim() === categoriaId
        ).length;
    };

    const poligonosVisibles = useMemo(() => {
        if (cuadrantesSeleccionados.length === 0) return poligonos;
        return poligonos.filter(p => cuadrantesSeleccionados.includes(p.nombre));
    }, [poligonos, cuadrantesSeleccionados]);

    const moverMapaAPunto = (lugar) => {
        if (!lugar.coords) return;
        const script = `
            map.flyTo([${lugar.coords[0]}, ${lugar.coords[1]}], 18, { animate: true, duration: 1.5 });
            group.eachLayer(function(layer) {
                if (layer instanceof L.Marker) {
                    var latLng = layer.getLatLng();
                    if (latLng.lat === ${lugar.coords[0]} && latLng.lng === ${lugar.coords[1]}) {
                        layer.openPopup();
                    }
                }
            });
        `;
        webViewRef.current?.injectJavaScript(script);
    };

    const mapHTML = useMemo(() => {
        const jsonPuntos = JSON.stringify(lugaresVisibles);
        const jsonPoligonos = JSON.stringify(poligonosVisibles);
        const colorSector = sectorActivo === 'pnp' ? '#024885' : '#e74c3c';

        return `
            <!DOCTYPE html><html><head>
            <meta name="viewport" content="width=device-width, initial-scale=1.0">
            <link rel="stylesheet" href="https://unpkg.com/leaflet@1.9.4/dist/leaflet.css" />
            <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/@mdi/font@7.2.96/css/materialdesignicons.min.css">
            <script src="https://unpkg.com/leaflet@1.9.4/dist/leaflet.js"></script>
            <style>
                body,html,#map{height:100vh;width:100vw;margin:0;background:#f0f0f0;}
                .label-style { background: white; border: 1.5px solid ${colorSector}; padding: 1px 4px; font-weight: bold; font-size: 10px; border-radius: 3px; color: ${colorSector}; }
                .custom-pin {
                    display: flex; justify-content: center; align-items: center;
                    width: 24px !important; height: 24px !important;
                    background: white; border-radius: 50% 50% 50% 0;
                    transform: rotate(-45deg); border: 1.5px solid #fff;
                    box-shadow: 0 2px 4px rgba(0,0,0,0.3);
                }
                .custom-pin i { transform: rotate(45deg); font-size: 13px; }
            </style>
            </head><body><div id="map"></div><script>
                var map = L.map('map', {zoomControl: false}).setView([-12.0463, -77.0427], 14);
                L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png').addTo(map);
                var group = L.featureGroup().addTo(map);

                JSON.parse('${jsonPoligonos}').forEach(function(item) {
                    if(item.geometria) {
                        L.geoJSON(item.geometria, {
                            coordsToLatLng: function (c) { return (c[0] > c[1]) ? L.latLng(c[0], c[1]) : L.latLng(c[1], c[0]); },
                            style: { color: "${colorSector}", weight: 3, fillOpacity: 0.15, dashArray: '5,5' }
                        }).addTo(group).bindTooltip(item.nombre || '', { permanent: true, direction: 'center', className: 'label-style' });
                    }
                });

                var iconos = {'ESCUELA SEGURA': 'mdi-school', 'TÁCTICO PRIORIZADO': 'mdi-hospital-building', 'CUADERNOS DE CONTROL': 'mdi-book-open-blank-variant', 'DEFAULT': 'mdi-map-marker'};
                var colores = {'ESCUELA SEGURA': '#ac9b01', 'TÁCTICO PRIORIZADO': 'rgba(4, 102, 248, 0.67)', 'CUADERNOS DE CONTROL': '#e74c3c', 'DEFAULT': '#024885'};

                JSON.parse('${jsonPuntos}').forEach(function(p) {
                    var t = (p.tipo || "DEFAULT").toUpperCase().trim();
                    var color = colores[t] || colores['DEFAULT'];
                    var iconName = iconos[t] || iconos['DEFAULT'];
                    var customIcon = L.divIcon({
                        className: 'custom-div-icon',
                        html: "<div class='custom-pin' style='background:"+color+"'><i class='mdi "+iconName+"' style='color:white'></i></div>",
                        iconSize: [24, 24], iconAnchor: [12, 24]
                    });
                    L.marker(p.coords, {icon: customIcon}).addTo(group).bindPopup("<b>"+p.nombre+"</b>");
                });

                if(group.getLayers().length > 0) {
                    setTimeout(function(){ map.fitBounds(group.getBounds(), {padding: [30,30]}); }, 400);
                }
            </script></body></html>
        `;
    }, [lugaresVisibles, poligonosVisibles, sectorActivo]);

    return (
        <View style={styles.container}>
            <View style={[styles.mapSide, isFullScreen && { flex: 1 }]}>
                {Platform.OS === 'web' ? <iframe srcDoc={mapHTML} style={styles.webMap} title="map" /> : 
                <WebView ref={webViewRef} source={{ html: mapHTML }} style={{ flex: 1 }} javaScriptEnabled={true} />}
                
                <View style={styles.floatingButtons}>
                    <TouchableOpacity style={styles.mapButton} onPress={() => setIsFullScreen(!isFullScreen)}>
                        <MaterialCommunityIcons name={isFullScreen ? "fullscreen-exit" : "fullscreen"} size={24} color="#333" />
                    </TouchableOpacity>
                    <TouchableOpacity style={[styles.mapButton, loading && { backgroundColor: '#eee' }]} onPress={cargarDatos} disabled={loading}>
                        <MaterialCommunityIcons name="refresh" size={24} color={loading ? "#999" : "#024885"} />
                    </TouchableOpacity>
                </View>
            </View>

            {!isFullScreen && (
                <View style={styles.sidebar}>
                    <Text style={styles.title}>Control GIS</Text>
                    
                    <View style={styles.searchContainer}>
                        <MaterialCommunityIcons name="magnify" size={20} color="#999" />
                        <TextInput style={styles.searchInput} placeholder="Buscar por nombre..." value={busqueda} onChangeText={setBusqueda} />
                    </View>

                    <View style={styles.row}>
                        <TouchableOpacity onPress={() => setSectorActivo('pnp')} style={[styles.btnType, sectorActivo === 'pnp' && {backgroundColor: '#024885'}]}>
                            <Text style={[styles.btnTextType, sectorActivo === 'pnp' && {color: '#fff'}]}>PNP</Text>
                        </TouchableOpacity>
                        <TouchableOpacity onPress={() => setSectorActivo('jv')} style={[styles.btnType, sectorActivo === 'jv' && {backgroundColor: '#e74c3c'}]}>
                            <Text style={[styles.btnTextType, sectorActivo === 'jv' && {color: '#fff'}]}>JV</Text>
                        </TouchableOpacity>
                    </View>

                    <View style={styles.headerLabel}>
                        <Text style={styles.label}>CUADRANTES:</Text>
                        {cuadrantesSeleccionados.length > 0 && (
                            <TouchableOpacity onPress={() => setCuadrantesSeleccionados([])}>
                                <Text style={styles.clearText}>Limpiar (✕)</Text>
                            </TouchableOpacity>
                        )}
                    </View>

                    <View style={styles.cuadranteGrid}>
                        {listaCuadrantes.map(nom => {
                            const activo = cuadrantesSeleccionados.includes(nom);
                            return (
                                <TouchableOpacity key={nom} onPress={() => toggleCuadrante(nom)} style={[styles.btnCuadrante, activo && styles.btnCuadranteActivo]}>
                                    <Text style={[styles.btnTextCuadrante, activo && styles.btnTextCuadranteActivo]}>{nom}</Text>
                                </TouchableOpacity>
                            );
                        })}
                    </View>

                    <Text style={styles.label}>CATEGORÍA:</Text>
                    <View style={styles.catContainer}>
                        <ScrollView horizontal showsHorizontalScrollIndicator={false}>
                            {TIPOS_CATEGORIA.map(cat => {
                                const activo = filtroTipo === cat.id;
                                const esTodos = cat.id === 'TODOS';
                                const total = obtenerConteo(cat.id);
                                return (
                                    <TouchableOpacity 
                                        key={cat.id} 
                                        onPress={() => setFiltroTipo(cat.id)} 
                                        style={[styles.btnCat, activo && (esTodos ? styles.btnCatTodosActivo : { borderColor: cat.color, backgroundColor: cat.color + '10' })]}
                                    >
                                        <MaterialCommunityIcons name={cat.icon} size={18} color={activo && esTodos ? '#fff' : (activo ? cat.color : '#666')} />
                                        <Text style={[styles.btnTextCat, activo && esTodos ? { color: '#fff' } : (activo ? { color: '#000' } : { color: '#666' })]}>
                                            {cat.label} ({total})
                                        </Text>
                                    </TouchableOpacity>
                                );
                            })}
                        </ScrollView>
                    </View>

                    <FlatList
                        data={lugaresVisibles}
                        style={{ marginTop: 10 }}
                        keyExtractor={item => item.id.toString()}
                        renderItem={({ item }) => {
                            const colorBorde = TIPOS_CATEGORIA.find(c => c.id === item.tipo?.toUpperCase())?.color || '#024885';
                            const cuadranteTxt = sectorActivo === 'pnp' ? item.pnp : item.jv;
                            return (
                                <TouchableOpacity 
                                    style={[styles.card, { borderLeftColor: colorBorde }]} 
                                    onPress={() => moverMapaAPunto(item)}
                                    activeOpacity={0.7}
                                >
                                    <View style={{ flex: 1 }}>
                                        <Text style={styles.cardName}>{item.nombre}</Text>
                                        <Text style={styles.cardTag}>{cuadranteTxt} • {item.tipo}</Text>
                                    </View>
                                    <MaterialCommunityIcons name="chevron-right" size={20} color="#ccc" />
                                </TouchableOpacity>
                            );
                        }}
                    />
                </View>
            )}
            {loading && (
                <View style={styles.loadingOverlay}>
                    <ActivityIndicator size="large" color="#024885" />
                    <Text style={{ marginTop: 10, color: '#024885', fontWeight: 'bold' }}>Actualizando mapa...</Text>
                </View>
            )}
        </View>
    );
}

const styles = StyleSheet.create({
    container: { flex: 1, flexDirection: 'row', backgroundColor: '#fff' },
    mapSide: { flex: 2.2 },
    webMap: { width: '100%', height: '100%', border: 'none' },
    floatingButtons: { position: 'absolute', top: 15, right: 15, gap: 10, zIndex: 10 },
    mapButton: { backgroundColor: '#fff', padding: 10, borderRadius: 8, elevation: 5, shadowColor: '#000', shadowOffset: { width: 0, height: 2 }, shadowOpacity: 0.2, shadowRadius: 3 },
    sidebar: { flex: 1, padding: 15, borderLeftWidth: 1, borderLeftColor: '#eee' },
    title: { fontSize: 20, fontWeight: 'bold', marginBottom: 15, color: '#333' },
    searchContainer: { flexDirection: 'row', alignItems: 'center', backgroundColor: '#f0f0f0', borderRadius: 10, paddingHorizontal: 12, marginBottom: 15, height: 45 },
    searchInput: { flex: 1, marginLeft: 8, fontSize: 15, color: '#333' },
    row: { flexDirection: 'row', gap: 10, marginBottom: 15 },
    btnType: { flex: 1, padding: 12, borderRadius: 8, backgroundColor: '#f0f0f0', alignItems: 'center' },
    btnTextType: { fontWeight: 'bold', fontSize: 14 },
    headerLabel: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', marginTop: 5 },
    label: { fontSize: 11, fontWeight: 'bold', color: '#999', marginVertical: 10, textTransform: 'uppercase' },
    clearText: { fontSize: 11, color: '#e74c3c', fontWeight: 'bold' },
    cuadranteGrid: { flexDirection: 'row', flexWrap: 'wrap', gap: 8, marginBottom: 10 },
    btnCuadrante: { backgroundColor: '#f5f5f5', paddingVertical: 10, paddingHorizontal: 14, borderRadius: 10, minWidth: 55, alignItems: 'center' },
    btnCuadranteActivo: { backgroundColor: '#34495e', elevation: 3 },
    btnTextCuadrante: { fontSize: 13, fontWeight: '800', color: '#444' },
    btnTextCuadranteActivo: { color: '#fff' },
    catContainer: { height: 50 },
    btnCat: { flexDirection: 'row', alignItems: 'center', paddingHorizontal: 16, height: 40, borderRadius: 20, marginRight: 10, borderWidth: 1, borderColor: '#e0e0e0', backgroundColor: '#fff' },
    btnCatTodosActivo: { backgroundColor: '#34495e', borderColor: '#34495e' },
    btnTextCat: { fontSize: 13, fontWeight: '700', marginLeft: 8 },
    card: { flexDirection: 'row', alignItems: 'center', padding: 15, backgroundColor: '#f9f9f9', marginBottom: 10, borderRadius: 12, borderLeftWidth: 6, elevation: 2 },
    cardName: { fontSize: 14, fontWeight: 'bold', color: '#2c3e50' },
    cardTag: { fontSize: 12, color: '#7f8c8d', marginTop: 4 },
    loadingOverlay: { ...StyleSheet.absoluteFillObject, backgroundColor: 'rgba(255,255,255,0.7)', justifyContent: 'center', alignItems: 'center', zIndex: 20 }
});