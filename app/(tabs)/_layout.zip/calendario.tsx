import { ThemedText } from '@/components/themed-text';
import { ThemedView } from '@/components/themed-view';
import { Ionicons } from '@expo/vector-icons';
import React, { useEffect, useState } from 'react';
import { Dimensions, ScrollView, StyleSheet, TouchableOpacity, View } from 'react-native';

const { width } = Dimensions.get('window');
const API_URL = 'http://192.168.1.11:3000';

// Mapeo de colores del HTML original
const SHIFT_COLORS: any = {
  'M': '#D9B72F',   // Mañana
  'T': '#DA8060',   // Tarde
  'N': '#5457A3',   // Noche
  'DL': '#60A354',  // Descanso
  'DM': '#60B7DA',  // Domingo
  'L': '#DA6099',   // Licencia (Lic)
};

export default function CalendarioScreen() {
  const [loading, setLoading] = useState(false);
  const [selectedDay, setSelectedDay] = useState(new Date().getDate());
  const [mes, setMes] = useState(new Date().getMonth() + 1);
  const [anio] = useState(2026);
  const [misTurnos, setMisTurnos] = useState<any>({});

  // Cargar turnos del usuario (puedes pasar un id_persona fijo por ahora para probar)
  useEffect(() => {
    fetchMisTurnos();
  }, [mes]);

  const fetchMisTurnos = async () => {
    setLoading(true);
    try {
      // Usamos el endpoint que ya creamos en Node
      const response = await fetch(`${API_URL}/rol-mensual?mes=${mes}&anio=${anio}&id_grupo=1`);
      const data = await response.json();
      // Buscamos los turnos de la primera persona para este ejemplo de vista individual
      if (data.length > 0) setMisTurnos(data[0].turnos);
    } catch (error) {
      console.error(error);
    } finally {
      setLoading(false);
    }
  };

  const renderDay = (day: number, isInactive = false) => {
    const sigla = misTurnos[day];
    const isSelected = selectedDay === day && !isInactive;
    const bgColor = isSelected ? '#176282' : (isInactive ? 'transparent' : '#fff');

    return (
      <TouchableOpacity 
        key={isInactive ? `inv-${day}` : day}
        onPress={() => !isInactive && setSelectedDay(day)}
        style={[styles.dayBox, { backgroundColor: bgColor }, isInactive && styles.dayInactive]}
      >
        <ThemedText style={[styles.dayNumber, isSelected && { color: '#fff' }]}>{day}</ThemedText>
        {sigla && (
          <View style={[styles.badge, { backgroundColor: isSelected ? '#fff' : SHIFT_COLORS[sigla] || '#ccc' }]}>
            <ThemedText style={[styles.badgeText, isSelected && { color: '#176282' }]}>{sigla}</ThemedText>
          </View>
        )}
      </TouchableOpacity>
    );
  };

  const diasEnMes = new Date(anio, mes, 0).getDate();
  const primerDiaSemana = new Date(anio, mes - 1, 1).getDay(); // Para el offset del calendario

  return (
    <ThemedView style={styles.container}>
      {/* AppBar */}
      <View style={styles.appBar}>
        <Ionicons name="menu" size={24} color="#333" />
        <ThemedText style={styles.appBarTitle}>Shift Planner</ThemedText>
        <View style={styles.appBarIcons}>
          <Ionicons name="search" size={20} color="#176282" style={styles.iconCircle} />
          <Ionicons name="person-circle" size={30} color="#333" />
        </View>
      </View>

      <ScrollView contentContainerStyle={{ paddingBottom: 100 }}>
        {/* Header de Mes */}
        <View style={styles.monthHeader}>
          <View>
            <ThemedText style={styles.scheduleLabel}>SCHEDULE</ThemedText>
            <ThemedText style={styles.monthName}>Octubre {anio}</ThemedText>
          </View>
          <View style={styles.navGroup}>
            <TouchableOpacity onPress={() => setMes(m => m - 1)}><Ionicons name="chevron-back" size={20} /></TouchableOpacity>
            <TouchableOpacity onPress={() => setMes(m => m + 1)}><Ionicons name="chevron-forward" size={20} /></TouchableOpacity>
          </View>
        </View>

        {/* Grid Calendario */}
        <View style={styles.grid}>
          {['LU', 'MA', 'MI', 'JU', 'VI', 'SA', 'DO'].map(d => (
            <ThemedText key={d} style={styles.dayLabel}>{d}</ThemedText>
          ))}
          {/* Días vacíos del mes anterior */}
          {Array.from({ length: primerDiaSemana - 1 }).map((_, i) => renderDay(30 - i, true))}
          {/* Días del mes actual */}
          {Array.from({ length: diasEnMes }).map((_, i) => renderDay(i + 1))}
        </View>

        {/* Leyenda Horizontal */}
        <ThemedText style={styles.sectionTitle}>Shift Legend</ThemedText>
        <ScrollView horizontal showsHorizontalScrollIndicator={false} style={styles.legendContainer}>
          {Object.keys(SHIFT_COLORS).map(key => (
            <View key={key} style={styles.legendItem}>
              <View style={[styles.colorDot, { backgroundColor: SHIFT_COLORS[key] }]} />
              <ThemedText style={styles.legendText}>{key}</ThemedText>
            </View>
          ))}
        </ScrollView>

        {/* Card de Detalle (Bento Style) */}
        <View style={styles.detailCard}>
          <View style={styles.cardHeader}>
            <View style={styles.dateCircle}><ThemedText style={styles.dateCircleText}>{selectedDay}</ThemedText></View>
            <View>
              <ThemedText style={styles.cardTitle}>Día Seleccionado</ThemedText>
              <ThemedText style={styles.cardSub}>Turno: {misTurnos[selectedDay] || 'Sin asignar'}</ThemedText>
            </View>
          </View>
        </View>
      </ScrollView>

      {/* Botones Flotantes */}
      <View style={styles.fabContainer}>
        <TouchableOpacity style={styles.btnPrimary}>
          <Ionicons name="add" size={24} color="#fff" />
          <ThemedText style={styles.btnText}>Solicitar Licencia</ThemedText>
        </TouchableOpacity>
        <TouchableOpacity style={styles.btnSecondary}>
          <Ionicons name="people" size={24} color="#176282" />
        </TouchableOpacity>
      </View>
    </ThemedView>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: '#f7f7f8' },
  appBar: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', paddingHorizontal: 15, paddingTop: 50, paddingBottom: 10, backgroundColor: '#fff', borderBottomWidth: 1, borderColor: '#eee' },
  appBarTitle: { fontSize: 18, fontWeight: 'bold' },
  appBarIcons: { flexDirection: 'row', alignItems: 'center', gap: 10 },
  iconCircle: { backgroundColor: 'rgba(23, 98, 130, 0.1)', padding: 5, borderRadius: 20 },
  monthHeader: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', padding: 20 },
  scheduleLabel: { color: '#176282', fontSize: 10, fontWeight: 'bold', letterSpacing: 1 },
  monthName: { fontSize: 26, fontWeight: 'bold', color: '#0f171a' },
  navGroup: { flexDirection: 'row', backgroundColor: '#fff', padding: 8, borderRadius: 12, gap: 15, elevation: 2 },
  grid: { flexDirection: 'row', flexWrap: 'wrap', paddingHorizontal: 10, justifyContent: 'center' },
  dayLabel: { width: (width - 40) / 7, textAlign: 'center', fontSize: 10, fontWeight: 'bold', color: '#aaa', marginBottom: 10 },
  dayBox: { width: (width - 60) / 7, aspectRatio: 1, margin: 3, borderRadius: 12, justifyContent: 'space-between', alignItems: 'center', padding: 5, elevation: 1 },
  dayInactive: { opacity: 0.2 },
  dayNumber: { fontSize: 12, fontWeight: 'bold' },
  badge: { width: '100%', borderRadius: 6, paddingVertical: 2, alignItems: 'center' },
  badgeText: { fontSize: 9, fontWeight: 'bold', color: '#fff' },
  sectionTitle: { paddingHorizontal: 20, marginTop: 25, fontWeight: 'bold', fontSize: 14 },
  legendContainer: { paddingLeft: 20, marginTop: 10, marginBottom: 10 },
 legendItem: { 
  flexDirection: 'row', 
  alignItems: 'center', 
  backgroundColor: '#fff', 
  padding: 10, 
  borderRadius: 12, 
  marginRight: 10, 
  borderWidth: 1, // <--- CORRECTO: borderWidth
  borderColor: '#eee' 
},colorDot: { width: 12, height: 12, borderRadius: 4, marginRight: 8 },
  legendText: { fontSize: 11, fontWeight: '600' },
  detailCard: { margin: 20, padding: 20, backgroundColor: 'rgba(23, 98, 130, 0.06)', borderRadius: 24, borderWidth: 1, borderColor: 'rgba(23, 98, 130, 0.1)' },
  cardHeader: { flexDirection: 'row', alignItems: 'center', gap: 15 },
  dateCircle: { width: 45, height: 45, backgroundColor: '#176282', borderRadius: 14, justifyContent: 'center', alignItems: 'center' },
  dateCircleText: { color: '#fff', fontWeight: 'bold', fontSize: 18 },
  cardTitle: { fontWeight: 'bold', fontSize: 15 },
  cardSub: { fontSize: 12, color: '#666' },
 fabContainer: { 
    position: 'absolute', 
    bottom: 30, // <-- Súbelo de 30 a 55 o 60
    left: 20, 
    right: 20, 
    flexDirection: 'row', 
    gap: 10 
},
  btnPrimary: { flex: 1, height: 55, backgroundColor: '#176282', borderRadius: 18, flexDirection: 'row', justifyContent: 'center', alignItems: 'center', gap: 10, elevation: 4 },
  btnSecondary: { width: 55, height: 55, backgroundColor: '#fff', borderRadius: 18, justifyContent: 'center', alignItems: 'center', elevation: 2, borderWidth: 1, borderColor: '#eee' },
  btnText: { color: '#fff', fontWeight: 'bold', fontSize: 14 }
});