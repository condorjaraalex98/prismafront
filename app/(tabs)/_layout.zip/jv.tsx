import React, { useEffect, useMemo, useState } from 'react';
import { ActivityIndicator, Platform, StyleSheet, View } from 'react-native';
const WebView = Platform.OS !== 'web' ? require('react-native-webview').WebView : null;

export default function MapaCuadrantes() {
    const [datos, setDatos] = useState([]);
    const [loading, setLoading] = useState(true);

    useEffect(() => {
        fetch('http://192.168.1.11:3000/poligonos-jv')
            .then(res => res.json())
            .then(json => { 
                setDatos(json); 
                setLoading(false); 
            })
            .catch(e => {
                console.log(e);
                setLoading(false);
            });
    }, []);

    const mapHTML = useMemo(() => {
        const jsonString = JSON.stringify(datos);

        return `
            <!DOCTYPE html>
            <html>
            <head>
                <meta name="viewport" content="width=device-width, initial-scale=1.0">
                <link rel="stylesheet" href="https://unpkg.com/leaflet@1.9.4/dist/leaflet.css" />
                <script src="https://unpkg.com/leaflet@1.9.4/dist/leaflet.js"></script>
                <style>
                    body, html, #map { height: 100vh; width: 100vw; margin: 0; }
                </style>
            </head>
            <body>
                <div id="map"></div>
                <script>
                    var map = L.map('map', { zoomControl: false }).setView([-12.04, -77.03], 12);
                    L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png').addTo(map);

                    var lista = ${jsonString};
                    var group = L.featureGroup();

                    lista.forEach(function(item) {
                        if(item.geometria) {
                            var geoData = (typeof item.geometria === 'string') ? JSON.parse(item.geometria) : item.geometria;
                            
                            L.geoJSON(geoData, {
                                coordsToLatLng: function (coords) {
                                    // Mantenemos la lógica de corrección de coordenadas
                                    return (coords[0] > coords[1]) 
                                        ? L.latLng(coords[0], coords[1]) 
                                        : L.latLng(coords[1], coords[0]);
                                },
                                style: { 
                                    color: '#024885', 
                                    weight: 2, 
                                    fillOpacity: 0.2 // Un poco más transparente para que se vea el mapa base
                                }
                            }).addTo(group);
                            
                            // SE ELIMINÓ EL BLOQUE bindTooltip PARA QUITAR LOS NÚMEROS/NOMBRES
                        }
                    });

                    group.addTo(map);
                    
                    if(lista.length > 0) {
                        setTimeout(function() {
                            map.fitBounds(group.getBounds());
                        }, 500);
                    }
                </script>
            </body>
            </html>
        `;
    }, [datos]);

    return (
        <View style={{ flex: 1 }}>
            {loading && <ActivityIndicator size="large" style={StyleSheet.absoluteFill} />}
            {Platform.OS === 'web' ? (
                <iframe 
                    srcDoc={mapHTML} 
                    style={{ flex: 1, border: 'none', width: '100%', height: '100%' }} 
                />
            ) : (
                <WebView 
                    originWhitelist={['*']} 
                    source={{ html: mapHTML }} 
                    style={{ flex: 1 }} 
                />
            )}
        </View>
    );
}